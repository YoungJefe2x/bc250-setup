import {
  ButtonItem,
  DialogButton,
  DropdownItem,
  Field,
  Focusable,
  PanelSection,
  PanelSectionRow,
  SliderField,
  staticClasses,
} from "@decky/ui";
import { callable, definePlugin, toaster } from "@decky/api";
import { useEffect, useState } from "react";
import { FaTv, FaVolumeDown, FaVolumeMute, FaVolumeUp } from "react-icons/fa";

interface Status {
  device: boolean;
  registered?: boolean;
  pa?: string | null;
  tv_power?: string | null;
  audio_present?: boolean;
  volume?: number | null;
  muted?: boolean | null;
  volume_la?: number;
  error: string | null;
}

interface VolumeResult {
  ok: boolean;
  la: number;
  volume: number | null;
  muted: boolean | null;
}

interface ActionResult {
  ok: boolean;
  message?: string;
}

interface Settings {
  volume_target: "auto" | "audio" | "tv";
  steps: number;
}

const getStatus = callable<[boolean], Status>("get_status");
const volume = callable<[string, number], VolumeResult>("volume");
const mute = callable<[], VolumeResult>("mute");
const tvOn = callable<[], ActionResult>("tv_on");
const tvOff = callable<[], ActionResult>("tv_off");
const switchInput = callable<[], ActionResult>("switch_input");
const audioToSoundbar = callable<[], ActionResult>("audio_to_soundbar");
const getSettings = callable<[], Settings>("get_settings");
const setSettings = callable<[Partial<Settings>], Settings>("set_settings");

const LA_AUDIO = 5;

function report(title: string, r: ActionResult) {
  if (!r.ok) {
    toaster.toast({ title, body: r.message || "The TV did not answer." });
  }
}

function Content() {
  const [status, setStatus] = useState<Status | null>(null);
  const [settings, setLocal] = useState<Settings | null>(null);
  const [busy, setBusy] = useState(false);

  const refresh = (probe = false) =>
    getStatus(probe)
      .then(setStatus)
      .catch(() => setStatus({ device: false, error: "Backend did not respond." }));

  useEffect(() => {
    refresh(true);
    getSettings().then(setLocal).catch(() => {});
  }, []);

  const run = async (fn: () => Promise<unknown>) => {
    if (busy) return;
    setBusy(true);
    try {
      await fn();
    } finally {
      setBusy(false);
    }
  };

  const applyVolume = (r: VolumeResult) => {
    setStatus((s) =>
      s ? { ...s, volume: r.volume, muted: r.muted, volume_la: r.la } : s,
    );
    if (!r.ok) {
      toaster.toast({
        title: "CEC Remote",
        body: r.la === LA_AUDIO ? "The soundbar did not answer." : "The TV did not answer.",
      });
    }
  };

  if (status === null) {
    return (
      <PanelSection title="CEC Remote">
        <PanelSectionRow>Looking for the TV…</PanelSectionRow>
      </PanelSection>
    );
  }

  if (!status.device || !status.registered) {
    return (
      <PanelSection title="CEC Remote">
        <PanelSectionRow>
          <Field label="Not ready" description={status.error ?? ""} />
        </PanelSectionRow>
        <PanelSectionRow>
          <ButtonItem layout="below" onClick={() => refresh(true)}>
            Try again
          </ButtonItem>
        </PanelSectionRow>
      </PanelSection>
    );
  }

  const sink = status.volume_la === LA_AUDIO ? "Soundbar" : "TV";
  let level = "Level not reported";
  if (status.volume_la === LA_AUDIO && status.volume != null) {
    level = `${status.volume}${status.muted ? " (muted)" : ""}`;
  } else if (status.muted) {
    level = "Muted";
  }

  const btn = { minWidth: 0, flex: 1, padding: "10px 0" };

  return (
    <>
      <PanelSection title="Volume">
        <PanelSectionRow>
          <Field label={sink} description={level} />
        </PanelSectionRow>
        <PanelSectionRow>
          <Focusable style={{ display: "flex", gap: "8px" }} flow-children="horizontal">
            <DialogButton
              style={btn}
              disabled={busy}
              onClick={() => run(() => volume("down", 0).then(applyVolume))}
            >
              <FaVolumeDown />
            </DialogButton>
            <DialogButton
              style={btn}
              disabled={busy}
              onClick={() => run(() => mute().then(applyVolume))}
            >
              <FaVolumeMute />
            </DialogButton>
            <DialogButton
              style={btn}
              disabled={busy}
              onClick={() => run(() => volume("up", 0).then(applyVolume))}
            >
              <FaVolumeUp />
            </DialogButton>
          </Focusable>
        </PanelSectionRow>
      </PanelSection>

      <PanelSection title="TV">
        <PanelSectionRow>
          <Field label="Power" description={status.tv_power ?? "No answer"} />
        </PanelSectionRow>
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            disabled={busy}
            onClick={() => run(() => switchInput().then((r) => report("Switch input", r)))}
          >
            Switch TV to this box
          </ButtonItem>
        </PanelSectionRow>
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            disabled={busy}
            onClick={() =>
              run(() =>
                tvOn()
                  .then((r) => report("TV on", r))
                  .then(() => refresh()),
              )
            }
          >
            Turn TV on
          </ButtonItem>
        </PanelSectionRow>
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            disabled={busy}
            onClick={() =>
              run(() =>
                tvOff()
                  .then((r) => report("TV off", r))
                  .then(() => refresh()),
              )
            }
          >
            Turn TV off
          </ButtonItem>
        </PanelSectionRow>
        {status.audio_present && (
          <PanelSectionRow>
            <ButtonItem
              layout="below"
              disabled={busy}
              onClick={() =>
                run(() => audioToSoundbar().then((r) => report("Soundbar", r)))
              }
            >
              Send sound to soundbar
            </ButtonItem>
          </PanelSectionRow>
        )}
      </PanelSection>

      {settings && (
        <PanelSection title="Settings">
          <PanelSectionRow>
            <DropdownItem
              label="Volume keys go to"
              rgOptions={[
                { data: "auto", label: "Automatic" },
                { data: "audio", label: "Soundbar" },
                { data: "tv", label: "TV" },
              ]}
              selectedOption={settings.volume_target}
              onChange={(o) =>
                setSettings({ volume_target: o.data })
                  .then(setLocal)
                  .then(() => refresh())
              }
            />
          </PanelSectionRow>
          <PanelSectionRow>
            <SliderField
              label="Steps per press"
              value={settings.steps}
              min={1}
              max={10}
              step={1}
              showValue
              onChange={(v) => {
                setLocal({ ...settings, steps: v });
                setSettings({ steps: v });
              }}
            />
          </PanelSectionRow>
          <PanelSectionRow>
            <ButtonItem layout="below" disabled={busy} onClick={() => run(() => refresh(true))}>
              Refresh
            </ButtonItem>
          </PanelSectionRow>
        </PanelSection>
      )}
    </>
  );
}

export default definePlugin(() => ({
  name: "CEC Remote",
  titleView: <div className={staticClasses.Title}>CEC Remote</div>,
  content: <Content />,
  icon: <FaTv />,
}));
