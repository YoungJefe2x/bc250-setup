# CEC Remote

Decky plugin for the BC-250: a TV and soundbar remote over HDMI-CEC.

- Volume up / down / mute. Goes to the soundbar (CEC audio system) when one
  answers, otherwise to the TV. Shows the level the soundbar reports.
- Turn the TV on or off (through `cec-tv` when the installer's CEC option is
  set up, so bc250-cec is paused around a standby).
- Switch the TV's input to this box (Active Source).
- Send sound to the soundbar (System Audio Mode request).

Needs `cec-ctl` (v4l-utils) and /dev/cec0. It only transmits; it never runs a
follower of its own, so it does not fight bc250-cec for the adapter.

Build: `npm install && npm run build`.
