"""CEC Remote: TV and soundbar control over HDMI-CEC from Game Mode.

Everything goes through cec-ctl on /dev/cec0. bc250-cec (from the BC-250
kernel packages) owns the adapter's registration; this plugin only transmits
on top of it and never runs a follower of its own, since two claimants on
/dev/cec0 is what made the bus flap before. TV power goes through the
installer's `cec-tv` helper when it exists, because that already knows how to
pause bc250-cec around a standby.
"""

import asyncio
import json
import os
import re
import shutil
import subprocess
import time

import decky

DEV = "/dev/cec0"
CEC_TV = "/usr/local/bin/cec-tv"
OSD_NAME = "CachyOS"

LA_TV = 0
LA_AUDIO = 5

SETTINGS_DIR = getattr(decky, "DECKY_PLUGIN_SETTINGS_DIR", "/tmp/cec-remote")
SETTINGS_PATH = os.path.join(SETTINGS_DIR, "settings.json")

DEFAULTS = {
    # Where volume keys go: "auto" (soundbar if one answers, else TV),
    # "audio" (always the soundbar) or "tv".
    "volume_target": "auto",
    # Key presses sent per tap of a volume button.
    "steps": 2,
}

# How long a soundbar probe result is trusted before asking the bus again.
AUDIO_PROBE_TTL = 60

FAIL_MARKERS = ("Not Acknowledged", "Tx, Error", "Timeout", "Arbitration Lost")


def _clean_env():
    """Decky's PyInstaller backend exports LD_LIBRARY_PATH pointing at its own
    bundle. Children inherit it and pick up the wrong libraries, so strip it
    before running system tools."""
    env = dict(os.environ)
    for key in ("LD_LIBRARY_PATH", "LD_PRELOAD", "PYTHONHOME", "PYTHONPATH", "_MEIPASS2"):
        env.pop(key, None)
    env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
    env["LC_ALL"] = "C"
    return env


def _run(args, timeout=10):
    try:
        proc = subprocess.run(
            args,
            env=_clean_env(),
            capture_output=True,
            text=True,
            timeout=timeout,
            stdin=subprocess.DEVNULL,
        )
        return proc.returncode, proc.stdout, proc.stderr
    except FileNotFoundError:
        return 127, "", f"{args[0]}: not found"
    except subprocess.TimeoutExpired:
        return 124, "", f"{args[0]}: timed out"


def _cec(*args, timeout=5):
    """One cec-ctl call. Returns (ok, output)."""
    code, out, err = _run(["cec-ctl", "-d", DEV, "-s", *args], timeout)
    text = out + err
    ok = code == 0 and not any(m in text for m in FAIL_MARKERS)
    return ok, text


def _adapter_info():
    _, out, _ = _run(["cec-ctl", "-d", DEV], 5)
    pa = None
    mask = None
    m = re.search(r"Physical Address\s*:\s*(\S+)", out)
    if m:
        pa = m.group(1)
    m = re.search(r"Logical Address Mask\s*:\s*(0x[0-9a-fA-F]+)", out)
    if m:
        mask = int(m.group(1), 16)
    return pa, mask


def _ensure_registered():
    """Put the playback registration back if something wiped it. Anything sent
    from an unconfigured adapter goes nowhere."""
    pa, mask = _adapter_info()
    if mask:
        return pa, True
    if os.access(CEC_TV, os.X_OK):
        _run([CEC_TV, "register"], 10)
    else:
        _run(["cec-ctl", "-d", DEV, "--playback", "--osd-name", OSD_NAME], 10)
    pa, mask = _adapter_info()
    return pa, bool(mask)


def _parse_audio(text):
    vol = None
    muted = None
    m = re.search(r"aud-mute-status:\s*(\w+)", text)
    if m:
        muted = m.group(1) in ("on", "1")
    raw = None
    m = re.search(r"aud-vol-status:[^\n]*?0x([0-9a-fA-F]+)", text)
    if m:
        raw = int(m.group(1), 16)
    else:
        m = re.search(r"aud-vol-status:\s*(\d+)", text)
        if m:
            raw = int(m.group(1))
    if raw is not None:
        # 0x7f means "unknown"; the top bit is the mute flag on some devices.
        raw &= 0x7F
        vol = None if raw == 0x7F else raw
    return vol, muted


class Plugin:
    async def _main(self):
        self.lock = asyncio.Lock()
        self.settings = dict(DEFAULTS)
        self.audio_seen = None
        self.audio_probed = 0.0
        try:
            with open(SETTINGS_PATH) as f:
                saved = json.load(f)
            for key in DEFAULTS:
                if key in saved:
                    self.settings[key] = saved[key]
        except (OSError, ValueError):
            pass
        decky.logger.info("CEC Remote loaded")

    async def _unload(self):
        pass

    def _save(self):
        try:
            os.makedirs(SETTINGS_DIR, exist_ok=True)
            with open(SETTINGS_PATH, "w") as f:
                json.dump(self.settings, f, indent=2)
        except OSError as e:
            decky.logger.warning(f"could not save settings: {e}")

    # ---------------------------------------------------------- helpers ---

    def _audio_status(self):
        """Ask the soundbar for volume and mute. None when nothing answers."""
        ok, out = _cec("--to", str(LA_AUDIO), "--give-audio-status")
        if not ok or "REPORT_AUDIO_STATUS" not in out:
            return None
        vol, muted = _parse_audio(out)
        return {"volume": vol, "muted": muted}

    def _audio_present(self, refresh=False):
        if refresh or self.audio_seen is None or time.time() - self.audio_probed > AUDIO_PROBE_TTL:
            ok, _ = _cec("--to", str(LA_AUDIO), "--poll")
            self.audio_seen = ok
            self.audio_probed = time.time()
        return self.audio_seen

    def _volume_la(self):
        target = self.settings.get("volume_target", "auto")
        if target == "tv":
            return LA_TV
        if target == "audio":
            return LA_AUDIO
        return LA_AUDIO if self._audio_present() else LA_TV

    def _key(self, la, cmd):
        ok, out = _cec("--to", str(la), "--user-control-pressed", f"ui-cmd={cmd}")
        # Always release, even after a failed press, so the sink never sees a
        # stuck key and keeps ramping.
        _cec("--to", str(la), "--user-control-released")
        return ok, out

    def _tv_power(self):
        ok, out = _cec("--to", str(LA_TV), "--give-device-power-status")
        if not ok:
            return None
        m = re.search(r"pwr-state:\s*(\S+)", out)
        return m.group(1) if m else None

    def _snapshot(self, probe_audio=False):
        if not os.path.exists(DEV):
            return {"device": False, "error": "No CEC adapter (/dev/cec0 is missing)."}
        if not shutil.which("cec-ctl", path=_clean_env()["PATH"]):
            return {"device": False, "error": "cec-ctl is not installed (pacman -S v4l-utils)."}
        pa, registered = _ensure_registered()
        if not registered or pa in (None, "f.f.f.f"):
            return {
                "device": True,
                "registered": False,
                "pa": pa,
                "error": "The adapter has no CEC address yet. Is the TV on and Anynet+/Bravia Sync enabled?",
            }
        audio = self._audio_present(refresh=probe_audio)
        status = self._audio_status() if audio else None
        return {
            "device": True,
            "registered": True,
            "pa": pa,
            "tv_power": self._tv_power(),
            "audio_present": audio,
            "volume": status["volume"] if status else None,
            "muted": status["muted"] if status else None,
            "volume_la": self._volume_la(),
            "error": None,
        }

    # -------------------------------------------------------- callables ---

    async def get_status(self, probe_audio: bool = False):
        async with self.lock:
            return await asyncio.to_thread(self._snapshot, probe_audio)

    async def volume(self, direction: str, steps: int = 0):
        cmd = {"up": "volume-up", "down": "volume-down"}.get(direction)
        if cmd is None:
            return {"ok": False, "error": f"bad direction {direction}"}
        steps = int(steps) or int(self.settings.get("steps", 2))
        steps = max(1, min(steps, 10))

        def work():
            _ensure_registered()
            la = self._volume_la()
            ok = True
            for _ in range(steps):
                sent, _ = self._key(la, cmd)
                ok = ok and sent
            status = self._audio_status() if la == LA_AUDIO else None
            return {"ok": ok, "la": la, **(status or {"volume": None, "muted": None})}

        async with self.lock:
            return await asyncio.to_thread(work)

    async def mute(self):
        def work():
            _ensure_registered()
            la = self._volume_la()
            ok, _ = self._key(la, "mute")
            status = self._audio_status() if la == LA_AUDIO else None
            return {"ok": ok, "la": la, **(status or {"volume": None, "muted": None})}

        async with self.lock:
            return await asyncio.to_thread(work)

    async def tv_on(self):
        def work():
            if os.access(CEC_TV, os.X_OK):
                code, out, err = _run([CEC_TV, "on"], 60)
                return {"ok": code == 0, "message": (out + err).strip()[-300:]}
            pa, _ = _ensure_registered()
            ok, _ = _cec("--to", str(LA_TV), "--image-view-on")
            if pa and pa != "f.f.f.f":
                _cec("--active-source", f"phys-addr={pa}")
            return {"ok": ok, "message": ""}

        async with self.lock:
            return await asyncio.to_thread(work)

    async def tv_off(self):
        def work():
            if os.access(CEC_TV, os.X_OK):
                code, out, err = _run([CEC_TV, "off"], 30)
                return {"ok": code == 0, "message": (out + err).strip()[-300:]}
            _ensure_registered()
            ok, _ = _cec("--to", str(LA_TV), "--standby")
            return {"ok": ok, "message": ""}

        async with self.lock:
            return await asyncio.to_thread(work)

    async def switch_input(self):
        """Tell the TV this box is the active source, so it changes input."""
        def work():
            pa, registered = _ensure_registered()
            if not registered or not pa or pa == "f.f.f.f":
                return {"ok": False, "message": "No CEC address yet."}
            _cec("--to", str(LA_TV), "--image-view-on")
            ok, _ = _cec("--active-source", f"phys-addr={pa}")
            return {"ok": ok, "message": ""}

        async with self.lock:
            return await asyncio.to_thread(work)

    async def audio_to_soundbar(self):
        """Ask the soundbar to take over audio (System Audio Mode)."""
        def work():
            pa, registered = _ensure_registered()
            if not registered or not pa or pa == "f.f.f.f":
                return {"ok": False, "message": "No CEC address yet."}
            ok, _ = _cec("--to", str(LA_AUDIO), "--system-audio-mode-request", f"phys-addr={pa}")
            return {"ok": ok, "message": "" if ok else "The soundbar did not answer."}

        async with self.lock:
            return await asyncio.to_thread(work)

    async def get_settings(self):
        return self.settings

    async def set_settings(self, changes: dict):
        if changes.get("volume_target") in ("auto", "audio", "tv"):
            self.settings["volume_target"] = changes["volume_target"]
        if "steps" in changes:
            try:
                self.settings["steps"] = max(1, min(int(changes["steps"]), 10))
            except (TypeError, ValueError):
                pass
        self._save()
        return self.settings
