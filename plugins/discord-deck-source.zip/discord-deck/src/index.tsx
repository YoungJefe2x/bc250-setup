import {
  ButtonItem,
  DropdownItem,
  Field,
  PanelSection,
  PanelSectionRow,
  SliderField,
  Spinner,
  TextField,
  ToggleField,
  staticClasses,
} from "@decky/ui";
import { addEventListener, call, definePlugin, removeEventListener, toaster } from "@decky/api";
import { useEffect, useRef, useState } from "react";
import { FaHeadset } from "react-icons/fa";

// ------------------------------------------------------------------ types --

interface Status {
  has_credentials: boolean;
  has_token: boolean;
  connected: boolean;
  authenticated: boolean;
  socket: string | null;
  user: DiscordUser | null;
  client_id: string;
  ring_color: string;
}

interface Guild {
  id: string;
  name: string;
  icon_url?: string | null;
}

interface Channel {
  id: string;
  name: string;
  type: number;
  member_count?: number | null;
}

interface DiscordUser {
  id: string;
  username: string;
  discriminator: string;
  global_name?: string | null;
  avatar: string | null;
}

interface VoiceStateEntry {
  user: DiscordUser;
  nick?: string;
  voice_state?: {
    mute: boolean;
    deaf: boolean;
    self_mute: boolean;
    self_deaf: boolean;
    suppress: boolean;
  };
}

interface RpcDevice {
  id: string;
  name: string;
}

interface VoiceSettings {
  input_device_id: string | null;
  input_volume: number | null;
  input_devices: RpcDevice[];
  output_device_id: string | null;
  output_volume: number | null;
  output_devices: RpcDevice[];
  mute: boolean | null;
  deaf: boolean | null;
  mode: string | null;
}

interface PwNode {
  id: number;
  name: string;
  label: string;
}

interface SystemDevices {
  sinks: PwNode[];
  sources: PwNode[];
  default_sink_id: number | null;
  default_source_id: number | null;
}

// The Quick Access Menu unmounts/remounts this panel whenever its tab loses
// and regains focus, which wipes component state. Keep the picker selection
// at module scope so it survives remounts.
let cachedGuildId: string | null = null;
let cachedChannelId: string | null = null;

// -------------------------------------------------------------- backend io --

const getStatus = () => call<[], Status>("get_status");
const setCredentials = (id: string, secret: string) =>
  call<[client_id: string, client_secret: string], Status>("set_credentials", id, secret);
const connect = () => call<[], Status>("connect");
const authorize = () => call<[], Status>("authorize");
const signOut = () => call<[], Status>("sign_out");
const resetConnection = () => call<[], Status>("reset_connection");
const getGuilds = () => call<[], Guild[]>("get_guilds");
const getVoiceChannels = (guildId: string) =>
  call<[guild_id: string], Channel[]>("get_voice_channels", guildId);
const getCurrentChannel = () => call<[], Channel | null>("get_current_channel");
const joinChannel = (channelId: string) =>
  call<[channel_id: string], any>("join_channel", channelId);
const leaveChannel = () => call<[], any>("leave_channel");
const getVoiceSettings = () => call<[], VoiceSettings>("get_voice_settings");
const patchVoiceSettings = (patch: Record<string, any>) =>
  call<[patch: Record<string, any>], VoiceSettings>("set_voice_settings", patch);
const getSystemDevices = () => call<[], SystemDevices>("get_system_devices");
const setSystemDefault = (nodeId: number) =>
  call<[node_id: number], SystemDevices>("set_system_default", nodeId);
const getChannelMembers = (channelId: string) =>
  call<[channel_id: string], VoiceStateEntry[]>("get_channel_members", channelId);
const launchDiscord = () => call<[], { launched: boolean }>("launch_discord");
const getCurrentlySpeaking = () => call<[], string[]>("get_currently_speaking");
const setRingColor = (color: string) => call<[color: string], Status>("set_ring_color", color);
const getVoiceConnectionStatus = () => call<[], string | null>("get_voice_connection_status");

// Discord's voice (RTC) connection states, in plain words. Anything not
// listed shows as-is so nothing gets hidden.
function describeRtc(state: string | null): { text: string; ok: boolean } | null {
  if (!state) return null;
  const map: Record<string, { text: string; ok: boolean }> = {
    VOICE_CONNECTED: { text: "Voice connected", ok: true },
    VOICE_CONNECTING: { text: "Voice connecting…", ok: false },
    AWAITING_ENDPOINT: { text: "Waiting for voice server…", ok: false },
    AUTHENTICATING: { text: "Authenticating voice…", ok: false },
    CONNECTING: { text: "Connecting voice…", ok: false },
    ICE_CHECKING: { text: "Checking network route…", ok: false },
    NO_ROUTE: { text: "No route to voice server — network problem", ok: false },
    VOICE_DISCONNECTED: { text: "Voice disconnected", ok: false },
    DISCONNECTED: { text: "Voice disconnected", ok: false },
  };
  return map[state] ?? { text: state, ok: false };
}

function avatarUrl(user: DiscordUser): string {
  if (user.avatar) {
    const ext = user.avatar.startsWith("a_") ? "gif" : "png";
    return `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.${ext}?size=80`;
  }
  // No custom avatar — fall back to Discord's default avatars. New
  // username-system accounts (discriminator "0") key off the user id;
  // legacy accounts key off their four-digit discriminator.
  let index: number;
  if (!user.discriminator || user.discriminator === "0") {
    index = Number((BigInt(user.id) >> 22n) % 6n);
  } else {
    index = Number(user.discriminator) % 5;
  }
  return `https://cdn.discordapp.com/embed/avatars/${index}.png`;
}

function displayName(u: DiscordUser, nick?: string): string {
  return nick || u.global_name || u.username;
}

function fail(what: string, e: any) {
  const msg = e?.message ?? String(e);
  toaster.toast({ title: what, body: msg });
  console.error("[discord-deck]", what, e);
}

// -------------------------------------------------------------- setup view --

function Setup({ status, onSaved }: { status: Status; onSaved: (s: Status) => void }) {
  const [clientId, setClientId] = useState(status.client_id || "");
  const [secret, setSecret] = useState("");
  const [busy, setBusy] = useState(false);

  return (
    <PanelSection title="Set up">
      <PanelSectionRow>
        <Field
          description="Create an app at discord.com/developers, add http://localhost as a redirect URI, then paste its ID and secret here. Only you can use it until Discord approves the app."
          focusable
        />
      </PanelSectionRow>
      <PanelSectionRow>
        <TextField label="Client ID" value={clientId} onChange={(e) => setClientId(e.target.value)} />
      </PanelSectionRow>
      <PanelSectionRow>
        <TextField
          label="Client secret"
          bIsPassword
          value={secret}
          onChange={(e) => setSecret(e.target.value)}
        />
      </PanelSectionRow>
      <PanelSectionRow>
        <ButtonItem
          layout="below"
          disabled={busy || !clientId || !secret}
          onClick={async () => {
            setBusy(true);
            try {
              onSaved(await setCredentials(clientId, secret));
            } catch (e) {
              fail("Could not save credentials", e);
            } finally {
              setBusy(false);
            }
          }}
        >
          Save credentials
        </ButtonItem>
      </PanelSectionRow>
    </PanelSection>
  );
}

const RING_COLOR_PRESETS: { color: string; name: string }[] = [
  { color: "hsl(145, 65%, 39%)", name: "Green (default)" },
  { color: "hsl(210, 80%, 55%)", name: "Blue" },
  { color: "hsl(265, 70%, 62%)", name: "Purple" },
  { color: "hsl(340, 75%, 58%)", name: "Pink" },
  { color: "hsl(0, 70%, 55%)", name: "Red" },
  { color: "hsl(30, 90%, 55%)", name: "Orange" },
  { color: "hsl(48, 90%, 55%)", name: "Yellow" },
  { color: "hsl(0, 0%, 85%)", name: "White" },
];

function ColorOptionLabel({ color, name }: { color: string; name: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <div
        style={{
          width: 16,
          height: 16,
          borderRadius: "50%",
          background: color,
          border: "1px solid rgba(255,255,255,0.3)",
          flexShrink: 0,
        }}
      />
      <span>{name}</span>
    </div>
  );
}

// --------------------------------------------------------------- party ui --

function GuildOptionLabel({ guild }: { guild: Guild }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      {guild.icon_url ? (
        <img
          src={guild.icon_url}
          alt=""
          style={{ width: 20, height: 20, borderRadius: "50%", objectFit: "cover", flexShrink: 0 }}
        />
      ) : (
        <div
          style={{
            width: 20,
            height: 20,
            borderRadius: "50%",
            background: "rgba(255,255,255,0.15)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 10,
            flexShrink: 0,
          }}
        >
          {guild.name.trim().charAt(0).toUpperCase()}
        </div>
      )}
      <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{guild.name}</span>
    </div>
  );
}

function PartyMember({
  vs,
  speaking,
  ringColor,
}: {
  vs: VoiceStateEntry;
  speaking: boolean;
  ringColor: string;
}) {
  const u = vs.user;
  const name = displayName(u, vs.nick);
  const muted = !!(vs.voice_state?.mute || vs.voice_state?.self_mute);
  const deafened = !!(vs.voice_state?.deaf || vs.voice_state?.self_deaf);

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", width: 64, gap: 4 }}>
      <div
        style={{
          width: 52,
          height: 52,
          borderRadius: "50%",
          boxShadow: speaking
            ? `0 0 0 3px ${ringColor}, 0 0 10px 2px ${ringColor}`
            : "0 0 0 2px rgba(255,255,255,0.08)",
          transition: "box-shadow 100ms ease-out",
        }}
      >
        <img
          src={avatarUrl(u)}
          alt={name}
          style={{
            width: "100%",
            height: "100%",
            borderRadius: "50%",
            display: "block",
            objectFit: "cover",
            opacity: deafened ? 0.45 : 1,
          }}
        />
      </div>
      <span
        title={name}
        style={{
          fontSize: 11,
          maxWidth: 64,
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap",
          textAlign: "center",
          opacity: deafened ? 0.6 : 1,
        }}
      >
        {muted ? "🔇 " : ""}
        {name}
      </span>
    </div>
  );
}

// Discord's RPC never includes the local user's own voice state in
// GET_CHANNEL's voice_states — only other members — so build our own tile.
function withSelf(
  list: VoiceStateEntry[],
  selfUser: DiscordUser | null | undefined,
  mute: boolean,
  deaf: boolean,
): VoiceStateEntry[] {
  if (!selfUser || list.some((m) => m.user.id === selfUser.id)) return list;
  return [
    {
      user: selfUser,
      voice_state: { mute, deaf, self_mute: mute, self_deaf: deaf, suppress: false },
    },
    ...list,
  ];
}

// --------------------------------------------------------------- main view --

function Content() {
  const [status, setStatus] = useState<Status | null>(null);
  const [busy, setBusy] = useState(false);

  const [guilds, setGuilds] = useState<Guild[]>([]);
  const [guildId, setGuildIdState] = useState<string | null>(cachedGuildId);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [channelId, setChannelIdState] = useState<string | null>(cachedChannelId);
  const [current, setCurrent] = useState<Channel | null>(null);

  const setGuildId = (id: string | null) => {
    cachedGuildId = id;
    setGuildIdState(id);
  };
  const setChannelId = (id: string | null) => {
    cachedChannelId = id;
    setChannelIdState(id);
  };

  const [voice, setVoice] = useState<VoiceSettings | null>(null);
  const [system, setSystem] = useState<SystemDevices | null>(null);
  const [members, setMembers] = useState<VoiceStateEntry[]>([]);
  const [speaking, setSpeaking] = useState<Set<string>>(new Set());
  const [connectStatus, setConnectStatus] = useState<string>("");
  const [rtcState, setRtcState] = useState<string | null>(null);
  const volumeTimer = useRef<number | null>(null);

  // Effect closures registered once at mount would otherwise keep seeing
  // the first render's (null) status/voice; refs stay current.
  const statusRef = useRef<Status | null>(status);
  const voiceRef = useRef<VoiceSettings | null>(voice);
  statusRef.current = status;
  voiceRef.current = voice;

  async function loadMembers(channelId: string | null) {
    if (!channelId) {
      setMembers([]);
      setSpeaking(new Set());
      return;
    }
    try {
      const list = await getChannelMembers(channelId);
      setMembers(withSelf(list, statusRef.current?.user, !!voiceRef.current?.mute, !!voiceRef.current?.deaf));
    } catch (e) {
      fail("Could not load channel members", e);
    }
  }

  // Speaking events are edge-triggered and this panel's state resets on
  // every remount, so ask the backend (which never unmounts) for a snapshot.
  async function syncSpeaking() {
    try {
      setSpeaking(new Set(await getCurrentlySpeaking()));
    } catch (e) {
      fail("Could not sync speaking state", e);
    }
  }

  // initial status + auto-connect if we already have a token
  useEffect(() => {
    (async () => {
      try {
        let s = await getStatus();
        if (s.has_credentials && s.has_token && !s.authenticated) {
          try {
            s = await connect();
          } catch {
            /* Discord probably isn't running yet */
          }
        }
        setStatus(s);
        if (s.authenticated) void refreshAll();
      } catch (e) {
        fail("Could not reach the plugin backend", e);
      }
    })();
  }, []);

  // live voice-state/speaking updates pushed from the backend
  useEffect(() => {
    const onVoiceEvent = (evt: string, data: any) => {
      if (evt === "SPEAKING_START") {
        setSpeaking((prev) => {
          const next = new Set(prev);
          next.add(data.user_id);
          return next;
        });
      } else if (evt === "SPEAKING_STOP") {
        setSpeaking((prev) => {
          if (!prev.has(data.user_id)) return prev;
          const next = new Set(prev);
          next.delete(data.user_id);
          return next;
        });
      } else if (evt === "VOICE_STATE_CREATE" || evt === "VOICE_STATE_UPDATE") {
        setMembers((prev) => {
          const idx = prev.findIndex((m) => m.user.id === data.user.id);
          if (idx === -1) return [...prev, data];
          const next = [...prev];
          next[idx] = data;
          return next;
        });
      } else if (evt === "VOICE_STATE_DELETE") {
        setMembers((prev) => prev.filter((m) => m.user.id !== data.user.id));
        setSpeaking((prev) => {
          if (!prev.has(data.user.id)) return prev;
          const next = new Set(prev);
          next.delete(data.user.id);
          return next;
        });
      }
    };

    // Fires on any voice-channel change, from the plugin or Discord itself.
    const onChannelChanged = (_channelId: string | null) => {
      (async () => {
        try {
          const c = await getCurrentChannel();
          setCurrent(c);
          setChannelId(c?.id ?? null);
          await loadMembers(c?.id ?? null);
          await syncSpeaking();
        } catch (e) {
          fail("Could not refresh channel", e);
        }
      })();
    };

    const onConnectStatus = (msg: string) => setConnectStatus(msg);

    // Discord's actual voice connection state, pushed live.
    const onConnectionStatus = (state: string | null) => setRtcState(state);

    // Mute/deafen changed anywhere (the plugin, Discord's own UI, a
    // keybind) — keep the toggles and your own tile honest.
    const onVoiceSettings = (flags: { mute: boolean; deaf: boolean }) => {
      setVoice((v) => (v ? { ...v, mute: flags.mute, deaf: flags.deaf } : v));
      const selfId = statusRef.current?.user?.id;
      if (selfId) {
        setMembers((prev) =>
          prev.map((m) =>
            m.user.id === selfId
              ? {
                  ...m,
                  voice_state: {
                    suppress: false,
                    ...(m.voice_state ?? {}),
                    mute: flags.mute,
                    deaf: flags.deaf,
                    self_mute: flags.mute,
                    self_deaf: flags.deaf,
                  },
                }
              : m,
          ),
        );
      }
    };

    addEventListener("voice_event", onVoiceEvent);
    addEventListener("channel_changed", onChannelChanged);
    addEventListener("connect_status", onConnectStatus);
    addEventListener("connection_status", onConnectionStatus);
    addEventListener("voice_settings", onVoiceSettings);
    return () => {
      removeEventListener("connection_status", onConnectionStatus);
      removeEventListener("voice_settings", onVoiceSettings);
      removeEventListener("voice_event", onVoiceEvent);
      removeEventListener("channel_changed", onChannelChanged);
      removeEventListener("connect_status", onConnectStatus);
    };
  }, []);

  async function refreshAll() {
    try {
      const [g, c, v] = await Promise.all([getGuilds(), getCurrentChannel(), getVoiceSettings()]);
      setGuilds(g);
      setCurrent(c);
      setVoice(v);
      voiceRef.current = v;
      if (c?.id) setChannelId(c.id);
      await loadMembers(c?.id ?? null);
      await syncSpeaking();
      setRtcState(await getVoiceConnectionStatus());
      const firstGuild = guildId ?? g[0]?.id ?? null;
      setGuildId(firstGuild);
      if (firstGuild) setChannels(await getVoiceChannels(firstGuild));
    } catch (e) {
      fail("Could not read Discord state", e);
    }
    try {
      setSystem(await getSystemDevices());
    } catch (e) {
      fail("Could not read audio devices", e);
    }
  }

  if (!status) {
    return (
      <PanelSection>
        <PanelSectionRow>
          <Spinner style={{ width: "40px", alignSelf: "center" }} />
        </PanelSectionRow>
      </PanelSection>
    );
  }

  if (!status.has_credentials) {
    return <Setup status={status} onSaved={setStatus} />;
  }

  if (!status.authenticated) {
    return (
      <PanelSection title="Discord">
        <PanelSectionRow>
          <Field
            description={
              connectStatus ||
              "If Discord isn't already running, Connect/Authorize will try to start it in the background automatically. First-time authorizing shows a consent window inside the Discord client, so do that in desktop mode."
            }
            focusable
          />
        </PanelSectionRow>
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              setConnectStatus("");
              try {
                const s = status.has_token ? await connect() : await authorize();
                setStatus(s);
                if (s.authenticated) await refreshAll();
              } catch (e) {
                fail("Connection failed", e);
              } finally {
                setBusy(false);
                setConnectStatus("");
              }
            }}
          >
            {status.has_token ? "Connect to Discord" : "Authorize with Discord"}
          </ButtonItem>
        </PanelSectionRow>
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              try {
                await launchDiscord();
                toaster.toast({ title: "Starting Discord", body: "It should be ready in a few seconds." });
              } catch (e) {
                fail("Could not start Discord", e);
              } finally {
                setBusy(false);
              }
            }}
          >
            Launch Discord in background
          </ButtonItem>
        </PanelSectionRow>
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            onClick={async () => {
              try {
                setStatus(await setCredentials("", ""));
              } catch (e) {
                fail("Could not clear credentials", e);
              }
            }}
          >
            Change app credentials
          </ButtonItem>
        </PanelSectionRow>
      </PanelSection>
    );
  }

  const user = status.user?.global_name || status.user?.username || "Discord";

  return (
    <>
      <PanelSection title="Voice">
        <PanelSectionRow>
          <Field
            label="In call"
            bottomSeparator="none"
            description={
              current
                ? voice?.deaf
                  ? "⚠ You're deafened — you won't hear anyone or see who's talking"
                  : (() => {
                      const r = describeRtc(rtcState);
                      return r ? `${r.ok ? "●" : "⚠"} ${r.text}` : undefined;
                    })()
                : undefined
            }
          >
            {current?.name ?? "Not connected"}
          </Field>
        </PanelSectionRow>

        {current && members.length > 0 && (
          <PanelSectionRow>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 10, justifyContent: "flex-start", padding: "6px 0 2px" }}>
              {members.map((m) => (
                <PartyMember
                  key={m.user.id}
                  vs={m}
                  speaking={speaking.has(m.user.id)}
                  ringColor={status.ring_color}
                />
              ))}
            </div>
          </PanelSectionRow>
        )}

        <PanelSectionRow>
          <DropdownItem
            label="Server"
            rgOptions={guilds.map((g) => ({ data: g.id, label: <GuildOptionLabel guild={g} /> }))}
            selectedOption={guildId}
            onChange={async (opt) => {
              setGuildId(opt.data);
              setChannelId(null);
              try {
                setChannels(await getVoiceChannels(opt.data));
              } catch (e) {
                fail("Could not list channels", e);
              }
            }}
          />
        </PanelSectionRow>

        <PanelSectionRow>
          <DropdownItem
            label="Channel"
            rgOptions={channels.map((c) => ({
              data: c.id,
              label: c.member_count != null ? `${c.name} (${c.member_count})` : c.name,
            }))}
            selectedOption={channelId}
            onChange={(opt) => setChannelId(opt.data)}
          />
        </PanelSectionRow>

        <PanelSectionRow>
          <ButtonItem
            layout="below"
            disabled={busy || !channelId}
            onClick={async () => {
              setBusy(true);
              try {
                await joinChannel(channelId!);
                setCurrent(await getCurrentChannel());
                await loadMembers(channelId!);
              } catch (e) {
                fail("Could not join", e);
              } finally {
                setBusy(false);
              }
            }}
          >
            Join channel
          </ButtonItem>
        </PanelSectionRow>

        <PanelSectionRow>
          <ButtonItem
            layout="below"
            disabled={busy || !current}
            onClick={async () => {
              setBusy(true);
              try {
                await leaveChannel();
                setCurrent(await getCurrentChannel());
                await loadMembers(null);
              } catch (e) {
                fail("Could not leave", e);
              } finally {
                setBusy(false);
              }
            }}
          >
            Leave channel
          </ButtonItem>
        </PanelSectionRow>

        <PanelSectionRow>
          <ToggleField
            label="Mute"
            checked={!!voice?.mute}
            onChange={async (value) => {
              try {
                setVoice(await patchVoiceSettings({ mute: value }));
              } catch (e) {
                fail("Could not change mute", e);
              }
            }}
          />
        </PanelSectionRow>
        <PanelSectionRow>
          <ToggleField
            label="Deafen"
            checked={!!voice?.deaf}
            onChange={async (value) => {
              try {
                setVoice(await patchVoiceSettings({ deaf: value }));
              } catch (e) {
                fail("Could not change deafen", e);
              }
            }}
          />
        </PanelSectionRow>

        <PanelSectionRow>
          <ButtonItem
            layout="below"
            description="Can't hear anyone? This resets the plugin's link to Discord, same as reloading Decky."
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              try {
                const s = await resetConnection();
                setStatus(s);
                if (s.authenticated) await refreshAll();
                toaster.toast({ title: "Discord Deck", body: "Reconnected to Discord" });
              } catch (e) {
                fail("Reconnect failed", e);
              } finally {
                setBusy(false);
              }
            }}
          >
            Reconnect audio
          </ButtonItem>
        </PanelSectionRow>
      </PanelSection>

      <PanelSection title="Discord audio">
        <PanelSectionRow>
          <DropdownItem
            label="Microphone"
            rgOptions={(voice?.input_devices ?? []).map((d) => ({ data: d.id, label: d.name }))}
            selectedOption={voice?.input_device_id}
            onChange={async (opt) => {
              try {
                setVoice(await patchVoiceSettings({ input_device_id: opt.data }));
              } catch (e) {
                fail("Could not change microphone", e);
              }
            }}
          />
        </PanelSectionRow>
        <PanelSectionRow>
          <DropdownItem
            label="Output"
            rgOptions={(voice?.output_devices ?? []).map((d) => ({ data: d.id, label: d.name }))}
            selectedOption={voice?.output_device_id}
            onChange={async (opt) => {
              try {
                setVoice(await patchVoiceSettings({ output_device_id: opt.data }));
              } catch (e) {
                fail("Could not change output", e);
              }
            }}
          />
        </PanelSectionRow>
        <PanelSectionRow>
          <SliderField
            label="Mic volume"
            value={Math.round(voice?.input_volume ?? 100)}
            min={0}
            max={100}
            step={1}
            showValue
            onChange={(value) => {
              setVoice((v) => (v ? { ...v, input_volume: value } : v));
              if (volumeTimer.current) window.clearTimeout(volumeTimer.current);
              volumeTimer.current = window.setTimeout(() => {
                patchVoiceSettings({ input_volume: value }).catch((e) =>
                  fail("Could not change mic volume", e),
                );
              }, 400);
            }}
          />
        </PanelSectionRow>
      </PanelSection>

      <PanelSection title="System audio">
        <PanelSectionRow>
          <DropdownItem
            key={`sink-${system?.default_sink_id ?? "none"}`}
            label="Output device"
            rgOptions={(system?.sinks ?? []).map((n) => ({ data: n.id, label: n.label }))}
            selectedOption={system?.default_sink_id ?? undefined}
            onChange={async (opt) => {
              try {
                setSystem(await setSystemDefault(opt.data));
              } catch (e) {
                fail("Could not set output device", e);
              }
            }}
          />
        </PanelSectionRow>
        <PanelSectionRow>
          <DropdownItem
            key={`source-${system?.default_source_id ?? "none"}`}
            label="Input device"
            rgOptions={(system?.sources ?? []).map((n) => ({ data: n.id, label: n.label }))}
            selectedOption={system?.default_source_id ?? undefined}
            onChange={async (opt) => {
              try {
                setSystem(await setSystemDefault(opt.data));
              } catch (e) {
                fail("Could not set input device", e);
              }
            }}
          />
        </PanelSectionRow>
      </PanelSection>

      <PanelSection title={`Signed in as ${user}`}>
        <PanelSectionRow>
          <ButtonItem layout="below" disabled={busy} onClick={() => refreshAll()}>
            Refresh
          </ButtonItem>
        </PanelSectionRow>
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            onClick={async () => {
              try {
                setStatus(await signOut());
              } catch (e) {
                fail("Could not sign out", e);
              }
            }}
          >
            Sign out
          </ButtonItem>
        </PanelSectionRow>
      </PanelSection>

      <PanelSection title="Appearance">
        <PanelSectionRow>
          <DropdownItem
            label="Speaking ring color"
            rgOptions={RING_COLOR_PRESETS.map(({ color, name }) => ({
              data: color,
              label: <ColorOptionLabel color={color} name={name} />,
            }))}
            selectedOption={status.ring_color}
            onChange={async (opt) => {
              try {
                setStatus(await setRingColor(opt.data));
              } catch (e) {
                fail("Could not save ring color", e);
              }
            }}
          />
        </PanelSectionRow>
      </PanelSection>
    </>
  );
}

export default definePlugin(() => ({
  name: "Discord Deck",
  titleView: <div className={staticClasses.Title}>Discord Deck</div>,
  content: <Content />,
  icon: <FaHeadset />,
}));
