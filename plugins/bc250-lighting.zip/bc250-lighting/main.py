"""BC-250 Fans: two 12-LED ARGB fans on a Nollie 1 single-channel controller.

The Nollie is written to directly over /dev/hidraw, so there is no OpenRGB
server, no AppImage and no udev rules involved. Decky runs this backend as
root, which is what makes that possible.

The front strip is deliberately not handled here -- it belongs to the
bc250_ws2812b_controller daemon and its own working plugin.
"""

import asyncio
import json
import os
import time

import decky

import effects
import idle
import nollie
import strip

SETTINGS_DIR = getattr(decky, "DECKY_PLUGIN_SETTINGS_DIR", "/tmp/bc250-fans")
SETTINGS_PATH = os.path.join(SETTINGS_DIR, "fans.json")
FRAME_RATE = 30

# Bumped whenever the shape of the settings changes. The OpenRGB-era build
# stored "channel" as a dict; this one needs an int. Both plugins share a name,
# so they share a settings directory, and a blind merge let the stale dict
# through -- which made every frame raise TypeError and the fans never lit.
SETTINGS_VERSION = 3

DEFAULT_SETTINGS = {
    "version": SETTINGS_VERSION,
    "leds": 24,
    "channel": 0,
    "budget_ma": 700,
    "auto_layout": True,
    "enabled": True,
    "span": False,
    "selected": "fans_all",
    "view": "strip",
    "keep_download": True,
    "sync_color": True,
    # Turn the strip and fans off after this long with no controller,
    # keyboard or mouse input -- the same thing Steam's dim timer counts.
    "standby": True,
    "standby_minutes": 5,
    "zones": [
        {
            "id": "fan_a",
            "name": "Fan A",
            "channel": 0,
            "offset": 0,
            "count": 12,
            "effect": "rainbow",
            "color": [255, 0, 0],
            "brightness": 60,
            "enabled": True,
        },
        {
            "id": "fan_b",
            "name": "Fan B",
            "channel": 0,
            "offset": 12,
            "count": 12,
            "effect": "rainbow",
            "color": [255, 0, 0],
            "brightness": 60,
            "enabled": True,
        },
    ],
}


def _sanitise(stored):
    """Merge stored settings over the defaults, rejecting anything of the
    wrong shape.

    A settings file written by an older build can contain values this build
    cannot use. Taking them blindly is how a dict ended up where an int was
    expected, so every key is checked against the type of its default and
    dropped if it does not match.
    """
    base = json.loads(json.dumps(DEFAULT_SETTINGS))

    if not isinstance(stored, dict):
        return base
    if stored.get("version") != SETTINGS_VERSION:
        # Shape changed since this was written. Start clean rather than guess
        # which individual keys still mean the same thing.
        return base

    for key, default in base.items():
        if key == "version" or key not in stored:
            continue
        value = stored[key]

        if key == "zones":
            zones = _sanitise_zones(value, base["zones"])
            if zones:
                base[key] = zones
        elif isinstance(default, bool):
            if isinstance(value, bool):
                base[key] = value
        elif isinstance(default, int):
            if isinstance(value, int) and not isinstance(value, bool):
                base[key] = value
        elif isinstance(default, str):
            if isinstance(value, str):
                base[key] = value

    base["leds"] = max(1, min(1024, base["leds"]))
    base["channel"] = max(0, min(31, base["channel"]))
    base["budget_ma"] = max(50, min(5000, base["budget_ma"]))
    base["standby_minutes"] = max(1, min(60, base["standby_minutes"]))
    return base


def _sanitise_zones(value, defaults):
    if not isinstance(value, list) or len(value) != len(defaults):
        return None

    cleaned = []
    for stored_zone, default_zone in zip(value, defaults):
        zone = dict(default_zone)
        if isinstance(stored_zone, dict):
            for field, fallback in default_zone.items():
                if field not in stored_zone:
                    continue
                got = stored_zone[field]
                if field == "color":
                    if (
                        isinstance(got, (list, tuple))
                        and len(got) == 3
                        and all(isinstance(c, int) and 0 <= c <= 255 for c in got)
                    ):
                        zone[field] = list(got)
                elif isinstance(fallback, bool):
                    if isinstance(got, bool):
                        zone[field] = got
                elif isinstance(fallback, int):
                    if isinstance(got, int) and not isinstance(got, bool):
                        zone[field] = got
                elif isinstance(fallback, str):
                    if isinstance(got, str):
                        zone[field] = got
        cleaned.append(zone)
    return cleaned


def _hex_to_rgb(hexed):
    hexed = str(hexed).lstrip("#")
    return (
        int(hexed[0:2], 16),
        int(hexed[2:4], 16),
        int(hexed[4:6], 16),
    )


def _rgb_to_hex(rgb):
    return "%02x%02x%02x" % (rgb[0], rgb[1], rgb[2])


class Plugin:
    async def _main(self):
        self.error = None
        self.device = None
        self.dev = None
        self._identify = None
        self._task = None
        self._dirty = True
        self._strip_cache = None
        self._strip_cache_at = 0.0
        self._strip_good = None
        self._strip_dirty = False
        self.frames = 0
        self.last_write_error = None
        self.last_frame_at = 0.0
        self.standby = False
        self.idle = idle.IdleWatcher()
        self._clear_standby_flag()

        try:
            self.settings = self._load()
        except Exception as exc:  # noqa: BLE001
            self.settings = json.loads(json.dumps(DEFAULT_SETTINGS))
            decky.logger.error("settings load failed: %s", exc)

        self._attach()
        self._task = asyncio.create_task(self._loop())
        self.idle.start()
        self._standby_task = asyncio.create_task(self._standby_loop())
        decky.logger.info("BC-250 Fans started")

    async def _unload(self):
        if self._task:
            self._task.cancel()
        if getattr(self, "_standby_task", None):
            self._standby_task.cancel()
        self.idle.stop()
        self._clear_standby_flag()
        try:
            if self.dev:
                self._push(self._blank())
                self.dev.close()
        except Exception:  # noqa: BLE001
            pass
        decky.logger.info("BC-250 Fans stopped")

    # -------------------------------------------------------------- hardware

    def _attach(self):
        """Find the controller and open it. Records why if it cannot."""
        if self.dev:
            self.dev.close()
            self.dev = None

        try:
            devices = nollie.find_devices()
        except Exception as exc:  # noqa: BLE001
            self.error = "scan failed: %s" % exc
            return False

        if not devices:
            self.device = None
            self.error = (
                "no Nollie controller found. Check it is plugged in and "
                "appears in lsusb as 16d2:1f11, 16d5:1f11 or 16d5:2a01."
            )
            return False

        self.device = devices[0]

        if not self.device["writable"] and os.geteuid() != 0:
            self.error = "%s is not writable; the plugin needs root" % self.device["path"]
            return False

        try:
            self.dev = nollie.Nollie(self.device["path"], self.device["pid"])
            self.dev.open()
            self._auto_layout()
            self._declare_leds()
            self.error = None
            return True
        except OSError as exc:
            self.dev = None
            self.error = "could not open %s: %s" % (self.device["path"], exc)
            return False

    def _auto_layout(self):
        """Put one fan per channel on a multi-channel controller.

        A single-header controller has to chain both fans and split them by
        offset. A Nollie 8 gives each fan its own header, which is simpler and
        lets them differ in length. Only runs while the layout is still
        untouched, so a hand-picked channel is never overwritten.
        """
        if not self.settings.get("auto_layout", True) or not self.device:
            return

        channels = int(self.device.get("channels", 1))
        zones = self.settings["zones"]
        chained = all(int(z.get("channel", 0)) == 0 for z in zones)

        if channels > 1 and chained and len(zones) > 1:
            for index, zone in enumerate(zones):
                zone["channel"] = index
                zone["offset"] = 0
            decky.logger.info("multi-channel controller: one fan per channel")
        elif channels == 1 and not chained:
            offset = 0
            for zone in zones:
                zone["channel"] = 0
                zone["offset"] = offset
                offset += int(zone.get("count", 12))
            decky.logger.info("single-channel controller: chained the fans")
        else:
            return

        # SATA-powered models are not limited the way a bus-powered one is
        if self.device.get("power") == "sata" and self.settings["budget_ma"] <= 700:
            self.settings["budget_ma"] = 2400
        self.settings["auto_layout"] = False
        self._save()

    def _channel_leds(self):
        """LEDs to declare per channel, from wherever each zone ends."""
        counts = {}
        for zone in self.settings["zones"]:
            ch = int(zone.get("channel", 0))
            end = int(zone.get("offset", 0)) + int(zone.get("count", 0))
            counts[ch] = max(counts.get(ch, 0), end)
        return counts

    def _declare_leds(self):
        counts = [0] * max(1, int(self.device.get("channels", 1)) if self.device else 1)
        for channel, leds in self._channel_leds().items():
            if 0 <= channel < len(counts):
                counts[channel] = leds
        self.dev.set_led_counts(counts)

    # ------------------------------------------------------------ persistence

    def _load(self):
        try:
            with open(SETTINGS_PATH, "r", encoding="utf-8") as handle:
                stored = json.load(handle)
        except (OSError, ValueError):
            return json.loads(json.dumps(DEFAULT_SETTINGS))
        return _sanitise(stored)

    def _save(self):
        try:
            os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)
            with open(SETTINGS_PATH, "w", encoding="utf-8") as handle:
                json.dump(self.settings, handle, indent=2)
        except OSError as exc:
            decky.logger.error("could not save settings: %s", exc)

    # ------------------------------------------------------------ render loop

    async def _loop(self):
        interval = 1.0 / FRAME_RATE
        started = time.monotonic()
        retry_at = 0.0

        while True:
            now = time.monotonic()
            try:
                if not self.dev:
                    # Reattach periodically so unplugging and replugging the
                    # controller recovers without restarting the plugin.
                    if now >= retry_at:
                        retry_at = now + 3.0
                        self._attach()
                elif self.settings.get("enabled", True) and not self.standby:
                    self._push(self._compose(now - started))
                elif self._dirty:
                    self._push(self._blank())
                    self._dirty = False
            except OSError as exc:
                decky.logger.warning("write failed, will reattach: %s", exc)
                self.error = "write failed: %s" % exc
                self.last_write_error = str(exc)
                if self.dev:
                    self.dev.close()
                self.dev = None
                retry_at = now + 3.0
            except Exception as exc:  # noqa: BLE001
                # Anything non-OSError here means the frame never reached the
                # device and the cause is in our own code, so record it rather
                # than silently looping.
                decky.logger.exception("render failed")
                self.last_write_error = "%s: %s" % (type(exc).__name__, exc)
                await asyncio.sleep(1.0)

            await asyncio.sleep(interval)

    # --------------------------------------------------------------- standby

    @staticmethod
    def _clear_standby_flag():
        try:
            os.remove(strip.STANDBY_FLAG)
        except FileNotFoundError:
            pass
        except OSError as exc:
            decky.logger.warning("could not clear standby flag: %s", exc)

    def _enter_standby(self):
        self.standby = True
        self._dirty = True
        try:
            with open(strip.STANDBY_FLAG, "w"):
                pass
        except OSError as exc:
            decky.logger.warning("could not set standby flag: %s", exc)
        decky.logger.info("idle: lights off")

    def _leave_standby(self):
        self.standby = False
        self._dirty = True
        self._clear_standby_flag()
        decky.logger.info("input: lights back on")

    async def _standby_loop(self):
        # Put the strip's rule in once, off the startup path: it restarts the
        # daemon, and a slow restart must not hold up the plugin loading.
        rule_ok = False
        while True:
            try:
                wanted = self.settings.get("standby", True)
                if wanted and not rule_ok:
                    rule_ok = bool(await asyncio.to_thread(strip.set_standby_rule, True))
                limit = self.settings.get("standby_minutes", 5) * 60
                idle_for = self.idle.idle_seconds()
                if self.standby and (not wanted or idle_for < limit):
                    self._leave_standby()
                elif not self.standby and wanted and idle_for >= limit:
                    self._enter_standby()
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                decky.logger.exception("standby check failed")
            await asyncio.sleep(1.0)

    def _compose(self, t):
        """Render every zone into its own channel's framebuffer.

        Returns channel -> pixel list. The current ceiling is applied across
        the union at the end, not per channel: the channels share one supply,
        so the total is what the budget is about.
        """
        frames = {ch: [(0, 0, 0)] * leds for ch, leds in self._channel_leds().items()}

        if self._identify and time.monotonic() > self._identify[1]:
            self._identify = None
        identify_id = self._identify[0] if self._identify else None

        zones = sorted(
            self.settings["zones"],
            key=lambda z: (int(z.get("channel", 0)), int(z.get("offset", 0))),
        )

        # span mode treats every fan as one continuous ring, so the effect is
        # rendered once at the combined length and then sliced back out
        span = self.settings.get("span") and not identify_id and zones
        span_pixels = None
        if span:
            lead = zones[0]
            total = sum(int(z["count"]) for z in zones)
            span_pixels = effects.clamp(
                effects.render(
                    lead.get("effect", "solid"),
                    total,
                    lead.get("color", [255, 255, 255]),
                    t,
                ),
                lead.get("brightness", 60),
                0,
            )

        cursor = 0
        for zone in zones:
            count = int(zone["count"])
            channel = int(zone.get("channel", 0))
            offset = int(zone.get("offset", 0))

            if identify_id:
                if zone["id"] != identify_id:
                    cursor += count
                    continue
                pixels = effects.clamp([(255, 255, 255)] * count, 70, 0)
            elif span:
                pixels = span_pixels[cursor : cursor + count]
                if not zone.get("enabled", True):
                    pixels = [(0, 0, 0)] * count
            else:
                if not zone.get("enabled", True):
                    cursor += count
                    continue
                pixels = effects.render(
                    zone.get("effect", "solid"),
                    count,
                    zone.get("color", [255, 255, 255]),
                    t,
                )
                pixels = effects.clamp(pixels, zone.get("brightness", 60), 0)

            cursor += count
            frame = frames.get(channel)
            if frame is None:
                continue
            for i, pixel in enumerate(pixels):
                index = offset + i
                if 0 <= index < len(frame):
                    frame[index] = pixel

        return self._budget(frames)

    def _budget(self, frames):
        budget = self.settings.get("budget_ma", 0)
        if budget <= 0:
            return frames
        draw = sum(effects.estimate_ma(f) for f in frames.values())
        if draw <= budget:
            return frames
        headroom = budget / draw
        return {
            ch: [
                (int(r * headroom), int(g * headroom), int(b * headroom))
                for r, g, b in frame
            ]
            for ch, frame in frames.items()
        }

    def _push(self, frames):
        self.dev.show_many(frames)
        self.frames += 1
        self.last_frame_at = time.monotonic()

    def _blank(self):
        return {ch: [(0, 0, 0)] * leds for ch, leds in self._channel_leds().items()}

    # -------------------------------------------------------- frontend methods

    async def get_state(self):
        return {
            "error": self.error,
            "device": self.device,
            "connected": self.dev is not None,
            "enabled": self.settings.get("enabled", True),
            "leds": self.settings["leds"],
            "span": self.settings.get("span", False),
            "selected": self.settings.get("selected", "fans_all"),
            "view": self.settings.get("view", "strip"),
            "keep_download": self.settings.get("keep_download", True),
            "sync_color": self.settings.get("sync_color", True),
            "frames": self.frames,
            "strip": await self._strip_state(),
            "budget_ma": self.settings["budget_ma"],
            "zones": self.settings["zones"],
            "channels": int(self.device.get("channels", 1)) if self.device else 1,
            "power_source": self.device.get("power", "usb") if self.device else "usb",
            "budget_ma": self.settings.get("budget_ma", 0),
            "power": self._power(),
            "standby": self.settings.get("standby", True),
            "standby_minutes": self.settings.get("standby_minutes", 5),
            "standby_active": self.standby,
        }

    async def reattach(self):
        ok = self._attach()
        return {"ok": ok, "error": self.error, "device": self.device}

    async def diagnostics(self):
        """Everything needed to tell where the fan pipeline stops."""
        report = {
            "root": os.geteuid() == 0,
            "euid": os.geteuid(),
            "devices": [],
            "holders": [],
            "connected": self.dev is not None,
            "frames": self.frames,
            "seconds_since_frame": (
                round(time.monotonic() - self.last_frame_at, 1)
                if self.last_frame_at
                else None
            ),
            "last_write_error": self.last_write_error,
            "error": self.error,
            "enabled": self.settings.get("enabled", True),
            "leds": self.settings["leds"],
            "channel": self.settings["channel"],
        }
        try:
            report["devices"] = await asyncio.to_thread(nollie.find_devices)
            if report["devices"]:
                report["holders"] = await asyncio.to_thread(
                    nollie.holders, report["devices"][0]["path"]
                )
        except Exception as exc:  # noqa: BLE001
            report["scan_error"] = str(exc)
        return report

    async def self_test(self):
        """Drive the fans straight from the backend, bypassing the render loop.

        Separates "the backend cannot write to the device" from "the render
        loop or its settings are wrong" -- the same sequence the standalone
        probe runs, but through the plugin's own code path.
        """
        if not self.dev and not self._attach():
            return {"ok": False, "stage": "attach", "error": self.error}

        counts = self._channel_leds()
        total = sum(counts.values())
        steps = [
            ("red", (80, 0, 0)),
            ("green", (0, 80, 0)),
            ("blue", (0, 0, 80)),
        ]
        try:
            await asyncio.to_thread(self._declare_leds)
            for _, colour in steps:
                await asyncio.to_thread(
                    self.dev.show_many,
                    {ch: [colour] * n for ch, n in counts.items()},
                )
                await asyncio.sleep(1.0)

            # one channel at a time, so a miswired header shows up
            for ch in sorted(counts):
                frames = {c: [(0, 0, 0)] * n for c, n in counts.items()}
                frames[ch] = [(80, 80, 80)] * counts[ch]
                await asyncio.to_thread(self.dev.show_many, frames)
                await asyncio.sleep(1.2)

            return {
                "ok": True,
                "channels": {str(c + 1): n for c, n in sorted(counts.items())},
                "leds": total,
                "path": self.device["path"] if self.device else None,
            }
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "stage": "write",
                    "error": "%s: %s" % (type(exc).__name__, exc)}

    async def scan(self):
        """Every Nollie the system can see, for troubleshooting."""
        try:
            return {"ok": True, "devices": nollie.find_devices()}
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "error": str(exc)}

    async def set_zone(self, zone_id, patch):
        for zone in self.settings["zones"]:
            if zone["id"] == zone_id:
                zone.update(patch)
                self._save()
                return zone
        return None

    # ---------------------------------------------------------------- strip
    #
    # Every one of these shells out, so they always run off the event loop.

    async def _strip_state(self, force=False):
        now = time.monotonic()
        if force or self._strip_cache is None or now - self._strip_cache_at > 2.5:
            self._strip_cache = await asyncio.to_thread(strip.get_state)
            self._strip_cache_at = now
            if self._strip_cache.get("ok"):
                self._strip_good = self._strip_cache
        return self._strip_cache

    async def _settled_strip_state(self, attempts=5, delay=0.35):
        """Read the strip only once the daemon is answering again.

        _apply_config restarts led-controller, and for a moment afterwards
        `led --list` fails. get_state() then returns its blank fallback --
        no effect, no effects list, no colour key. Handing that straight back
        to the panel wiped the real values and left the dropdown showing
        "Automatic" until the panel was reopened, which is exactly the bug.
        """
        degraded = None
        for _ in range(attempts):
            state = await self._strip_state(force=True)
            # "ok" only means the daemon answered. The unit can still be
            # mid-transition, and reporting "activating" as not-running is what
            # made the panel flip its own toggle off after every change.
            if state.get("ok") and state.get("service") not in strip.TRANSITIONAL:
                return state
            degraded = state
            await asyncio.sleep(delay)

        # Still not answering. A transient failure must never replace a
        # known-good snapshot; report it alongside instead.
        # A settled-enough reading still beats a stale one: if the daemon
        # answered but the unit never left its transition, use that.
        if degraded and degraded.get("ok"):
            return degraded
        if self._strip_good:
            carried = dict(self._strip_good)
            carried["transient_error"] = (degraded or {}).get("error")
            return carried
        return degraded or await self._strip_state()

    async def _strip_for_panel(self):
        """State for get_state: settle only if a change is pending."""
        if self._strip_dirty:
            self._strip_dirty = False
            return await self._settled_strip_state()
        return await self._strip_state()

    def _invalidate_strip(self):
        self._strip_cache_at = 0.0

    # ------------------------------------------------------------------ sync

    async def set_sync(self, enabled):
        self.settings["sync_color"] = bool(enabled)
        self._save()
        return self.settings["sync_color"]

    async def set_color(self, hexed, scope):
        """Colour from the fan section. Mirrors to the strip when sync is on."""
        if not hexed:
            return {"ok": False, "error": "fans need an actual colour"}

        hexed = str(hexed).lstrip("#").lower()[:6]
        rgb = list(_hex_to_rgb(hexed))

        for zone in self.settings["zones"]:
            if scope == "fans_all" or zone["id"] == scope:
                zone["color"] = rgb
        self._save()

        if self.settings.get("sync_color", True):
            state = await self._strip_state()
            if state.get("ok") and state.get("colorKey"):
                await asyncio.to_thread(strip.set_color, hexed, state.get("color2"))
                self._invalidate_strip()
                return {"ok": True, "synced": True}
        return {"ok": True, "synced": False}

    async def strip_set_keep_download(self, keep):
        """Whether a download rule outranks the pinned effect."""
        self.settings["keep_download"] = bool(keep)
        self._save()
        ok = await asyncio.to_thread(strip.move_override, self.settings["keep_download"])
        self._invalidate_strip()
        return bool(ok)

    async def strip_set_effect(self, name, color=None, color2=None):
        """Same shape the standalone Front Strip plugin used: the panel passes
        the colours it already has, and re-reads state itself afterwards."""
        if self.settings.get("sync_color", True) and self.settings["zones"]:
            color = _rgb_to_hex(self.settings["zones"][0]["color"])
        ok = await asyncio.to_thread(
            strip.set_effect, name, color, color2,
            self.settings.get("keep_download", True),
        )
        self._invalidate_strip()
        return bool(ok)

    async def strip_set_color(self, hexed, hex2=None):
        hexed = str(hexed).lstrip("#").lower()[:6] if hexed else None
        hex2 = str(hex2).lstrip("#").lower()[:6] if hex2 else None
        ok = await asyncio.to_thread(strip.set_color, hexed, hex2)
        self._invalidate_strip()

        # sync sends the same colour to the fans, which need no restart
        if hexed and self.settings.get("sync_color", True):
            rgb = list(_hex_to_rgb(hexed))
            for zone in self.settings["zones"]:
                zone["color"] = rgb
            self._save()
        return bool(ok)

    async def strip_set_brightness(self, percent):
        """Takes 0-100 from the panel; the daemon stores 0..1."""
        value = max(0.0, min(1.0, float(percent) / 100.0))
        ok = await asyncio.to_thread(strip.set_brightness, value)
        self._invalidate_strip()
        return bool(ok)

    async def strip_set_reverse(self, on):
        ok = await asyncio.to_thread(strip.set_reverse, on)
        self._invalidate_strip()
        return bool(ok)

    async def strip_set_power(self, on):
        ok = await asyncio.to_thread(strip.set_power, on)
        self._invalidate_strip()
        return bool(ok)

    async def strip_refresh(self):
        """The panel's own read, waiting out a daemon restart if one is in
        progress rather than reporting the blank fallback.

        Copied before annotating so the cached snapshot stays clean.
        """
        state = dict(await self._settled_strip_state())
        state["keepDownload"] = self.settings.get("keep_download", True)
        return state

    async def set_view(self, view):
        """Which device the panel is showing. Stored here for the same reason
        the fan selection is: local React state does not survive a remount."""
        if view not in ("strip", "fans"):
            return self.settings.get("view", "strip")
        self.settings["view"] = view
        self._save()
        return view

    async def set_selected(self, target):
        """Remember which fan the panel is editing."""
        valid = {"fans_all", "strip"} | {z["id"] for z in self.settings["zones"]}
        if target not in valid:
            return self.settings.get("selected", "fans_all")
        self.settings["selected"] = target
        self._save()
        return target

    async def set_all(self, patch):
        """Apply one change to every fan at once."""
        for zone in self.settings["zones"]:
            zone.update(patch)
        self._save()
        return self.settings["zones"]

    async def set_span(self, span):
        self.settings["span"] = bool(span)
        self._save()
        return self.settings["span"]

    async def set_enabled(self, enabled):
        self.settings["enabled"] = bool(enabled)
        self._dirty = True
        self._save()
        return self.settings["enabled"]

    async def set_standby(self, enabled):
        self.settings["standby"] = bool(enabled)
        self._save()
        # Leaving the rule in would cost nothing while the flag file is
        # absent, but take it out when switched off so the config reads as
        # the user expects.
        await asyncio.to_thread(strip.set_standby_rule, bool(enabled))
        return self.settings["standby"]

    async def set_standby_minutes(self, minutes):
        self.settings["standby_minutes"] = max(1, min(60, int(minutes)))
        self.idle.poke()
        self._save()
        return self.settings["standby_minutes"]

    async def set_budget(self, value):
        self.settings["budget_ma"] = max(50, int(value))
        self._save()
        return self.settings["budget_ma"]

    async def set_leds(self, count):
        """Resize the chain. Splits evenly between the fans when they share a
        channel; when each has its own, both get the full count."""
        count = max(1, int(count))
        self.settings["leds"] = count
        zones = self.settings["zones"]
        shared = len({int(z.get("channel", 0)) for z in zones}) == 1

        if shared and len(zones) == 2:
            half = count // 2
            zones[0]["offset"], zones[0]["count"] = 0, half
            zones[1]["offset"], zones[1]["count"] = half, count - half
        else:
            for zone in zones:
                zone["offset"] = 0
                zone["count"] = count
        self._save()
        if self.dev:
            try:
                self._declare_leds()
            except OSError as exc:
                decky.logger.warning("could not re-declare LEDs: %s", exc)
        return self.settings["leds"]

    async def set_channel_for(self, zone_id, channel):
        """Move one fan to a different header on the controller."""
        limit = int(self.device.get("channels", 1)) if self.device else 1
        channel = max(0, min(limit - 1, int(channel)))
        for zone in self.settings["zones"]:
            if zone["id"] == zone_id:
                zone["channel"] = channel
                zone["offset"] = 0
                break
        self.settings["auto_layout"] = False
        self._save()
        if self.dev:
            try:
                self._declare_leds()
            except OSError as exc:
                decky.logger.warning("could not re-declare LEDs: %s", exc)
        return {"ok": True, "channel": channel}

    async def identify(self, zone_id, seconds=5):
        self._identify = (zone_id, time.monotonic() + seconds)
        return {"ok": True}

    async def swap(self):
        """Exchange the two fans. Swaps offsets when they share a channel, or
        the channels themselves when each has its own header."""
        zones = self.settings["zones"]
        if len(zones) != 2:
            return {"ok": False}
        if int(zones[0].get("channel", 0)) == int(zones[1].get("channel", 0)):
            zones[0]["offset"], zones[1]["offset"] = zones[1]["offset"], zones[0]["offset"]
        else:
            zones[0]["channel"], zones[1]["channel"] = (
                zones[1]["channel"],
                zones[0]["channel"],
            )
            if self.dev:
                try:
                    self._declare_leds()
                except OSError:
                    pass
        self.settings["auto_layout"] = False
        self._save()
        return {"ok": True}

    def _power(self):
        try:
            budget = self.settings["budget_ma"]
            held = sum(effects.estimate_ma(f) for f in self._compose(0.0).values())
            self.settings["budget_ma"] = 0
            try:
                asked = sum(effects.estimate_ma(f) for f in self._compose(0.0).values())
            finally:
                self.settings["budget_ma"] = budget
            return {
                "ma": round(held),
                "requested_ma": round(asked),
                "budget_ma": budget,
            }
        except Exception:  # noqa: BLE001
            return {"ma": 0, "requested_ma": 0,
                    "budget_ma": self.settings.get("budget_ma", 0)}
