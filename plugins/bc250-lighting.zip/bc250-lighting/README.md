# BC-250 Lighting

One Decky panel for the front LED strip and the ARGB case fans.

Replaces both the standalone **BC-250 Front Strip** and **BC-250 Fans**
plugins. Remove those before installing this, or they will fight over the
same config file and the same USB device.

## Two devices, two mechanisms

**Front strip** — a WS2812B strip on the ESP32, run by the
`bc250_ws2812b_controller` daemon. The daemon owns the serial port and runs
effects on the receiver, so an effect is selected by pinning a catch-all rule
in `/etc/led-controller/config.json` and restarting the unit. Effects come from
`led --list`, so the menu stays correct as the daemon gains new ones. Powered
from the PSU.

**Fans** — two 12-LED fans daisy-chained on a Nollie 1, written to directly
over `/dev/hidraw` using the protocol from OpenRGB's NollieController driver.
No OpenRGB server, no AppImage, no udev rules. Frames are rendered on the host
at 30 fps.

## Controllers

One build covers both machines — the layout follows whichever controller is
attached.

| controller | channels | power    | how the fans sit                    |
| ---------- | -------- | -------- | ----------------------------------- |
| Nollie 1   | 1        | USB bus  | chained: LEDs 1-12 and 13-24        |
| Nollie 8   | 8        | 2x SATA  | one per channel, each starting at 1 |

On a multi-channel controller each fan gets its own header and a **Header**
dropdown appears, labelled Channel 1-8 to match the board. The layout is only
chosen automatically while it has not been set by hand, so a header you pick
sticks.

Frames for every channel are queued and then latched once, so both fans update
on the same frame instead of tearing across them.

**Swap fan order** adapts: it exchanges offsets when the fans share a channel,
and the channels themselves when each has its own. **Flash this fan** blanks
every other channel, so it identifies a fan either way.

The current ceiling defaults by power source: 700 mA for the bus-powered
Nollie 1, 2400 mA for a SATA-powered controller, which one SATA feed supplies
comfortably (rated about 4 A, roughly 100 LEDs). It is applied to the sum
across channels, since they share the supply. Twenty-four LEDs of full white is
1440 mA, so on the Nollie 8 nothing is throttled.

## Fan brightness

The fan slider is perceptual, not linear. Perceived brightness is roughly the
2.2 power of emitted light, so scaling frames linearly wastes most of the
slider — the top third barely changes and the bottom never gets genuinely dim.
Raising the slider position to that power spreads the useful travel evenly:

| slider | 8-bit output | linear would give |
| ------ | ------------ | ----------------- |
| 100%   | 255          | 255               |
| 60%    | 83           | 153               |
| 40%    | 34           | 102               |
| 20%    | 7            | 51                |
| 10%    | 2            | 25                |
| 5%     | 1            | 12                |

The slider runs 1–100 in steps of 1 and reaches 1/255, the dimmest a WS2812B
can show. Below roughly 8% the curve would round to zero, so the frame is
rescaled to put its brightest pixel on 1 instead — the bottom of the slider is
very dim, never an off switch. 0 is still fully off.

Existing settings will look dimmer than before at the same number: 60% used to
mean 153/255 and now means 83. Raise it if you liked the old level.

The strip's brightness is unaffected — that value goes to the daemon, which
does its own scaling.

## Fan effects

A fan is a ring, not a line — LED 0 sits next to LED 11 — so anything that
travels uses modular distance and wraps seamlessly at the seam.

| effect   | what it looks like                                     |
| -------- | ------------------------------------------------------ |
| Solid    | one steady color                                       |
| Glow     | the whole ring drifting slowly around the chosen hue   |
| Breathe  | the ring rising and falling together                   |
| Wave     | two standing brightness waves rotating                 |
| Spin     | a lit arc sweeping round, like a blade catching light  |
| Orbit    | two dots circling opposite each other                  |
| Comet    | a bright head with a fading tail                       |
| Chase    | every third pixel lit, the pattern stepping round      |
| Twinkle  | sparkles fading in and out over a dim base             |
| Fire     | flicker in the chosen hue, hot centres cooling at edges|
| Split    | two complementary halves rotating                      |
| Rainbow  | full hue cycle round the ring                          |
| Off      | dark                                                   |

Rainbow makes its own colors and ignores the picker; the panel says so rather
than leaving a control that does nothing. Split derives its second color from
the one you choose.

In **Treat as one strip** mode the effect renders across all 24 LEDs, so the
pair behaves as one larger ring and a spin sweeps from one fan into the other.

Every effect is a pure function of position and time — nothing carries state
between frames — and each still passes through the current clamp, so even
Solid white stays under the ceiling.

## Effect colour settings

Which key an effect takes its colour through is a table in
`py_modules/strip.py`, because the daemon exposes no way to ask — `led --list`
returns names only. Effects fall into four groups.

**A colour picker** — `solid` and `alarm` take a single `color`; `breathe`,
`comet`, `drift`, `ember`, `pulse`, `aurora`, `shoreline`, `audio_music`,
`audio_ripple`, `audio_spectrum` and `steam_download` ship two or three palette
stops, so one colour (or two with blend) is a fair stand-in.

**Left as designed** — `caustics`, `ink`, `lava`, `load`, `load_boil`,
`orbit`, `plasma`, `silk` and `tide` ship four to six stops, and the palette
*is* the effect: ink sweeps fronts of five inks across each other, lava merges
six, load maps its window onto CPU and GPU load. Replacing that with one or two
stops does not recolour them, it flattens them into something duller. The panel
says how many colours the effect uses instead of offering a picker.

**Makes its own colours** — `rainbow` and `cycle`.

**Unknown** — anything not listed. No control, and the panel says the effect is
newer than the plugin. The table used to default unlisted effects to `palette`,
which gave every new effect a control the daemon ignored.

To reclassify one, move its name between `PALETTE_EFFECTS` and
`FIXED_PALETTE_EFFECTS` at the top of `py_modules/strip.py`.

## Strip orientation

**Flip direction** sets the daemon's `strip.reverse`, which moves LED 0 to the
far end of the strip.

The `steam_download` effect has no direction of its own — its only settings are
`palette` and `done_color` — so the bar's direction comes from the strip's
orientation, not the effect. Flipping the strip is therefore the way to change
which end it fills from.

It flips every directional effect, not just the download bar: comet sweeps the
other way, the audio spectrum grows from the other end. That is the right
behaviour when the case has physically been turned on its side, since the strip
really did change orientation. Centre-based effects (alarm, load, pulse) look
the same either way.

Changing it restarts the daemon, so the boot and shutdown recordings
re-capture in the new orientation too.

## Downloads take over

Rules are evaluated in order and the first match wins, and the pinned rule
matches everything — so pinning an effect used to shadow the download progress
bar entirely.

**Steam downloads take over** inserts the pinned rule *after* the download
rule instead of at the front. The bar plays while a download is running and
the pinned effect resumes when it finishes. Everything else stays below the
pin, so the pinned effect still wins over ordinary rules.

The download rule is found by effect name (`steam_download`) or by its
condition mentioning the download flag, so a renamed rule still works. Only
rules with an `if` are kept above the pin: an unconditional one would match
every time and the pinned effect would never play. If the config has no
download rule at all the toggle is disabled and says so.

## Sync colors

On by default. A color picked in either section is applied to the strip and
both fans. The two sides store color differently — the fans take an RGB triple
per frame, the strip takes a hex string in the daemon's config — so the value
is converted, not shared.

Effects are not synced. The daemon's effect list and the host-rendered fan
effects are different sets with no overlap, so "rainbow" means unrelated things
on each. Strip effects that generate their own colors (`rainbow`, `lava`,
`cycle`) are skipped rather than treated as an error. Palette effects keep
their blend stop; only the first color moves.

Turn sync off to set each independently.

## Controls

Each device has its own section and its own dropdowns.

**Front strip** — effect list from `led --list`, brightness as a percentage,
ten named presets plus **Custom hue** with a hue slider and a swatch showing
the color you are dialling in. Palette effects also get **Blend to**, with its
own hue slider and swatch. **Effect default** hands the color choice back to
the effect. Sliders debounce at 600 ms because every change restarts the
daemon.

**Fans** — **Which fan** selects Both fans, Fan A or Fan B. Same preset and
custom-hue picker, brightness as a percentage. Both fans mode has **Treat as
one strip**: off, each fan runs its own copy of the effect so a rainbow appears
twice; on, the effect renders once across all 24 LEDs and sweeps from one fan
into the next.

Chain order comes from your cabling, not config — **Flash this fan** lights one
and blanks the other, **Swap fan order** fixes it if backwards. The Nollie 1
has one header, so both fans are one 24-LED chain: Fan A is LEDs 1-12, Fan B is
13-24.

## Threading

Everything on the strip side shells out — `led --list`, `systemctl is-active`,
`systemctl restart`. Those calls run in a thread, never on the event loop,
because the fan render loop lives on that loop and any blocking call stalls it.
Strip state is also cached for 2.5 s so a UI poll does not re-run `led --list`
every time.

## Power

The strip is PSU-powered, so nothing to worry about there.

The Nollie 1 is bus-powered over USB. Its 5 V 2.6 A rating is what the
controller can pass, not what a port will give you: 500 mA on USB 2.0, 900 mA
on USB 3.x. Twenty-four WS2812Bs at full white is about 1440 mA, so frames are
scaled to stay under a 700 mA ceiling before transmission. That clamp still
runs; it is just no longer in the UI. To change it, edit `budget_ma` in
`fans.json` in the plugin's Decky settings directory.

## Install

Decky → gear → Settings → General → Developer mode, then Developer tab →
Install Plugin from ZIP. The frontend is prebuilt and there are no Python
dependencies.

Needs root to write `/etc/led-controller/config.json`, call `systemctl`, and
open `/dev/hidraw` — hence `"flags": ["root"]`.

## Troubleshooting

Logs: `cat ~/homebrew/logs/BC-250\ Lighting/plugin.log`

- **"led binary not found"** — the daemon is not installed here, or `led` is
  outside `~/.local/bin`, `/usr/local/bin`, `/usr/bin`. Fix `LED_CANDIDATES` in
  `py_modules/strip.py`.
- **"no Nollie controller found"** — run `sudo python3 nollie-probe.py --test`.
- **Panel loads but nothing responds** — `plugin.json` needs
  `"api_version": 1`.
- **Strip effect changes do nothing** — check `systemctl status led-controller`.
  The plugin only restarts the daemon if it was already running.

## Notes

Subprocesses run with `LD_LIBRARY_PATH` scrubbed. Decky's backend is a
PyInstaller bundle that points it at `/tmp/_MEI*`; children inherit that and
load the bundled libcrypto, which makes `systemctl` fail on a missing
`OPENSSL_3.x` symbol version.

Nollie HID protocol ported from the OpenRGB project (GPL-2.0-or-later) by
cnn1236661.

Strip control targets peterdk31/bc250_ws2812b_controller. Behaviour taken from
its documentation:

- Rules are evaluated top to bottom every 0.5 s and the first match wins. A
  rule with no `if` always matches, which is what makes the pinned rule work.
- Conditions are string expressions (`"steam_dl & !proc:gamescope"`), not
  objects. Downloads are the `steam_dl` condition.
- Pinnable effects take their color through `palette` (comma-separated stops)
  except `solid` and `alarm`, which take a single `color`. Only `rainbow` and
  `cycle` derive colors internally.
- `boot`, `shutdown`, `button_on` and `button_off` are not pinnable: they are
  one-shot recordings the receiver replays from flash, set under
  `esp32.power_on` / `esp32.shutdown` rather than as rules. `steam_download` is
  excluded too — it is driven by the `steam_dl` condition and handled by the
  download toggle instead.
- Switching effects crossfades over `crossfade_ms` (default 600), and a rule's
  `hold` sets a minimum time before it can be switched away from. Strip control follows the approach in the original Front Strip
plugin.
