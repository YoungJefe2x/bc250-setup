import {
  ButtonItem,
  DropdownItem,
  PanelSection,
  PanelSectionRow,
  SliderField,
  ToggleField,
  staticClasses,
} from "@decky/ui";
import { callable, definePlugin } from "@decky/api";
import { useEffect, useRef, useState } from "react";
import { FaLightbulb } from "react-icons/fa";

const DEBOUNCE_MS = 600;
const RULES_OPTION = "__rules__";
const DEFAULT_COLOR = "__default__";
const CUSTOM_COLOR = "__custom__";
const NO_SECOND = "__none__";
const FANS_ALL = "fans_all";
const DEV_STRIP = "device_strip";
const DEV_FANS = "device_fans";

// effects that only make sense when something triggers them, so they're no use
// as a pinned pick. The first four are one-shot animations the daemon records
// and uploads to the receiver's flash for power-on/off -- they play once and
// hold their last frame. steam_download is a progress bar driven by the
// steam_dl condition, so it just sits at zero when nothing is downloading.
const TRANSIENT_EFFECTS = new Set([
  "boot",
  "shutdown",
  "button_on",
  "button_off",
  "steam_download",
]);

const PRESETS = [
  { label: "White", hex: "ffffff" },
  { label: "Red", hex: "ff2020" },
  { label: "Orange", hex: "ff7010" },
  { label: "Yellow", hex: "ffc800" },
  { label: "Green", hex: "30e060" },
  { label: "Teal", hex: "20d0c0" },
  { label: "Light blue", hex: "60b0ff" },
  { label: "Blue", hex: "2060ff" },
  { label: "Purple", hex: "8040ff" },
  { label: "Pink", hex: "ff40a0" },
];

// Grouped by how they read on a fan: steady, then moving round the ring,
// then textured. rainbow and split make their own colors and ignore the
// picker; everything else is rendered in the chosen color.
const FAN_EFFECTS = [
  { data: "solid", label: "Solid" },
  { data: "glow", label: "Glow" },
  { data: "breathe", label: "Breathe" },
  { data: "wave", label: "Wave" },
  { data: "spin", label: "Spin" },
  { data: "orbit", label: "Orbit" },
  { data: "comet", label: "Comet" },
  { data: "chase", label: "Chase" },
  { data: "twinkle", label: "Twinkle" },
  { data: "fire", label: "Fire" },
  { data: "split", label: "Split" },
  { data: "rainbow", label: "Rainbow" },
  { data: "off", label: "Off" },
];

// effects that derive their own colors, so the color picker does nothing
const FAN_SELF_COLORED = new Set(["rainbow", "off"]);

// effect names come from the daemon as bare identifiers ("audio_music"); show
// them as words. Words the daemon spells lowercase but that read better
// capitalized get a special case.
const LABEL_FIXUPS: Record<string, string> = { gpu: "GPU", cpu: "CPU", led: "LED" };

const prettyEffect = (name: string) =>
  name
    .split("_")
    .map((w) => LABEL_FIXUPS[w] ?? w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");

// full-saturation hue -> RRGGBB, for the custom slider
function hueToHex(hue: number) {
  const x = Math.round(255 * (1 - Math.abs(((hue / 60) % 2) - 1)));
  const rgb = [
    [255, x, 0],
    [x, 255, 0],
    [0, 255, x],
    [0, x, 255],
    [x, 0, 255],
    [255, 0, x],
  ][Math.floor(hue / 60) % 6];
  return rgb.map((v) => v.toString(16).padStart(2, "0")).join("");
}

// RRGGBB -> hue degrees, so a custom color loaded from the config starts the
// slider (and its swatch) where the user actually left it
function hexToHue(hex: string) {
  const n = parseInt(hex, 16);
  if (isNaN(n)) return 0;
  const r = ((n >> 16) & 0xff) / 255;
  const g = ((n >> 8) & 0xff) / 255;
  const b = (n & 0xff) / 255;
  const max = Math.max(r, g, b);
  const d = max - Math.min(r, g, b);
  if (d === 0) return 0;
  let h: number;
  if (max === r) h = ((g - b) / d) % 6;
  else if (max === g) h = (b - r) / d + 2;
  else h = (r - g) / d + 4;
  return Math.round((h * 60 + 360) % 360);
}

const rgbToHex = ([r, g, b]: [number, number, number]) =>
  [r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("");

// A hue slider only shows a number, so this shows the color it will become.
// Reads from local state so it tracks the stick rather than waiting for the
// daemon to come back.
function Swatch({ hex, label }: { hex: string; label: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: "12px", padding: "4px 16px 8px" }}>
      <div
        style={{
          width: "28px",
          height: "28px",
          borderRadius: "50%",
          background: "#" + hex,
          border: "2px solid rgba(255, 255, 255, 0.35)",
          flexShrink: 0,
        }}
      />
      <span style={{ opacity: 0.75, fontSize: "0.85em" }}>
        {label} #{hex}
      </span>
    </div>
  );
}

type StripState = {
  ok: boolean;
  error: string | null;
  running: boolean;
  effects: string[];
  effect: string | null;
  brightness: number;
  leds: number;
  reverse: boolean;
  colorKey: string | null;
  effectKnown: boolean;
  paletteStops: number;
  color: string | null;
  color2: string | null;
  service: string;
  hasDownloadRule: boolean;
  overrideAt: number | null;
  keepDownload: boolean;
};

type Zone = {
  id: string;
  name: string;
  channel: number;
  offset: number;
  count: number;
  effect: string;
  color: [number, number, number];
  brightness: number;
  enabled: boolean;
};

type FanState = {
  error: string | null;
  device: { name: string; path: string } | null;
  connected: boolean;
  enabled: boolean;
  span: boolean;
  selected: string;
  sync_color: boolean;
  view: string;
  zones: Zone[];
  channels: number;
  power_source: string;
};

const getState = callable<[], FanState>("get_state");
const stripRefresh = callable<[], StripState>("strip_refresh");
const stripSetEffect = callable<[string | null, string | null, string | null], boolean>("strip_set_effect");
const stripSetColor = callable<[string | null, string | null], boolean>("strip_set_color");
const stripSetBrightness = callable<[number], boolean>("strip_set_brightness");
const stripSetPower = callable<[boolean], boolean>("strip_set_power");
const stripSetReverse = callable<[boolean], boolean>("strip_set_reverse");
const stripSetKeepDownload = callable<[boolean], boolean>("strip_set_keep_download");
const setZone = callable<[string, Partial<Zone>], unknown>("set_zone");
const setAll = callable<[Partial<Zone>], unknown>("set_all");
const setColor = callable<[string | null, string], unknown>("set_color");
const setSync = callable<[boolean], boolean>("set_sync");
const setSpan = callable<[boolean], boolean>("set_span");
const setSelected = callable<[string], string>("set_selected");
const setViewCall = callable<[string], string>("set_view");
const setEnabled = callable<[boolean], boolean>("set_enabled");
const identify = callable<[string, number], unknown>("identify");
const swap = callable<[], unknown>("swap");
const setChannelFor = callable<[string, number], unknown>("set_channel_for");
const reattach = callable<[], unknown>("reattach");
const diagnostics = callable<[], any>("diagnostics");
const selfTest = callable<[], any>("self_test");

// ============================================================ front strip
//
// A faithful port of the standalone Front Strip plugin, which worked: the
// same busy flag disabling controls mid-change, the same unconditional full
// refresh after every change, the same debounced sliders. Earlier attempts
// here diverged from that -- optimistic updates, partial refreshes, keyed
// remounts -- and the divergence is what broke the dropdowns.

function StripPanel({ syncOn }: { syncOn: boolean }) {
  const [state, setState] = useState<StripState | null>(null);
  // held as a percentage for display; the daemon takes 0..1
  const [brightness, setBrightness] = useState(100);
  const [hue, setHue] = useState(0);
  const [custom, setCustom] = useState(false);
  const [hue2, setHue2] = useState(180);
  const [custom2, setCustom2] = useState(false);
  const [busy, setBusy] = useState(false);
  const timers = useRef<Record<string, number>>({});

  const refresh = async () => {
    const next = await stripRefresh();
    setState(next);
    setBrightness(Math.round(next.brightness * 100));
    const isCustom = !!next.color && !PRESETS.some((p) => p.hex === next.color);
    const isCustom2 = !!next.color2 && !PRESETS.some((p) => p.hex === next.color2);
    setCustom(isCustom);
    setCustom2(isCustom2);
    if (isCustom && next.color) setHue(hexToHue(next.color));
    if (isCustom2 && next.color2) setHue2(hexToHue(next.color2));
  };

  useEffect(() => {
    refresh();
    return () => {
      window.clearTimeout(timers.current.brightness);
      window.clearTimeout(timers.current.hue);
      window.clearTimeout(timers.current.hue2);
    };
  }, []);

  if (!state) {
    return (
      <PanelSection title="Front strip">
        <PanelSectionRow>Loading…</PanelSectionRow>
      </PanelSection>
    );
  }

  if (!state.ok) {
    return (
      <PanelSection title="Front strip">
        <PanelSectionRow>{state.error ?? "Something went wrong."}</PanelSectionRow>
        <PanelSectionRow>
          <ButtonItem layout="below" onClick={() => refresh()}>
            Try again
          </ButtonItem>
        </PanelSectionRow>
      </PanelSection>
    );
  }

  const onEffect = async (value: string) => {
    setBusy(true);
    await stripSetEffect(value === RULES_OPTION ? null : value, state.color, state.color2);
    await refresh();
    setBusy(false);
  };

  const onBrightness = (percent: number) => {
    setBrightness(percent);
    window.clearTimeout(timers.current.brightness);
    timers.current.brightness = window.setTimeout(async () => {
      setBusy(true);
      await stripSetBrightness(percent);
      setBusy(false);
    }, DEBOUNCE_MS);
  };

  const applyColor = async (hex: string | null, hex2: string | null = state.color2) => {
    setBusy(true);
    await stripSetColor(hex, hex2);
    await refresh();
    setBusy(false);
  };

  const onColorChoice = async (value: string) => {
    if (value === CUSTOM_COLOR) {
      setCustom(true);
      await applyColor(hueToHex(hue));
      return;
    }
    setCustom(false);
    await applyColor(value === DEFAULT_COLOR ? null : value);
  };

  const onHue = (value: number) => {
    setHue(value);
    window.clearTimeout(timers.current.hue);
    timers.current.hue = window.setTimeout(() => applyColor(hueToHex(value)), DEBOUNCE_MS);
  };

  const onSecondChoice = async (value: string) => {
    if (value === CUSTOM_COLOR) {
      setCustom2(true);
      await applyColor(state.color, hueToHex(hue2));
      return;
    }
    setCustom2(false);
    await applyColor(state.color, value === NO_SECOND ? null : value);
  };

  const onHue2 = (value: number) => {
    setHue2(value);
    window.clearTimeout(timers.current.hue2);
    timers.current.hue2 = window.setTimeout(
      () => applyColor(state.color, hueToHex(value)),
      DEBOUNCE_MS
    );
  };

  const effectOptions = [
    { data: RULES_OPTION, label: "Automatic (follow rules)" },
    // keep a transient effect listed if it is the current pick, so the
    // dropdown can always show what's actually selected
    ...state.effects
      .filter((n) => !TRANSIENT_EFFECTS.has(n) || n === state.effect)
      .map((name) => ({ data: name, label: prettyEffect(name) })),
  ];
  const colorOptions = [
    { data: DEFAULT_COLOR, label: "Effect default" },
    ...PRESETS.map((p) => ({ data: p.hex, label: p.label })),
    { data: CUSTOM_COLOR, label: "Custom hue" },
  ];
  const secondOptions = [
    { data: NO_SECOND, label: "None (single color)" },
    ...PRESETS.map((p) => ({ data: p.hex, label: p.label })),
    { data: CUSTOM_COLOR, label: "Custom hue" },
  ];

  const selectedColor = custom ? CUSTOM_COLOR : state.color ?? DEFAULT_COLOR;
  const selectedSecond = custom2 ? CUSTOM_COLOR : state.color2 ?? NO_SECOND;
  // only palettes blend; "color" effects take a single value
  const canBlend = state.colorKey === "palette" && !!state.color;
  const controlsOff = busy || !state.running;

  return (
    <PanelSection title="Front strip">
      <PanelSectionRow>
        <ToggleField
          label="Strip on"
          description={`${state.leds} LEDs`}
          checked={state.running}
          disabled={busy}
          onChange={async (v) => {
            setBusy(true);
            await stripSetPower(v);
            await refresh();
            setBusy(false);
          }}
        />
      </PanelSectionRow>
      <PanelSectionRow>
        <DropdownItem
          label="Effect"
          rgOptions={effectOptions}
          selectedOption={state.effect ?? RULES_OPTION}
          disabled={controlsOff}
          onChange={(o) => onEffect(o.data as string)}
        />
      </PanelSectionRow>
      <PanelSectionRow>
        <SliderField
          label="Brightness"
          value={brightness}
          min={5}
          max={100}
          step={5}
          disabled={controlsOff}
          showValue
          valueSuffix="%"
          onChange={onBrightness}
        />
      </PanelSectionRow>
      {state.colorKey && (
        <PanelSectionRow>
          <DropdownItem
            label="Color"
            rgOptions={colorOptions}
            selectedOption={selectedColor}
            disabled={controlsOff}
            onChange={(o) => onColorChoice(o.data as string)}
          />
        </PanelSectionRow>
      )}
      {state.colorKey && custom && (
        <>
          <PanelSectionRow>
            <SliderField
              label="Hue"
              value={hue}
              min={0}
              max={359}
              step={1}
              disabled={controlsOff}
              showValue
              onChange={onHue}
            />
          </PanelSectionRow>
          <Swatch hex={hueToHex(hue)} label="Color" />
        </>
      )}
      {canBlend && (
        <PanelSectionRow>
          <DropdownItem
            label="Blend to"
            rgOptions={secondOptions}
            selectedOption={selectedSecond}
            disabled={controlsOff}
            onChange={(o) => onSecondChoice(o.data as string)}
          />
        </PanelSectionRow>
      )}
      {canBlend && custom2 && (
        <>
          <PanelSectionRow>
            <SliderField
              label="Blend hue"
              value={hue2}
              min={0}
              max={359}
              step={1}
              disabled={controlsOff}
              showValue
              onChange={onHue2}
            />
          </PanelSectionRow>
          <Swatch hex={hueToHex(hue2)} label="Blend" />
        </>
      )}
      {!state.colorKey && (
        <PanelSectionRow>
          {state.paletteStops > 0
            ? `${prettyEffect(state.effect ?? "This effect")} is built around a ${
                state.paletteStops
              }-color palette, so it is left as designed.`
            : state.effectKnown
            ? `${prettyEffect(state.effect ?? "This effect")} picks its own colors.`
            : `${prettyEffect(
                state.effect ?? "This effect"
              )} is newer than this plugin, so its color settings are unknown and hidden.`}
        </PanelSectionRow>
      )}
      <PanelSectionRow>
        <ToggleField
          label="Flip direction"
          description="For when the case is laid on its side. Reverses which end the download bar fills from, and every other effect with it."
          checked={state.reverse}
          disabled={busy}
          onChange={async (v) => {
            setBusy(true);
            await stripSetReverse(v);
            await refresh();
            setBusy(false);
          }}
        />
      </PanelSectionRow>
      {state.effect && (
        <PanelSectionRow>
          <ToggleField
            label="Steam downloads take over"
            description={
              state.hasDownloadRule
                ? "Show the download bar while downloading, then return to this effect."
                : "No download rule found in the daemon config, so this has nothing to defer to."
            }
            checked={state.keepDownload}
            disabled={busy || !state.hasDownloadRule}
            onChange={async (v) => {
              setBusy(true);
              await stripSetKeepDownload(v);
              await refresh();
              setBusy(false);
            }}
          />
        </PanelSectionRow>
      )}
      {syncOn && (
        <PanelSectionRow>
          <div style={{ padding: "0 16px 8px", fontSize: "0.8em", opacity: 0.7 }}>
            Colors are synced to the fans.
          </div>
        </PanelSectionRow>
      )}
    </PanelSection>
  );
}

// =================================================================== fans

function FanPanel() {
  const [state, setState] = useState<FanState | null>(null);
  const [target, setTarget] = useState(FANS_ALL);
  const [fanHue, setFanHue] = useState(0);
  const [fanCustom, setFanCustom] = useState(false);
  const [busy, setBusy] = useState(false);
  const [diag, setDiag] = useState<string | null>(null);
  const timers = useRef<Record<string, number>>({});

  const refresh = async () => {
    const next = await getState();
    setState(next);
    const validTarget =
      next.selected === FANS_ALL || next.zones.some((z) => z.id === next.selected);
    const chosen = validTarget ? next.selected : FANS_ALL;
    setTarget(chosen);
    const lead = next.zones.find((z) => z.id === chosen) ?? next.zones[0] ?? null;
    if (lead) {
      const hex = rgbToHex(lead.color);
      const isCustom = !PRESETS.some((p) => p.hex === hex);
      setFanCustom(isCustom);
      if (isCustom) setFanHue(hexToHue(hex));
    }
  };

  useEffect(() => {
    refresh();
    return () => window.clearTimeout(timers.current.hue);
  }, []);

  if (!state) {
    return (
      <PanelSection title="Fans">
        <PanelSectionRow>Loading…</PanelSectionRow>
      </PanelSection>
    );
  }

  if (!state.connected) {
    return (
      <PanelSection title="Fans">
        <PanelSectionRow>
          {state.error ?? "The Nollie controller is not connected."}
        </PanelSectionRow>
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            onClick={async () => {
              await reattach();
              await refresh();
            }}
          >
            Look for the controller
          </ButtonItem>
        </PanelSectionRow>
      </PanelSection>
    );
  }

  const bothFans = target === FANS_ALL;
  const fan = state.zones.find((z) => z.id === target) ?? state.zones[0];
  const selectedFanColor = fanCustom ? CUSTOM_COLOR : rgbToHex(fan.color);
  const controlsOff = busy || !state.enabled;

  const fanColorOptions = [
    ...PRESETS.map((p) => ({ data: p.hex, label: p.label })),
    { data: CUSTOM_COLOR, label: "Custom hue" },
  ];
  const targetOptions = [
    { data: FANS_ALL, label: "Both fans" },
    ...state.zones.map((z) => ({ data: z.id, label: z.name })),
  ];

  const applyFan = async (patch: Partial<Zone>) => {
    setBusy(true);
    if (bothFans) await setAll(patch);
    else await setZone(fan.id, patch);
    await refresh();
    setBusy(false);
  };

  const applyFanColor = async (hex: string) => {
    setBusy(true);
    await setColor(hex, target);
    await refresh();
    setBusy(false);
  };

  return (
    <>
      <PanelSection title="Fans">
        <PanelSectionRow>
          <ToggleField
            label="Fans on"
            description={
              state.device
                ? state.channels > 1
                  ? `${state.device.name}, a channel per fan`
                  : `${state.device.name}, both fans chained`
                : undefined
            }
            checked={state.enabled}
            disabled={busy}
            onChange={async (v) => {
              setBusy(true);
              await setEnabled(v);
              await refresh();
              setBusy(false);
            }}
          />
        </PanelSectionRow>
        <PanelSectionRow>
          <DropdownItem
            label="Which fan"
            rgOptions={targetOptions}
            selectedOption={target}
            disabled={busy}
            onChange={async (o) => {
              setBusy(true);
              await setSelected(o.data as string);
              await refresh();
              setBusy(false);
            }}
          />
        </PanelSectionRow>
        {state.channels > 1 && (
          <PanelSectionRow>
            <DropdownItem
              label="Header"
              rgOptions={Array.from({ length: state.channels }, (_, i) => ({
                data: i,
                label: `Channel ${i + 1}`,
              }))}
              selectedOption={fan.channel ?? 0}
              disabled={busy || bothFans}
              onChange={async (o) => {
                setBusy(true);
                await setChannelFor(fan.id, o.data as number);
                await refresh();
                setBusy(false);
              }}
            />
          </PanelSectionRow>
        )}
        <PanelSectionRow>
          <DropdownItem
            label="Effect"
            rgOptions={FAN_EFFECTS}
            selectedOption={fan.effect}
            disabled={controlsOff}
            onChange={(o) => applyFan({ effect: o.data as string })}
          />
        </PanelSectionRow>
        <PanelSectionRow>
          <SliderField
            label="Brightness"
            value={fan.brightness}
            min={1}
            max={100}
            step={1}
            disabled={controlsOff}
            showValue
            valueSuffix="%"
            onChange={(v) => applyFan({ brightness: v })}
          />
        </PanelSectionRow>
        <PanelSectionRow>
          <DropdownItem
            label="Color"
            rgOptions={fanColorOptions}
            selectedOption={selectedFanColor}
            disabled={controlsOff}
            onChange={async (o) => {
              const pick = o.data as string;
              if (pick === CUSTOM_COLOR) {
                setFanCustom(true);
                await applyFanColor(hueToHex(fanHue));
                return;
              }
              setFanCustom(false);
              await applyFanColor(pick);
            }}
          />
        </PanelSectionRow>
        {FAN_SELF_COLORED.has(fan.effect) && (
          <PanelSectionRow>
            <div style={{ padding: "0 16px 8px", fontSize: "0.85em", opacity: 0.75 }}>
              {fan.effect === "off"
                ? "This fan is dark."
                : "Rainbow makes its own colors."}
            </div>
          </PanelSectionRow>
        )}
        {fanCustom && (
          <>
            <PanelSectionRow>
              <SliderField
                label="Hue"
                value={fanHue}
                min={0}
                max={359}
                step={1}
                disabled={controlsOff}
                showValue
                onChange={(v) => {
                  setFanHue(v);
                  window.clearTimeout(timers.current.hue);
                  timers.current.hue = window.setTimeout(
                    () => applyFanColor(hueToHex(v)),
                    DEBOUNCE_MS
                  );
                }}
              />
            </PanelSectionRow>
            <Swatch hex={hueToHex(fanHue)} label="Color" />
          </>
        )}
        {bothFans ? (
          <PanelSectionRow>
            <ToggleField
              label="Treat as one strip"
              description="Run the effect across both fans instead of repeating it on each."
              checked={state.span}
              disabled={controlsOff}
              onChange={async (v) => {
                setBusy(true);
                await setSpan(v);
                await refresh();
                setBusy(false);
              }}
            />
          </PanelSectionRow>
        ) : (
          <PanelSectionRow>
            <ButtonItem layout="below" disabled={controlsOff} onClick={() => identify(fan.id, 5)}>
              Flash this fan
            </ButtonItem>
          </PanelSectionRow>
        )}
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            disabled={busy}
            onClick={async () => {
              await swap();
              await refresh();
            }}
          >
            Swap fan order
          </ButtonItem>
        </PanelSectionRow>
      </PanelSection>

      <PanelSection title="Fan diagnostics">
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            onClick={async () => {
              const d = await diagnostics();
              const found = (d.devices ?? []).map((x: any) => `${x.name} ${x.path}`).join(", ");
              const others = (d.holders ?? []).map((h: any) => `${h.name}(${h.pid})`).join(", ");
              setDiag(
                [
                  `root: ${d.root}`,
                  `found: ${found || "nothing"}`,
                  `open: ${d.connected}`,
                  `frames: ${d.frames}`,
                  `last frame: ${
                    d.seconds_since_frame == null ? "never" : d.seconds_since_frame + "s ago"
                  }`,
                  `enabled: ${d.enabled}, leds: ${d.leds}, ch: ${d.channel}`,
                  others ? `ALSO HELD BY: ${others}` : "no other holders",
                  d.last_write_error ? `write error: ${d.last_write_error}` : "",
                  d.error ? `error: ${d.error}` : "",
                ]
                  .filter(Boolean)
                  .join("\n")
              );
            }}
          >
            Run diagnostics
          </ButtonItem>
        </PanelSectionRow>
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            onClick={async () => {
              setDiag("running test pattern…");
              const r = await selfTest();
              setDiag(
                r.ok
                  ? `wrote red/green/blue to ${r.path}, then lit each channel alone (${Object.entries(
                      r.channels ?? {}
                    )
                      .map(([c, n]) => `ch${c}:${n}`)
                      .join(", ")}). Did both fans change?`
                  : `test failed at ${r.stage}: ${r.error}`
              );
            }}
          >
            Run test pattern
          </ButtonItem>
        </PanelSectionRow>
        {diag && (
          <PanelSectionRow>
            <div style={{ whiteSpace: "pre-wrap", fontSize: "0.8em", padding: "4px 16px 8px" }}>
              {diag}
            </div>
          </PanelSectionRow>
        )}
      </PanelSection>
    </>
  );
}

// ================================================================== shell
//
// Each panel owns its own state and does its own reads. Nothing is shared, so
// neither can overwrite the other's controls -- which is what went wrong when
// they were a single component.

function Content() {
  const [view, setView] = useState<string | null>(null);
  const [syncOn, setSyncOn] = useState(true);

  useEffect(() => {
    getState()
      .then((s) => {
        setView(s.view === "fans" ? DEV_FANS : DEV_STRIP);
        setSyncOn(s.sync_color);
      })
      .catch(() => setView(DEV_STRIP));
  }, []);

  if (view === null) {
    return (
      <PanelSection title="BC-250 Lighting">
        <PanelSectionRow>Loading…</PanelSectionRow>
      </PanelSection>
    );
  }

  return (
    <>
      <PanelSection title="BC-250 Lighting">
        <PanelSectionRow>
          <DropdownItem
            label="Lighting"
            rgOptions={[
              { data: DEV_STRIP, label: "Front strip" },
              { data: DEV_FANS, label: "Fans" },
            ]}
            selectedOption={view}
            onChange={(o) => {
              const pick = o.data as string;
              setView(pick);
              setViewCall(pick === DEV_FANS ? "fans" : "strip");
            }}
          />
        </PanelSectionRow>
        <PanelSectionRow>
          <ToggleField
            label="Sync colors"
            description="A color picked in either section is applied to both."
            checked={syncOn}
            onChange={(v) => {
              setSyncOn(v);
              setSync(v);
            }}
          />
        </PanelSectionRow>
      </PanelSection>

      {view === DEV_STRIP ? <StripPanel key="strip" syncOn={syncOn} /> : <FanPanel key="fans" />}
    </>
  );
}

export default definePlugin(() => ({
  name: "BC-250 Lighting",
  titleView: <div className={staticClasses.Title}>BC-250 Lighting</div>,
  content: <Content />,
  icon: <FaLightbulb />,
}));
