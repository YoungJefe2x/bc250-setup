import {
  ButtonItem,
  DialogButton,
  DropdownItem,
  Focusable,
  GamepadButton,
  PanelSection,
  PanelSectionRow,
  SliderField,
  ToggleField,
  staticClasses,
} from "@decky/ui";
import { callable, definePlugin } from "@decky/api";
import { useEffect, useRef, useState } from "react";
import { FaLightbulb } from "react-icons/fa";

const DEBOUNCE_MS = 600;
const RULES_OPTION = "__rules__";
const DEFAULT_COLOR = "__default__";
const CUSTOM_COLOR = "__custom__";
const NO_SECOND = "__none__";
const FANS_ALL = "fans_all";

// effects that only make sense when something triggers them, so they're no use
// as a pinned pick. The first four are one-shot animations the daemon records
// and uploads to the receiver's flash for power-on/off -- they play once and
// hold their last frame. steam_download is a progress bar driven by the
// steam_dl condition, so it just sits at zero when nothing is downloading.
// The backend adds any other effect the daemon's sources mark as one-shot or
// feed-driven (achievement, progress, and whatever comes next) in
// state.transient; this list is only the fallback.
const TRANSIENT_EFFECTS = new Set([
  "boot",
  "shutdown",
  "button_on",
  "button_off",
  "steam_download",
]);

const PRESETS = [
  { label: "White", hex: "ffffff" },
  { label: "Red", hex: "ff2020" },
  { label: "Orange", hex: "ff7010" },
  { label: "Yellow", hex: "ffc800" },
  { label: "Green", hex: "30e060" },
  { label: "Teal", hex: "20d0c0" },
  { label: "Light blue", hex: "60b0ff" },
  { label: "Blue", hex: "2060ff" },
  { label: "Purple", hex: "8040ff" },
  { label: "Pink", hex: "ff40a0" },
];

// Grouped by how they read on a fan: steady, then moving round the ring,
// then textured, then the strip's effects reshaped for a ring. rainbow and the
// strip ports make their own colors and ignore the picker; split derives its
// second color from the pick; everything else is rendered in the chosen color.
const FAN_EFFECTS = [
  { data: "solid", label: "Solid" },
  { data: "glow", label: "Glow" },
  { data: "breathe", label: "Breathe" },
  { data: "wave", label: "Wave" },
  { data: "spin", label: "Spin" },
  { data: "orbit", label: "Orbit" },
  { data: "comet", label: "Comet" },
  { data: "chase", label: "Chase" },
  { data: "twinkle", label: "Twinkle" },
  { data: "fire", label: "Fire" },
  { data: "split", label: "Split" },
  { data: "rainbow", label: "Rainbow" },
  // ports of the strip's effects, in the strip's own colors
  { data: "pendulum", label: "Pendulum" },
  { data: "shoreline", label: "Shoreline" },
  { data: "ink", label: "Ink" },
  { data: "silk", label: "Silk" },
  { data: "caustics", label: "Caustics" },
  { data: "stars", label: "Binary Stars" },
  { data: "boil", label: "Load Boil" },
  { data: "off", label: "Off" },
];

// the strip's effects keep the strip's palettes on the fans too
const FAN_STRIP_PORTS = new Set(["pendulum", "shoreline", "ink", "silk", "caustics", "stars", "boil"]);

// effects that derive their own colors, so the color picker does nothing
const FAN_SELF_COLORED = new Set(["rainbow", "off", ...FAN_STRIP_PORTS]);

// effect names come from the daemon as bare identifiers ("audio_music"); show
// them as words. Words the daemon spells lowercase but that read better
// capitalized get a special case.
const LABEL_FIXUPS: Record<string, string> = { gpu: "GPU", cpu: "CPU", led: "LED" };

const prettyEffect = (name: string) =>
  name
    .split("_")
    .map((w) => LABEL_FIXUPS[w] ?? w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");

// full-saturation hue -> RRGGBB, for the custom slider
function hueToHex(hue: number) {
  const x = Math.round(255 * (1 - Math.abs(((hue / 60) % 2) - 1)));
  const rgb = [
    [255, x, 0],
    [x, 255, 0],
    [0, 255, x],
    [0, x, 255],
    [x, 0, 255],
    [255, 0, x],
  ][Math.floor(hue / 60) % 6];
  return rgb.map((v) => v.toString(16).padStart(2, "0")).join("");
}

// RRGGBB -> hue degrees, so a custom color loaded from the config starts the
// slider (and its swatch) where the user actually left it
function hexToHue(hex: string) {
  const n = parseInt(hex, 16);
  if (isNaN(n)) return 0;
  const r = ((n >> 16) & 0xff) / 255;
  const g = ((n >> 8) & 0xff) / 255;
  const b = (n & 0xff) / 255;
  const max = Math.max(r, g, b);
  const d = max - Math.min(r, g, b);
  if (d === 0) return 0;
  let h: number;
  if (max === r) h = ((g - b) / d) % 6;
  else if (max === g) h = (b - r) / d + 2;
  else h = (r - g) / d + 4;
  return Math.round((h * 60 + 360) % 360);
}

const rgbToHex = ([r, g, b]: [number, number, number]) =>
  [r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("");

// A hue slider only shows a number, so this shows the color it will become.
// Reads from local state so it tracks the stick rather than waiting for the
// daemon to come back.
function Swatch({ hex, label }: { hex: string; label: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: "12px", padding: "4px 16px 8px" }}>
      <div
        style={{
          width: "28px",
          height: "28px",
          borderRadius: "50%",
          background: "#" + hex,
          border: "2px solid rgba(255, 255, 255, 0.35)",
          flexShrink: 0,
        }}
      />
      <span style={{ opacity: 0.75, fontSize: "0.85em" }}>
        {label} #{hex}
      </span>
    </div>
  );
}

// A row of round color buttons in place of a dropdown: one press to pick, and
// the current color is visible without opening anything. `first` is an
// optional leading swatch (the effect's own palette). The last swatch opens
// the custom hue slider.
const RAINBOW = "conic-gradient(#ff2020, #ffc800, #30e060, #20d0c0, #2060ff, #8040ff, #ff40a0, #ff2020)";

function Swatches({
  value,
  custom,
  disabled,
  first,
  onPick,
}: {
  value: string | null;
  custom: boolean;
  disabled?: boolean;
  first?: { data: string; label: string; background: string };
  onPick: (data: string) => void;
}) {
  const [focused, setFocused] = useState<string | null>(null);
  const items = [
    ...(first ? [first] : []),
    ...PRESETS.map((p) => ({ data: p.hex, label: p.label, background: "#" + p.hex })),
    { data: CUSTOM_COLOR, label: "Custom hue", background: RAINBOW },
  ];
  const selected = custom ? CUSTOM_COLOR : value ?? first?.data ?? null;
  const shown = items.find((i) => i.data === (focused ?? selected));
  return (
    <div style={{ padding: "4px 0 8px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.9em", padding: "0 0 6px" }}>
        <span>Color</span>
        <span style={{ opacity: 0.7 }}>{shown?.label ?? ""}</span>
      </div>
      <Focusable style={{ display: "flex", flexWrap: "wrap", gap: "6px" }} flow-children="horizontal">
        {items.map((item) => {
          const isSel = item.data === selected;
          const isFocus = item.data === focused;
          return (
            <Focusable
              key={item.data}
              noFocusRing
              onActivate={() => !disabled && onPick(item.data)}
              onClick={() => !disabled && onPick(item.data)}
              onFocus={() => setFocused(item.data)}
              onBlur={() => setFocused((f) => (f === item.data ? null : f))}
              aria-label={item.label}
              style={{
                width: "30px",
                height: "30px",
                minWidth: 0,
                padding: 0,
                borderRadius: "50%",
                background: item.background,
                border: isSel ? "3px solid #ffffff" : "2px solid rgba(255,255,255,0.15)",
                boxShadow: isFocus ? "0 0 0 2px #1a9fff" : "none",
                opacity: disabled ? 0.4 : 1,
                boxSizing: "border-box",
                cursor: "pointer",
              }}
            >
              <span />
            </Focusable>
          );
        })}
      </Focusable>
    </div>
  );
}

const TAB_STRIP = "strip";
const TAB_FANS = "fans";
const TAB_SETTINGS = "settings";

function TabBar({ tab, onTab }: { tab: string; onTab: (t: string) => void }) {
  const tabs = [
    { id: TAB_STRIP, label: "Strip" },
    { id: TAB_FANS, label: "Fans" },
    { id: TAB_SETTINGS, label: "Settings" },
  ];
  return (
    <Focusable
      style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "4px", padding: "0 0 8px" }}
      flow-children="horizontal"
    >
      {tabs.map((t) => (
        <DialogButton
          key={t.id}
          onClick={() => onTab(t.id)}
          style={{
            minWidth: 0,
            padding: "6px 0",
            fontSize: "0.9em",
            background: t.id === tab ? "#1a9fff" : undefined,
            color: t.id === tab ? "#ffffff" : undefined,
          }}
        >
          {t.label}
        </DialogButton>
      ))}
    </Focusable>
  );
}

type StripState = {
  ok: boolean;
  error: string | null;
  running: boolean;
  effects: string[];
  effect: string | null;
  brightness: number;
  leds: number;
  reverse: boolean;
  colorKey: string | null;
  effectKnown: boolean;
  paletteStops: number;
  color: string | null;
  color2: string | null;
  service: string;
  hasDownloadRule: boolean;
  overrideAt: number | null;
  keepDownload: boolean;
  transient?: string[];
  summary?: string;
  settings?: EffectSetting[];
};

// one of the pinned effect's own settings, as the daemon's source declares it
type EffectSetting = {
  key: string;
  type: "float" | "int" | "bool";
  default: number | boolean;
  value: number | boolean;
  changed: boolean;
  doc: string;
  min?: number;
  max?: number;
};

type Zone = {
  id: string;
  name: string;
  channel: number;
  offset: number;
  count: number;
  effect: string;
  color: [number, number, number];
  brightness: number;
  enabled: boolean;
};

type FanState = {
  standby: boolean;
  standby_minutes: number;
  standby_active: boolean;
  download_dim?: boolean;
  download_dim_active?: boolean;
  error: string | null;
  device: { name: string; path: string } | null;
  connected: boolean;
  enabled: boolean;
  span: boolean;
  mirror?: boolean;
  selected: string;
  sync_color: boolean;
  view: string;
  zones: Zone[];
  channels: number;
  power_source: string;
};

const getState = callable<[], FanState>("get_state");
const stripRefresh = callable<[], StripState>("strip_refresh");
const stripSetEffect = callable<[string | null, string | null, string | null], boolean>("strip_set_effect");
const stripSetColor = callable<[string | null, string | null], boolean>("strip_set_color");
const stripSetBrightness = callable<[number], boolean>("strip_set_brightness");
const stripSetPower = callable<[boolean], boolean>("strip_set_power");
const stripSetReverse = callable<[boolean], boolean>("strip_set_reverse");
const stripSetKeepDownload = callable<[boolean], boolean>("strip_set_keep_download");
const stripSetSetting = callable<[string, number | boolean | null], boolean>("strip_set_setting");
const stripResetSettings = callable<[], boolean>("strip_reset_settings");

// settings are shown as 0..100 slider positions over the effect's range, so a
// 0.05-wide value and a 60-second period get the same fine control
const SLIDER_STEPS = 100;
const toPosition = (s: EffectSetting, v: number) => {
  const lo = s.min ?? 0;
  const hi = s.max ?? 1;
  if (hi <= lo) return 0;
  return Math.round(((Math.min(hi, Math.max(lo, v)) - lo) / (hi - lo)) * SLIDER_STEPS);
};
const fromPosition = (s: EffectSetting, p: number) => {
  const lo = s.min ?? 0;
  const hi = s.max ?? 1;
  const v = lo + ((hi - lo) * p) / SLIDER_STEPS;
  if (s.type === "int") return Math.round(v);
  const digits = hi - lo >= 20 ? 1 : hi - lo >= 2 ? 2 : 3;
  return Number(v.toFixed(digits));
};
const formatValue = (v: number | boolean) =>
  typeof v === "number" ? String(Number(v.toFixed(3))) : v ? "on" : "off";
const prettyKey = (key: string) => {
  const words = key.split("_");
  return words
    .map((w, i) => (i === 0 ? w.charAt(0).toUpperCase() + w.slice(1) : w))
    .join(" ")
    .replace(/ seconds$/, " (s)");
};
const sentence = (text: string) => (text ? text.charAt(0).toUpperCase() + text.slice(1) : text);
const setZone = callable<[string, Partial<Zone>], unknown>("set_zone");
const setAll = callable<[Partial<Zone>], unknown>("set_all");
const setColor = callable<[string | null, string], unknown>("set_color");
const setSync = callable<[boolean], boolean>("set_sync");
const setSpan = callable<[boolean], boolean>("set_span");
const setMirror = callable<[boolean], boolean>("set_mirror");
const setSelected = callable<[string], string>("set_selected");
const setViewCall = callable<[string], string>("set_view");
const setEnabled = callable<[boolean], boolean>("set_enabled");
const identify = callable<[string, number], unknown>("identify");
const swap = callable<[], unknown>("swap");
const setChannelFor = callable<[string, number], unknown>("set_channel_for");
const reattach = callable<[], unknown>("reattach");
const diagnostics = callable<[], any>("diagnostics");
const selfTest = callable<[], any>("self_test");
const setStandby = callable<[boolean], boolean>("set_standby");
const setStandbyMinutes = callable<[number], number>("set_standby_minutes");
const setDownloadDim = callable<[boolean], boolean>("set_download_dim");

// ============================================================ front strip
//
// A faithful port of the standalone Front Strip plugin, which worked: the
// same busy flag disabling controls mid-change, the same unconditional full
// refresh after every change, the same debounced sliders. Earlier attempts
// here diverged from that -- optimistic updates, partial refreshes, keyed
// remounts -- and the divergence is what broke the dropdowns.

// mode "main" is the Strip tab (on, effect, brightness, color, tune); mode
// "settings" is the strip's part of the Settings tab (direction, Steam events)
function StripPanel({ syncOn, mode = "main" }: { syncOn: boolean; mode?: "main" | "settings" }) {
  const [state, setState] = useState<StripState | null>(null);
  // held as a percentage for display; the daemon takes 0..1
  const [brightness, setBrightness] = useState(100);
  const [hue, setHue] = useState(0);
  const [custom, setCustom] = useState(false);
  const [hue2, setHue2] = useState(180);
  const [custom2, setCustom2] = useState(false);
  const [busy, setBusy] = useState(false);
  const [tuning, setTuning] = useState(false);
  // slider positions while a debounced write is pending, keyed by setting
  const [pending, setPending] = useState<Record<string, number>>({});
  const timers = useRef<Record<string, number>>({});

  const refresh = async () => {
    const next = await stripRefresh();
    setState(next);
    setPending({});
    setBrightness(Math.round(next.brightness * 100));
    const isCustom = !!next.color && !PRESETS.some((p) => p.hex === next.color);
    const isCustom2 = !!next.color2 && !PRESETS.some((p) => p.hex === next.color2);
    setCustom(isCustom);
    setCustom2(isCustom2);
    if (isCustom && next.color) setHue(hexToHue(next.color));
    if (isCustom2 && next.color2) setHue2(hexToHue(next.color2));
  };

  useEffect(() => {
    refresh();
    return () => {
      window.clearTimeout(timers.current.brightness);
      window.clearTimeout(timers.current.hue);
      window.clearTimeout(timers.current.hue2);
      Object.keys(timers.current)
        .filter((k) => k.startsWith("setting:"))
        .forEach((k) => window.clearTimeout(timers.current[k]));
    };
  }, []);

  if (!state) {
    return (
      <PanelSection title="Front strip">
        <PanelSectionRow>Loading…</PanelSectionRow>
      </PanelSection>
    );
  }

  if (!state.ok) {
    return (
      <PanelSection title="Front strip">
        <PanelSectionRow>{state.error ?? "Something went wrong."}</PanelSectionRow>
        <PanelSectionRow>
          <ButtonItem layout="below" onClick={() => refresh()}>
            Try again
          </ButtonItem>
        </PanelSectionRow>
      </PanelSection>
    );
  }

  const onEffect = async (value: string) => {
    setBusy(true);
    await stripSetEffect(value === RULES_OPTION ? null : value, state.color, state.color2);
    await refresh();
    setBusy(false);
  };

  const onBrightness = (percent: number) => {
    setBrightness(percent);
    window.clearTimeout(timers.current.brightness);
    timers.current.brightness = window.setTimeout(async () => {
      setBusy(true);
      await stripSetBrightness(percent);
      setBusy(false);
    }, DEBOUNCE_MS);
  };

  const applyColor = async (hex: string | null, hex2: string | null = state.color2) => {
    setBusy(true);
    await stripSetColor(hex, hex2);
    await refresh();
    setBusy(false);
  };

  const onColorChoice = async (value: string) => {
    if (value === CUSTOM_COLOR) {
      setCustom(true);
      await applyColor(hueToHex(hue));
      return;
    }
    setCustom(false);
    await applyColor(value === DEFAULT_COLOR ? null : value);
  };

  const onHue = (value: number) => {
    setHue(value);
    window.clearTimeout(timers.current.hue);
    timers.current.hue = window.setTimeout(() => applyColor(hueToHex(value)), DEBOUNCE_MS);
  };

  const onSecondChoice = async (value: string) => {
    if (value === CUSTOM_COLOR) {
      setCustom2(true);
      await applyColor(state.color, hueToHex(hue2));
      return;
    }
    setCustom2(false);
    await applyColor(state.color, value === NO_SECOND ? null : value);
  };

  const onHue2 = (value: number) => {
    setHue2(value);
    window.clearTimeout(timers.current.hue2);
    timers.current.hue2 = window.setTimeout(
      () => applyColor(state.color, hueToHex(value)),
      DEBOUNCE_MS
    );
  };

  const onSetting = (setting: EffectSetting, position: number) => {
    setPending((p) => ({ ...p, [setting.key]: position }));
    const id = "setting:" + setting.key;
    window.clearTimeout(timers.current[id]);
    timers.current[id] = window.setTimeout(async () => {
      setBusy(true);
      await stripSetSetting(setting.key, fromPosition(setting, position));
      await refresh();
      setBusy(false);
    }, DEBOUNCE_MS);
  };

  const onToggleSetting = async (setting: EffectSetting, value: boolean) => {
    setBusy(true);
    await stripSetSetting(setting.key, value);
    await refresh();
    setBusy(false);
  };

  const onResetSettings = async () => {
    setBusy(true);
    await stripResetSettings();
    await refresh();
    setBusy(false);
  };

  const transient = new Set([...TRANSIENT_EFFECTS, ...(state.transient ?? [])]);
  const effectSettings = state.settings ?? [];
  const anyChanged = effectSettings.some((s) => s.changed);

  const effectOptions = [
    { data: RULES_OPTION, label: "Automatic (follow rules)" },
    // keep a transient effect listed if it is the current pick, so the
    // dropdown can always show what's actually selected
    ...state.effects
      .filter((n) => !transient.has(n) || n === state.effect)
      .map((name) => ({ data: name, label: prettyEffect(name) })),
  ];
  const secondOptions = [
    { data: NO_SECOND, label: "None (single color)" },
    ...PRESETS.map((p) => ({ data: p.hex, label: p.label })),
    { data: CUSTOM_COLOR, label: "Custom hue" },
  ];

  const selectedSecond = custom2 ? CUSTOM_COLOR : state.color2 ?? NO_SECOND;
  // only palettes blend; "color" effects take a single value
  const canBlend = state.colorKey === "palette" && !!state.color;
  const controlsOff = busy || !state.running;

  if (mode === "settings") {
    return (
      <PanelSection title="Front strip">
        <PanelSectionRow>
          <ToggleField
            label="Flip direction"
            description="For a case laid on its side."
            checked={state.reverse}
            disabled={busy}
            onChange={async (v) => {
              setBusy(true);
              await stripSetReverse(v);
              await refresh();
              setBusy(false);
            }}
          />
        </PanelSectionRow>
        <PanelSectionRow>
          <ToggleField
            label="Steam events take over"
            description={
              state.hasDownloadRule
                ? "Downloads, launches and achievements show over your effect."
                : "No Steam event rules in the daemon config."
            }
            checked={state.keepDownload}
            disabled={busy || !state.hasDownloadRule}
            onChange={async (v) => {
              setBusy(true);
              await stripSetKeepDownload(v);
              await refresh();
              setBusy(false);
            }}
          />
        </PanelSectionRow>
      </PanelSection>
    );
  }

  return (
    <PanelSection title="Front strip">
      <PanelSectionRow>
        <ToggleField
          label="Strip on"
          description={`${state.leds} LEDs`}
          checked={state.running}
          disabled={busy}
          onChange={async (v) => {
            setBusy(true);
            await stripSetPower(v);
            await refresh();
            setBusy(false);
          }}
        />
      </PanelSectionRow>
      <PanelSectionRow>
        <DropdownItem
          label="Effect"
          rgOptions={effectOptions}
          selectedOption={state.effect ?? RULES_OPTION}
          disabled={controlsOff}
          onChange={(o) => onEffect(o.data as string)}
        />
      </PanelSectionRow>
      {state.effect && state.summary && (
        <PanelSectionRow>
          <div style={{ fontSize: "12px", opacity: 0.75 }}>{sentence(state.summary)}</div>
        </PanelSectionRow>
      )}
      <PanelSectionRow>
        <SliderField
          label="Brightness"
          value={brightness}
          min={5}
          max={100}
          step={5}
          disabled={controlsOff}
          showValue
          valueSuffix="%"
          onChange={onBrightness}
        />
      </PanelSectionRow>
      {state.colorKey && (
        <PanelSectionRow>
          <Swatches
            value={state.color}
            custom={custom}
            disabled={controlsOff}
            first={{ data: DEFAULT_COLOR, label: "Effect default", background: RAINBOW.replace("conic-gradient(", "conic-gradient(from 90deg, ") }}
            onPick={(v) => onColorChoice(v)}
          />
        </PanelSectionRow>
      )}
      {state.colorKey && custom && (
        <>
          <PanelSectionRow>
            <SliderField
              label="Hue"
              value={hue}
              min={0}
              max={359}
              step={1}
              disabled={controlsOff}
              showValue
              onChange={onHue}
            />
          </PanelSectionRow>
          <Swatch hex={hueToHex(hue)} label="Color" />
        </>
      )}
      {canBlend && (
        <PanelSectionRow>
          <DropdownItem
            label="Blend to"
            rgOptions={secondOptions}
            selectedOption={selectedSecond}
            disabled={controlsOff}
            onChange={(o) => onSecondChoice(o.data as string)}
          />
        </PanelSectionRow>
      )}
      {canBlend && custom2 && (
        <>
          <PanelSectionRow>
            <SliderField
              label="Blend hue"
              value={hue2}
              min={0}
              max={359}
              step={1}
              disabled={controlsOff}
              showValue
              onChange={onHue2}
            />
          </PanelSectionRow>
          <Swatch hex={hueToHex(hue2)} label="Blend" />
        </>
      )}
      {!state.colorKey && (
        <PanelSectionRow>
          {state.paletteStops > 0
            ? `${prettyEffect(state.effect ?? "This effect")} is built around a ${
                state.paletteStops
              }-color palette, so it is left as designed.`
            : state.effectKnown
            ? `${prettyEffect(state.effect ?? "This effect")} picks its own colors.`
            : `${prettyEffect(
                state.effect ?? "This effect"
              )} is newer than this plugin, so its color settings are unknown and hidden.`}
        </PanelSectionRow>
      )}
      {state.effect && effectSettings.length > 0 && (
        <PanelSectionRow>
          <ToggleField
            label="Tune effect"
            description={`${effectSettings.length} settings from the daemon${
              anyChanged ? ", some changed" : ""
            }. Kept for this effect.`}
            checked={tuning}
            onChange={setTuning}
          />
        </PanelSectionRow>
      )}
      {state.effect &&
        tuning &&
        effectSettings.map((setting) =>
          setting.type === "bool" ? (
            <PanelSectionRow key={setting.key}>
              <ToggleField
                label={prettyKey(setting.key)}
                description={sentence(setting.doc) || undefined}
                checked={!!setting.value}
                disabled={controlsOff}
                onChange={(v) => onToggleSetting(setting, v)}
              />
            </PanelSectionRow>
          ) : (
            <PanelSectionRow key={setting.key}>
              <SliderField
                label={`${prettyKey(setting.key)}: ${formatValue(
                  setting.key in pending
                    ? fromPosition(setting, pending[setting.key])
                    : (setting.value as number)
                )}${setting.changed ? "" : " (default)"}`}
                description={sentence(setting.doc) || undefined}
                value={
                  setting.key in pending
                    ? pending[setting.key]
                    : toPosition(setting, Number(setting.value))
                }
                min={0}
                max={SLIDER_STEPS}
                step={1}
                disabled={controlsOff}
                onChange={(p) => onSetting(setting, p)}
              />
            </PanelSectionRow>
          )
        )}
      {state.effect && tuning && anyChanged && (
        <PanelSectionRow>
          <ButtonItem layout="below" disabled={controlsOff} onClick={onResetSettings}>
            Reset to effect defaults
          </ButtonItem>
        </PanelSectionRow>
      )}
      {syncOn && (
        <PanelSectionRow>
          <div style={{ padding: "0 16px 8px", fontSize: "0.8em", opacity: 0.7 }}>
            Colors are synced to the fans.
          </div>
        </PanelSectionRow>
      )}
    </PanelSection>
  );
}

// =================================================================== fans

function FanPanel() {
  const [state, setState] = useState<FanState | null>(null);
  const [target, setTarget] = useState(FANS_ALL);
  const [fanHue, setFanHue] = useState(0);
  const [fanCustom, setFanCustom] = useState(false);
  const [busy, setBusy] = useState(false);
  const [diag, setDiag] = useState<string | null>(null);
  const timers = useRef<Record<string, number>>({});

  const refresh = async () => {
    const next = await getState();
    setState(next);
    const validTarget =
      next.selected === FANS_ALL || next.zones.some((z) => z.id === next.selected);
    const chosen = validTarget ? next.selected : FANS_ALL;
    setTarget(chosen);
    const lead = next.zones.find((z) => z.id === chosen) ?? next.zones[0] ?? null;
    if (lead) {
      const hex = rgbToHex(lead.color);
      const isCustom = !PRESETS.some((p) => p.hex === hex);
      setFanCustom(isCustom);
      if (isCustom) setFanHue(hexToHue(hex));
    }
  };

  useEffect(() => {
    refresh();
    return () => window.clearTimeout(timers.current.hue);
  }, []);

  if (!state) {
    return (
      <PanelSection title="Fans">
        <PanelSectionRow>Loading…</PanelSectionRow>
      </PanelSection>
    );
  }

  if (!state.connected) {
    return (
      <PanelSection title="Fans">
        <PanelSectionRow>
          {state.error ?? "The Nollie controller is not connected."}
        </PanelSectionRow>
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            onClick={async () => {
              await reattach();
              await refresh();
            }}
          >
            Look for the controller
          </ButtonItem>
        </PanelSectionRow>
      </PanelSection>
    );
  }

  const bothFans = target === FANS_ALL;
  const fan = state.zones.find((z) => z.id === target) ?? state.zones[0];
  const controlsOff = busy || !state.enabled;

  const targetOptions = [
    { data: FANS_ALL, label: "Both fans" },
    ...state.zones.map((z) => ({ data: z.id, label: z.name })),
  ];

  const applyFan = async (patch: Partial<Zone>) => {
    setBusy(true);
    if (bothFans) await setAll(patch);
    else await setZone(fan.id, patch);
    await refresh();
    setBusy(false);
  };

  const applyFanColor = async (hex: string) => {
    setBusy(true);
    await setColor(hex, target);
    await refresh();
    setBusy(false);
  };

  return (
    <>
      <PanelSection title="Fans">
        <PanelSectionRow>
          <ToggleField
            label="Fans on"
            description={
              state.device
                ? state.channels > 1
                  ? `${state.device.name}, a channel per fan`
                  : `${state.device.name}, both fans chained`
                : undefined
            }
            checked={state.enabled}
            disabled={busy}
            onChange={async (v) => {
              setBusy(true);
              await setEnabled(v);
              await refresh();
              setBusy(false);
            }}
          />
        </PanelSectionRow>
        <PanelSectionRow>
          <DropdownItem
            label="Which fan"
            rgOptions={targetOptions}
            selectedOption={target}
            disabled={busy}
            onChange={async (o) => {
              setBusy(true);
              await setSelected(o.data as string);
              await refresh();
              setBusy(false);
            }}
          />
        </PanelSectionRow>
        {state.channels > 1 && (
          <PanelSectionRow>
            <DropdownItem
              label="Header"
              rgOptions={Array.from({ length: state.channels }, (_, i) => ({
                data: i,
                label: `Channel ${i + 1}`,
              }))}
              selectedOption={fan.channel ?? 0}
              disabled={busy || bothFans}
              onChange={async (o) => {
                setBusy(true);
                await setChannelFor(fan.id, o.data as number);
                await refresh();
                setBusy(false);
              }}
            />
          </PanelSectionRow>
        )}
        <PanelSectionRow>
          <DropdownItem
            label="Effect"
            rgOptions={FAN_EFFECTS}
            selectedOption={fan.effect}
            disabled={controlsOff}
            onChange={(o) => applyFan({ effect: o.data as string })}
          />
        </PanelSectionRow>
        <PanelSectionRow>
          <SliderField
            label="Brightness"
            value={fan.brightness}
            min={1}
            max={100}
            step={1}
            disabled={controlsOff}
            showValue
            valueSuffix="%"
            onChange={(v) => applyFan({ brightness: v })}
          />
        </PanelSectionRow>
        <PanelSectionRow>
          <Swatches
            value={rgbToHex(fan.color)}
            custom={fanCustom}
            disabled={controlsOff}
            onPick={async (pick) => {
              if (pick === CUSTOM_COLOR) {
                setFanCustom(true);
                await applyFanColor(hueToHex(fanHue));
                return;
              }
              setFanCustom(false);
              await applyFanColor(pick);
            }}
          />
        </PanelSectionRow>
        {FAN_SELF_COLORED.has(fan.effect) && (
          <PanelSectionRow>
            <div style={{ padding: "0 16px 8px", fontSize: "0.85em", opacity: 0.75 }}>
              {fan.effect === "off"
                ? "This fan is dark."
                : fan.effect === "boil"
                ? "Uses the strip's colors. CPU load drives one half of the ring, GPU load the other."
                : FAN_STRIP_PORTS.has(fan.effect)
                ? "Uses the same colors as this effect on the strip."
                : "Rainbow makes its own colors."}
            </div>
          </PanelSectionRow>
        )}
        {fanCustom && (
          <>
            <PanelSectionRow>
              <SliderField
                label="Hue"
                value={fanHue}
                min={0}
                max={359}
                step={1}
                disabled={controlsOff}
                showValue
                onChange={(v) => {
                  setFanHue(v);
                  window.clearTimeout(timers.current.hue);
                  timers.current.hue = window.setTimeout(
                    () => applyFanColor(hueToHex(v)),
                    DEBOUNCE_MS
                  );
                }}
              />
            </PanelSectionRow>
            <Swatch hex={hueToHex(fanHue)} label="Color" />
          </>
        )}
        {bothFans ? (
          <>
            <PanelSectionRow>
              <ToggleField
                label="Treat as one strip"
                description="Run the effect across both fans instead of repeating it on each."
                checked={state.span}
                disabled={controlsOff}
                onChange={async (v) => {
                  setBusy(true);
                  await setSpan(v);
                  await refresh();
                  setBusy(false);
                }}
              />
            </PanelSectionRow>
            <PanelSectionRow>
              <ToggleField
                label="Mirror Fan B"
                description={
                  state.span
                    ? "Turn off Treat as one strip to mirror the second fan."
                    : "Fan B runs the effect the opposite way round, so the fans turn against each other."
                }
                checked={!!state.mirror}
                disabled={controlsOff || state.span}
                onChange={async (v) => {
                  setBusy(true);
                  await setMirror(v);
                  await refresh();
                  setBusy(false);
                }}
              />
            </PanelSectionRow>
          </>
        ) : (
          <PanelSectionRow>
            <ButtonItem layout="below" disabled={controlsOff} onClick={() => identify(fan.id, 5)}>
              Flash this fan
            </ButtonItem>
          </PanelSectionRow>
        )}
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            disabled={busy}
            onClick={async () => {
              await swap();
              await refresh();
            }}
          >
            Swap fan order
          </ButtonItem>
        </PanelSectionRow>
      </PanelSection>

      <PanelSection title="Fan diagnostics">
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            onClick={async () => {
              const d = await diagnostics();
              const found = (d.devices ?? []).map((x: any) => `${x.name} ${x.path}`).join(", ");
              const others = (d.holders ?? []).map((h: any) => `${h.name}(${h.pid})`).join(", ");
              setDiag(
                [
                  `root: ${d.root}`,
                  `found: ${found || "nothing"}`,
                  `open: ${d.connected}`,
                  `frames: ${d.frames}`,
                  `last frame: ${
                    d.seconds_since_frame == null ? "never" : d.seconds_since_frame + "s ago"
                  }`,
                  `enabled: ${d.enabled}, leds: ${d.leds}, ch: ${d.channel}`,
                  others ? `ALSO HELD BY: ${others}` : "no other holders",
                  d.last_write_error ? `write error: ${d.last_write_error}` : "",
                  d.error ? `error: ${d.error}` : "",
                ]
                  .filter(Boolean)
                  .join("\n")
              );
            }}
          >
            Run diagnostics
          </ButtonItem>
        </PanelSectionRow>
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            onClick={async () => {
              setDiag("running test pattern…");
              const r = await selfTest();
              setDiag(
                r.ok
                  ? `wrote red/green/blue to ${r.path}, then lit each channel alone (${Object.entries(
                      r.channels ?? {}
                    )
                      .map(([c, n]) => `ch${c}:${n}`)
                      .join(", ")}). Did both fans change?`
                  : `test failed at ${r.stage}: ${r.error}`
              );
            }}
          >
            Run test pattern
          </ButtonItem>
        </PanelSectionRow>
        {diag && (
          <PanelSectionRow>
            <div style={{ whiteSpace: "pre-wrap", fontSize: "0.8em", padding: "4px 16px 8px" }}>
              {diag}
            </div>
          </PanelSectionRow>
        )}
      </PanelSection>
    </>
  );
}

// ================================================================== shell
//
// Each panel owns its own state and does its own reads. Nothing is shared, so
// neither can overwrite the other's controls -- which is what went wrong when
// they were a single component.

function Content() {
  const [view, setView] = useState<string | null>(null);
  const [syncOn, setSyncOn] = useState(true);
  const [standbyOn, setStandbyOn] = useState(true);
  const [standbyMin, setStandbyMin] = useState(5);
  const [dimOn, setDimOn] = useState(false);
  const [dimActive, setDimActive] = useState(false);
  const minutesTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    getState()
      .then((s) => {
        setView([TAB_STRIP, TAB_FANS, TAB_SETTINGS].includes(s.view) ? s.view : TAB_STRIP);
        setSyncOn(s.sync_color);
        setStandbyOn(s.standby ?? true);
        setStandbyMin(s.standby_minutes ?? 5);
        setDimOn(!!s.download_dim);
        setDimActive(!!s.download_dim_active);
      })
      .catch(() => setView(TAB_STRIP));
  }, []);

  if (view === null) {
    return (
      <PanelSection>
        <PanelSectionRow>Loading…</PanelSectionRow>
      </PanelSection>
    );
  }

  const onTab = (t: string) => {
    setView(t);
    setViewCall(t);
  };

  // LB / RB (L1 / R1) move to the previous / next tab from anywhere in the panel.
  const TABS = [TAB_STRIP, TAB_FANS, TAB_SETTINGS];
  const onButtonDown = (evt: any) => {
    const b = evt?.detail?.button;
    if (b !== GamepadButton.BUMPER_LEFT && b !== GamepadButton.BUMPER_RIGHT) return;
    const step = b === GamepadButton.BUMPER_RIGHT ? 1 : TABS.length - 1;
    onTab(TABS[(TABS.indexOf(view) + step) % TABS.length]);
  };

  return (
    <Focusable onButtonDown={onButtonDown}>
      <PanelSection>
        <PanelSectionRow>
          <TabBar tab={view} onTab={onTab} />
        </PanelSectionRow>
      </PanelSection>

      {view === TAB_STRIP && <StripPanel key="strip" syncOn={syncOn} />}
      {view === TAB_FANS && <FanPanel key="fans" />}
      {view === TAB_SETTINGS && (
        <>
          <PanelSection title="Colors">
            <PanelSectionRow>
              <ToggleField
                label="Sync colors"
                description="A color picked for the strip or fans goes to both."
                checked={syncOn}
                onChange={(v) => {
                  setSyncOn(v);
                  setSync(v);
                }}
              />
            </PanelSectionRow>
          </PanelSection>

          <PanelSection title="Idle">
            <PanelSectionRow>
              <ToggleField
                label="Turn off when idle"
                description="Lights off when nothing is used or playing."
                checked={standbyOn}
                onChange={(v) => {
                  setStandbyOn(v);
                  setStandby(v);
                }}
              />
            </PanelSectionRow>
            {standbyOn && (
              <PanelSectionRow>
                <SliderField
                  label="Idle minutes"
                  value={standbyMin}
                  min={1}
                  max={30}
                  step={1}
                  showValue
                  onChange={(v) => {
                    setStandbyMin(v);
                    if (minutesTimer.current) clearTimeout(minutesTimer.current);
                    minutesTimer.current = setTimeout(() => setStandbyMinutes(v), DEBOUNCE_MS);
                  }}
                />
              </PanelSectionRow>
            )}
            <PanelSectionRow>
              <ToggleField
                label="Dim while downloading"
                description={
                  dimActive
                    ? "Downloading now: fans off, strip at its lowest."
                    : "Fans off and strip at its lowest while Steam downloads."
                }
                checked={dimOn}
                onChange={(v) => {
                  setDimOn(v);
                  setDownloadDim(v);
                }}
              />
            </PanelSectionRow>
          </PanelSection>

          <StripPanel key="strip-settings" syncOn={syncOn} mode="settings" />
        </>
      )}
    </Focusable>
  );
}

export default definePlugin(() => ({
  name: "BC-250 Lighting",
  titleView: <div className={staticClasses.Title}>BC-250 Lighting</div>,
  content: <Content />,
  icon: <FaLightbulb />,
}));
