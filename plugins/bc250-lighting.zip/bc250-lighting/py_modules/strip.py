"""
Front strip control for bc250_ws2812b_controller.

Talks to the `led` daemon by editing /etc/led-controller/config.json and
restarting the systemd unit. All daemon communication is confined to
_apply_config() / _systemctl() / get_state() -- to move to a control socket
later, reimplement those three and leave the rest alone.
"""

import json
import os
import shutil
import subprocess

import decky

CONFIG_PATH = "/etc/led-controller/config.json"
SERVICE = "led-controller"

# absolute path: Decky's backend does not inherit a normal login PATH
SYSTEMCTL = "/usr/bin/systemctl"

# which settings key each effect takes its color from. Most read a
# "palette" of comma-separated stops, where a single stop is a solid
# color; solid and alarm take a plain "color". The rest derive their
# colors internally and ignore both.
# Which settings key each effect takes its color through, from the daemon's
# effect table. Explicit sets rather than a default: an effect the plugin has
# never heard of gets no color control, because guessing "palette" gave every
# new effect a control the daemon then ignored.
COLOR_EFFECTS = {"solid", "alarm"}

# Two or three default stops. The picker writes one color (or two with blend),
# which is a reasonable stand-in for a palette that short.
PALETTE_EFFECTS = {
    "audio_music",
    "audio_ripple",
    "audio_spectrum",
    "aurora",
    "breathe",
    "comet",
    "drift",
    "ember",
    "pulse",
    "shoreline",
    "steam_download",
}

# Four or more stops, and the palette *is* the effect: ink sweeps fronts of
# five inks across each other, lava merges six, load maps its window onto CPU
# and GPU load. Collapsing that to one or two stops does not recolor them, it
# flattens them into a different, duller effect -- so they are left alone. The
# value is the number of stops the daemon ships, only used to explain why.
FIXED_PALETTE_EFFECTS = {
    "caustics": 4,
    "ink": 5,
    "lava": 6,
    "load": 5,
    "load_boil": 5,
    "orbit": 4,
    "plasma": 4,
    "silk": 5,
    "tide": 5,
}

# Documented as deriving their colors internally.
NO_COLOR_EFFECTS = {"rainbow", "cycle"}

# One-shot recordings, never pinnable, listed so they are not reported unknown.
RECORDED_EFFECTS = {"boot", "shutdown", "button_on", "button_off"}

KNOWN_EFFECTS = (
    COLOR_EFFECTS
    | PALETTE_EFFECTS
    | set(FIXED_PALETTE_EFFECTS)
    | NO_COLOR_EFFECTS
    | RECORDED_EFFECTS
)

# marks the rule this plugin inserts, so we can find and remove it again
# without disturbing the user's own rules. loadRules() ignores unknown keys.
OVERRIDE_KEY = "_decky_override"

# A pinned rule has no "if", so it always matches and nothing below it is ever
# evaluated. That is what makes pinning work -- and also what silences the
# download bar. Rules identified as download-driven can be kept above the pin
# so they still win while a download is running.
DOWNLOAD_MARKERS = ("steam_dl", "steam_download", "steamdl")

# make install puts `led` at $PREFIX/bin; check the usual prefixes
LED_CANDIDATES = [
    "/home/deck/.local/bin/led",
    "/usr/local/bin/led",
    "/usr/bin/led",
]


def _led_binary():
    for path in LED_CANDIDATES:
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return path
    return shutil.which("led")


def _clean_env():
    """Environment for subprocesses, with PyInstaller's bundle stripped out.

    Decky runs this backend from a PyInstaller bundle, which points
    LD_LIBRARY_PATH at its own /tmp/_MEI* directory. Children inherit that
    and load the bundled libcrypto/libssl instead of the system ones, so
    systemctl dies on a missing OPENSSL_3.x symbol version. PyInstaller
    saves the pre-launch values in *_ORIG, so restore those when present
    and drop the variable entirely otherwise.
    """
    env = os.environ.copy()

    for var in ("LD_LIBRARY_PATH", "LD_PRELOAD", "DYLD_LIBRARY_PATH"):
        original = env.pop(var + "_ORIG", None)
        if original:
            env[var] = original
        else:
            env.pop(var, None)

    return env


def _run(args, timeout=45):
    """Run a command, returning (rc, stdout, stderr). Never raises."""
    try:
        proc = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=_clean_env(),
        )
        return proc.returncode, proc.stdout.strip(), proc.stderr.strip()
    except Exception as exc:
        decky.logger.error("command failed: %s: %s", args, exc)
        return 1, "", str(exc)


def _systemctl(verb):
    rc, _, err = _run([SYSTEMCTL, verb, SERVICE])
    if rc != 0:
        decky.logger.error("systemctl %s failed: %s", verb, err)
    return rc == 0


# systemctl is-active does not only answer active/inactive. Straight after a
# restart it reports "activating", and the old check compared against the exact
# string "active" -- so every change made the panel believe the strip had gone
# off, flipping the toggle and disabling the controls while the strip was in
# fact running.
TRANSITIONAL = {"activating", "deactivating", "reloading", "refreshing"}
UP = {"active", "activating", "reloading", "refreshing"}


def _service_status():
    """Raw systemctl state: active, activating, inactive, failed, and so on."""
    _rc, out, _err = _run([SYSTEMCTL, "is-active", SERVICE])
    return out.strip().splitlines()[0].strip() if out.strip() else "unknown"


def _service_running():
    return _service_status() in UP


def _read_config():
    with open(CONFIG_PATH, "r") as handle:
        return json.load(handle)


def _write_config(cfg):
    """Write atomically so a crash mid-write can't leave invalid JSON."""
    tmp = CONFIG_PATH + ".decky-tmp"
    with open(tmp, "w") as handle:
        json.dump(cfg, handle, indent=4)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, CONFIG_PATH)


def _apply_config(mutate):
    """Read config, apply mutate(cfg), write it back, restart the daemon."""
    try:
        cfg = _read_config()
    except Exception as exc:
        decky.logger.error("could not read %s: %s", CONFIG_PATH, exc)
        return False

    mutate(cfg)

    try:
        _write_config(cfg)
    except Exception as exc:
        decky.logger.error("could not write %s: %s", CONFIG_PATH, exc)
        return False

    # only restart if it was already up; otherwise the user turned it off
    # deliberately and the new config applies whenever they turn it back on
    if _service_running():
        return _systemctl("restart")
    return True


def _is_download_rule(rule):
    """Whether this rule is the download progress bar.

    Matched on the effect name, or on the condition mentioning the download
    flag, so it works whatever shape the user's "if" takes.
    """
    if not isinstance(rule, dict):
        return False
    if rule.get(OVERRIDE_KEY):
        return False
    if str(rule.get("effect", "")).lower() == "steam_download":
        return True
    condition = rule.get("if")
    if condition is None:
        return False
    try:
        blob = json.dumps(condition).lower()
    except (TypeError, ValueError):
        blob = str(condition).lower()
    return any(marker in blob for marker in DOWNLOAD_MARKERS)


def has_download_rule(cfg=None):
    if cfg is None:
        try:
            cfg = _read_config()
        except Exception:  # noqa: BLE001
            return False
    return any(_is_download_rule(r) for r in cfg.get("rules", []) or [])


def _always_matches(rule):
    """A rule nothing can get past: no "if", or the literal always condition."""
    if not isinstance(rule, dict):
        return False
    condition = rule.get("if")
    if condition is None:
        return True
    return isinstance(condition, str) and condition.strip().lower() == "always"


def _insert_index(rules, keep_download):
    """Where the pinned rule goes.

    Rules are evaluated top to bottom and the first match wins, so the pin
    belongs after the download rules and before everything else. Scanning stops
    at the first rule that matches unconditionally: anything past it is already
    unreachable in the user's own config, and placing the pin beyond it would
    make the pin unreachable too.
    """
    if not keep_download:
        return 0

    index = 0
    for position, rule in enumerate(rules):
        if _always_matches(rule):
            break
        # a download rule without a condition would shadow the pin forever
        if _is_download_rule(rule) and rule.get("if") is not None:
            index = position + 1
    return index


def _strip_overrides(cfg):
    rules = cfg.get("rules")
    if isinstance(rules, list):
        cfg["rules"] = [
            r for r in rules
            if not (isinstance(r, dict) and r.get(OVERRIDE_KEY))
        ]


def _color_key(effect):
    """Settings key this effect takes a color through, or None.

    None covers both "this effect makes its own colors" and "no idea what this
    effect takes" -- _effect_known tells those apart for the panel.
    """
    if not effect:
        return None
    if effect in COLOR_EFFECTS:
        return "color"
    if effect in PALETTE_EFFECTS:
        return "palette"
    return None


def palette_stops(effect):
    """Stops in a fixed-palette effect's default, or 0 if it is not one."""
    return FIXED_PALETTE_EFFECTS.get(effect or "", 0)


def _effect_known(effect):
    return not effect or effect in KNOWN_EFFECTS


def _color_value(key, color, color2=None):
    """Build the settings value: a palette takes two stops, "color" one."""
    if key == "palette" and color2:
        return "%s,%s" % (color, color2)
    return color


def _current_override(cfg):
    for rule in cfg.get("rules", []) or []:
        if isinstance(rule, dict) and rule.get(OVERRIDE_KEY):
            return rule.get("effect")
    return None


# --------------------------------------------------------------- public API
#
# The daemon owns the serial port and runs effects on the receiver, so the
# strip is never driven frame by frame the way the fans are. We pin an effect
# by inserting a catch-all rule and restarting the unit.


def get_state():
    state = {
        "ok": False, "error": None, "running": False, "effects": [],
        "effect": None, "brightness": 1.0, "leds": 0,
        "colorKey": None, "color": None, "color2": None,
        "service": "unknown",
        "reverse": False,
        "effectKnown": True,
        "paletteStops": 0,
        "hasDownloadRule": False,
        "overrideAt": None,
    }

    led = _led_binary()
    if not led:
        state["error"] = "led binary not found; looked in " + ", ".join(LED_CANDIDATES)
        return state

    if not os.path.isfile(CONFIG_PATH):
        state["error"] = "no config at " + CONFIG_PATH
        return state

    rc, out, err = _run([led, "--list"])
    if rc != 0:
        state["error"] = err or "led --list failed"
        return state

    state["effects"] = sorted(line.strip() for line in out.splitlines() if line.strip())

    try:
        cfg = _read_config()
    except Exception as exc:  # noqa: BLE001
        state["error"] = "config is not valid JSON: %s" % exc
        return state

    strip_cfg = cfg.get("strip", {}) or {}
    state["brightness"] = float(strip_cfg.get("brightness", 1.0))
    state["reverse"] = bool(strip_cfg.get("reverse", False))
    state["leds"] = int(strip_cfg.get("leds", 0))
    state["effect"] = _current_override(cfg)
    rules = cfg.get("rules", []) or []
    state["hasDownloadRule"] = has_download_rule(cfg)
    state["overrideAt"] = next(
        (i for i, r in enumerate(rules) if isinstance(r, dict) and r.get(OVERRIDE_KEY)),
        None,
    )
    state["colorKey"] = _color_key(state["effect"])
    state["effectKnown"] = _effect_known(state["effect"])
    state["paletteStops"] = palette_stops(state["effect"])

    if state["colorKey"]:
        for rule in cfg.get("rules", []) or []:
            if isinstance(rule, dict) and rule.get(OVERRIDE_KEY):
                settings = rule.get("settings") or {}
                raw = settings.get(state["colorKey"])
                stops = [x.strip() for x in str(raw).split(",")] if raw else []
                state["color"] = stops[0] if stops else None
                state["color2"] = stops[1] if len(stops) > 1 else None
                break

    status = _service_status()
    state["service"] = status
    state["running"] = status in UP
    state["ok"] = True
    return state


def takes_color(effect):
    """Whether this effect can be given a colour at all."""
    return _color_key(effect) is not None


def takes_blend(effect):
    return _color_key(effect) == "palette"


def set_effect(name, color=None, color2=None, keep_download=True):
    def mutate(cfg):
        _strip_overrides(cfg)
        if name:
            rules = cfg.get("rules")
            if not isinstance(rules, list):
                rules = []
            entry = {"effect": name, OVERRIDE_KEY: True}
            key = _color_key(name)
            if key and color:
                entry["settings"] = {key: _color_value(key, color, color2)}
            at = _insert_index(rules, keep_download)
            cfg["rules"] = rules[:at] + [entry] + rules[at:]

    return _apply_config(mutate)


def move_override(keep_download):
    """Re-place an existing pin without changing which effect is pinned."""

    def mutate(cfg):
        rules = cfg.get("rules")
        if not isinstance(rules, list):
            return
        entry = next(
            (r for r in rules if isinstance(r, dict) and r.get(OVERRIDE_KEY)), None
        )
        if entry is None:
            return
        rest = [r for r in rules if r is not entry]
        at = _insert_index(rest, keep_download)
        cfg["rules"] = rest[:at] + [entry] + rest[at:]

    return _apply_config(mutate)


def set_color(value, value2=None):
    def mutate(cfg):
        for rule in cfg.get("rules", []) or []:
            if not (isinstance(rule, dict) and rule.get(OVERRIDE_KEY)):
                continue
            key = _color_key(rule.get("effect"))
            if not key:
                return
            settings = rule.get("settings")
            if not isinstance(settings, dict):
                settings = {}
            if value:
                settings[key] = _color_value(key, value, value2)
            else:
                settings.pop(key, None)
            if settings:
                rule["settings"] = settings
            else:
                rule.pop("settings", None)
            return

    return _apply_config(mutate)


def set_reverse(value):
    """Flip which physical end of the strip is LED 0.

    The steam_download effect has no direction of its own -- its only settings
    are palette and done_color -- so the bar's direction comes from the strip's
    own orientation. This is the daemon's strip.reverse, which remaps the whole
    strip, so every directional effect flips with it. That is what you want
    when the case has been physically turned: the strip really did change
    orientation, not just the download bar.
    """

    def mutate(cfg):
        cfg.setdefault("strip", {})["reverse"] = bool(value)

    return _apply_config(mutate)


def set_brightness(value):
    value = max(0.0, min(1.0, float(value)))

    def mutate(cfg):
        cfg.setdefault("strip", {})["brightness"] = round(value, 3)

    return _apply_config(mutate)


def set_power(on):
    return _systemctl("start" if on else "stop")


def restart():
    return _systemctl("restart")


def reachable():
    return bool(_led_binary()) and os.path.isfile(CONFIG_PATH)


def settling():
    """True while the unit is between states, so a reading now would be wrong."""
    return _service_status() in TRANSITIONAL
