"""
Front strip control for bc250_ws2812b_controller.

Talks to the `led` daemon by editing /etc/led-controller/config.json and
restarting the systemd unit. All daemon communication is confined to
_apply_config() / _systemctl() / get_state() -- to move to a control socket
later, reimplement those three and leave the rest alone.
"""

import json
import os
import shutil
import subprocess

import decky

import effect_schema

CONFIG_PATH = "/etc/led-controller/config.json"
SERVICE = "led-controller"

# absolute path: Decky's backend does not inherit a normal login PATH
SYSTEMCTL = "/usr/bin/systemctl"

# What each effect takes is read from the daemon's own effect sources (see
# effect_schema.py), so an effect added to the daemon gets its color control,
# its settings and its place in the list with no plugin change. The tables
# below are only the fallback for when neither the daemon checkout nor the
# bundled snapshot can be read.
#
# Which settings key each effect takes its color through. Explicit sets rather
# than a default: an effect the plugin has never heard of gets no color
# control, because guessing "palette" gave every new effect a control the
# daemon then ignored.
COLOR_EFFECTS = {"solid", "alarm"}

# Two or three default stops. The picker writes one color (or two with blend),
# which is a reasonable stand-in for a palette that short.
PALETTE_EFFECTS = {
    "audio_music",
    "audio_ripple",
    "audio_spectrum",
    "aurora",
    "breathe",
    "comet",
    "drift",
    "ember",
    "pulse",
    "shoreline",
    "progress",
    "steam_download",
}

# Four or more stops, and the palette *is* the effect: ink sweeps fronts of
# five inks across each other, lava merges six, load maps its window onto CPU
# and GPU load. Collapsing that to one or two stops does not recolor them, it
# flattens them into a different, duller effect -- so they are left alone. The
# value is the number of stops the daemon ships, only used to explain why.
FIXED_PALETTE_EFFECTS = {
    "caustics": 4,
    "ink": 5,
    "lava": 6,
    "load": 5,
    "load_boil": 5,
    "orbit": 4,
    "plasma": 4,
    "silk": 5,
    "tide": 5,
}

# Documented as deriving their colors internally.
NO_COLOR_EFFECTS = {"rainbow", "cycle"}

# One-shot recordings, never pinnable, listed so they are not reported unknown.
RECORDED_EFFECTS = {"boot", "shutdown", "button_on", "button_off"}

KNOWN_EFFECTS = (
    COLOR_EFFECTS
    | PALETTE_EFFECTS
    | set(FIXED_PALETTE_EFFECTS)
    | NO_COLOR_EFFECTS
    | RECORDED_EFFECTS
)

# marks the rule this plugin inserts, so we can find and remove it again
# without disturbing the user's own rules. The marker lives in the rule's
# "settings": the daemon's config check (led --check, run by make install)
# rejects unknown keys on a rule, while effects ignore unknown settings.
OVERRIDE_KEY = "_decky_override"


def _marked(rule, key):
    """Whether this rule carries one of our markers (in settings, or top level
    as written by 0.2.2 and older)."""
    if not isinstance(rule, dict):
        return False
    settings = rule.get("settings")
    return bool(rule.get(key) or (isinstance(settings, dict) and settings.get(key)))

# A pinned rule has no "if", so it always matches and nothing below it is ever
# evaluated. That is what makes pinning work -- and also what silences the
# download bar. Rules identified as download-driven can be kept above the pin
# so they still win while a download is running.
DOWNLOAD_MARKERS = (
    "steam_dl", "steam_download", "steamdl",
    "steam_launch", "steam_achievement",
)

# Idle standby. One rule at the very top of the list, keyed on a flag file the
# plugin creates when nobody has touched a controller, keyboard or mouse for a
# while. The daemon re-evaluates rules every 0.5 s and a file: condition is
# just a stat, so going dark and coming back needs no restart -- only putting
# the rule in does. The over-temperature alarm still wins over it.
STANDBY_KEY = "_decky_standby"
STANDBY_FLAG = "/run/bc250-led-standby"
STANDBY_RULE = {
    "if": "file:%s & !temp>85" % STANDBY_FLAG,
    "effect": "solid",
    "hold": 0,
    "settings": {"color": "000000", "level": 0.0, STANDBY_KEY: True},
}

# make install puts `led` at $PREFIX/bin; check the usual prefixes
LED_CANDIDATES = [
    "/home/deck/.local/bin/led",
    "/usr/local/bin/led",
    "/usr/bin/led",
]


def _led_binary():
    for path in LED_CANDIDATES:
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return path
    return shutil.which("led")


def _clean_env():
    """Environment for subprocesses, with PyInstaller's bundle stripped out.

    Decky runs this backend from a PyInstaller bundle, which points
    LD_LIBRARY_PATH at its own /tmp/_MEI* directory. Children inherit that
    and load the bundled libcrypto/libssl instead of the system ones, so
    systemctl dies on a missing OPENSSL_3.x symbol version. PyInstaller
    saves the pre-launch values in *_ORIG, so restore those when present
    and drop the variable entirely otherwise.
    """
    env = os.environ.copy()

    for var in ("LD_LIBRARY_PATH", "LD_PRELOAD", "DYLD_LIBRARY_PATH"):
        original = env.pop(var + "_ORIG", None)
        if original:
            env[var] = original
        else:
            env.pop(var, None)

    return env


def _run(args, timeout=45):
    """Run a command, returning (rc, stdout, stderr). Never raises."""
    try:
        proc = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=_clean_env(),
        )
        return proc.returncode, proc.stdout.strip(), proc.stderr.strip()
    except Exception as exc:
        decky.logger.error("command failed: %s: %s", args, exc)
        return 1, "", str(exc)


def _systemctl(verb):
    rc, _, err = _run([SYSTEMCTL, verb, SERVICE])
    if rc != 0:
        decky.logger.error("systemctl %s failed: %s", verb, err)
    return rc == 0


# systemctl is-active does not only answer active/inactive. Straight after a
# restart it reports "activating", and the old check compared against the exact
# string "active" -- so every change made the panel believe the strip had gone
# off, flipping the toggle and disabling the controls while the strip was in
# fact running.
TRANSITIONAL = {"activating", "deactivating", "reloading", "refreshing"}
UP = {"active", "activating", "reloading", "refreshing"}


def _service_status():
    """Raw systemctl state: active, activating, inactive, failed, and so on."""
    _rc, out, _err = _run([SYSTEMCTL, "is-active", SERVICE])
    return out.strip().splitlines()[0].strip() if out.strip() else "unknown"


def _service_running():
    return _service_status() in UP


def _read_config():
    with open(CONFIG_PATH, "r") as handle:
        return json.load(handle)


def _write_config(cfg):
    """Write atomically so a crash mid-write can't leave invalid JSON."""
    tmp = CONFIG_PATH + ".decky-tmp"
    with open(tmp, "w") as handle:
        json.dump(cfg, handle, indent=4)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, CONFIG_PATH)


def _move_markers(cfg):
    """Move 0.2.2's top-level rule markers into settings (see OVERRIDE_KEY)."""
    for rule in cfg.get("rules") or []:
        if not isinstance(rule, dict):
            continue
        for key in (OVERRIDE_KEY, STANDBY_KEY):
            if key in rule:
                settings = rule.get("settings")
                if not isinstance(settings, dict):
                    settings = rule["settings"] = {}
                settings[key] = rule.pop(key)


def _apply_config(mutate):
    """Read config, apply mutate(cfg), write it back, restart the daemon."""
    try:
        cfg = _read_config()
    except Exception as exc:
        decky.logger.error("could not read %s: %s", CONFIG_PATH, exc)
        return False

    mutate(cfg)
    _move_markers(cfg)

    try:
        _write_config(cfg)
    except Exception as exc:
        decky.logger.error("could not write %s: %s", CONFIG_PATH, exc)
        return False

    # only restart if it was already up; otherwise the user turned it off
    # deliberately and the new config applies whenever they turn it back on
    if _service_running():
        return _systemctl("restart")
    return True


def _is_download_rule(rule):
    """Whether this rule is the download progress bar.

    Matched on the effect name, or on the condition mentioning the download
    flag, so it works whatever shape the user's "if" takes.
    """
    if not isinstance(rule, dict):
        return False
    if _marked(rule, OVERRIDE_KEY):
        return False
    effect = str(rule.get("effect", "")).lower()
    if effect == "steam_download":
        return True
    # a one-shot or feed-driven effect (achievement, progress) only plays
    # while its event is happening, so it should win over a pin
    info = _info(effect)
    if info and info.get("transient") and effect not in RECORDED_EFFECTS:
        return True
    condition = rule.get("if")
    if condition is None:
        return False
    try:
        blob = json.dumps(condition).lower()
    except (TypeError, ValueError):
        blob = str(condition).lower()
    return any(marker in blob for marker in DOWNLOAD_MARKERS)


def has_download_rule(cfg=None):
    if cfg is None:
        try:
            cfg = _read_config()
        except Exception:  # noqa: BLE001
            return False
    return any(_is_download_rule(r) for r in cfg.get("rules", []) or [])


def _always_matches(rule):
    """A rule nothing can get past: no "if", or the literal always condition."""
    if not isinstance(rule, dict):
        return False
    condition = rule.get("if")
    if condition is None:
        return True
    return isinstance(condition, str) and condition.strip().lower() == "always"


def _insert_index(rules, keep_download):
    """Where the pinned rule goes.

    Rules are evaluated top to bottom and the first match wins, so the pin
    belongs after the download rules and before everything else. Scanning stops
    at the first rule that matches unconditionally: anything past it is already
    unreachable in the user's own config, and placing the pin beyond it would
    make the pin unreachable too.
    """
    # the standby rule always stays on top, above any pin
    start = 0
    while start < len(rules) and _is_standby_rule(rules[start]):
        start += 1
    if not keep_download:
        return start

    index = start
    for position, rule in enumerate(rules):
        if _always_matches(rule):
            break
        # a download rule without a condition would shadow the pin forever
        if _is_download_rule(rule) and rule.get("if") is not None:
            index = position + 1
    return index


def _is_standby_rule(rule):
    return _marked(rule, STANDBY_KEY)


def has_standby_rule(cfg=None):
    if cfg is None:
        try:
            cfg = _read_config()
        except Exception:  # noqa: BLE001
            return False
    rules = cfg.get("rules") or []
    return bool(rules) and _is_standby_rule(rules[0]) and rules[0].get("if") == STANDBY_RULE["if"]


def set_standby_rule(present):
    """Put the standby rule at the top of the list, or take it out."""
    try:
        if has_standby_rule() == bool(present):
            return True
    except Exception:  # noqa: BLE001
        pass

    def mutate(cfg):
        rules = cfg.get("rules")
        if not isinstance(rules, list):
            rules = []
        rules = [r for r in rules if not _is_standby_rule(r)]
        if present:
            rules.insert(0, json.loads(json.dumps(STANDBY_RULE)))
        cfg["rules"] = rules

    return _apply_config(mutate)


def _strip_overrides(cfg):
    rules = cfg.get("rules")
    if isinstance(rules, list):
        cfg["rules"] = [
            r for r in rules
            if not (_marked(r, OVERRIDE_KEY))
        ]


def _schema():
    try:
        schema, _origin = effect_schema.load()
        return schema or {}
    except Exception as exc:  # noqa: BLE001
        decky.logger.error("could not read effect schema: %s", exc)
        return {}


def _info(effect):
    """The daemon's description of one effect, or None if it has none."""
    if not effect:
        return None
    return _schema().get(effect)


def _color_key(effect):
    """Settings key this effect takes a color through, or None.

    None covers both "this effect makes its own colors" and "no idea what this
    effect takes" -- _effect_known tells those apart for the panel.
    """
    if not effect:
        return None
    info = _info(effect)
    if info is not None:
        return info.get("colorKey")
    if effect in COLOR_EFFECTS:
        return "color"
    if effect in PALETTE_EFFECTS:
        return "palette"
    return None


def palette_stops(effect):
    """Stops in a fixed-palette effect's default, or 0 if it is not one."""
    info = _info(effect)
    if info is not None:
        return info.get("paletteStops", 0) if info.get("fixedPalette") else 0
    return FIXED_PALETTE_EFFECTS.get(effect or "", 0)


def _effect_known(effect):
    return not effect or _info(effect) is not None or effect in KNOWN_EFFECTS


def transient_effects(names):
    """Effects with nothing to show as a pinned pick: they play once, or follow
    a feed (download or launch progress) that sits idle most of the time."""
    out = set(RECORDED_EFFECTS) | {"steam_download"}
    for name in names:
        info = _info(name)
        if info and info.get("transient"):
            out.add(name)
    return sorted(out)


def tunables(effect):
    """The numeric and on/off settings this effect reads, with defaults."""
    info = _info(effect)
    return list(info.get("settings") or []) if info else []


def _coerce(spec, value):
    """A panel value as the type the effect reads, or None to drop it."""
    try:
        if spec["type"] == "bool":
            return bool(value)
        if spec["type"] == "int":
            return int(round(float(value)))
        number = float(value)
        if number != number or number in (float("inf"), float("-inf")):
            return None
        return round(number, 4)
    except (TypeError, ValueError):
        return None


def _color_value(key, color, color2=None):
    """Build the settings value: a palette takes two stops, "color" one."""
    if key == "palette" and color2:
        return "%s,%s" % (color, color2)
    return color


def _current_override(cfg):
    for rule in cfg.get("rules", []) or []:
        if _marked(rule, OVERRIDE_KEY):
            return rule.get("effect")
    return None


# --------------------------------------------------------------- public API
#
# The daemon owns the serial port and runs effects on the receiver, so the
# strip is never driven frame by frame the way the fans are. We pin an effect
# by inserting a catch-all rule and restarting the unit.


def get_state():
    state = {
        "ok": False, "error": None, "running": False, "effects": [],
        "effect": None, "brightness": 1.0, "leds": 0,
        "colorKey": None, "color": None, "color2": None,
        "service": "unknown",
        "reverse": False,
        "effectKnown": True,
        "paletteStops": 0,
        "hasDownloadRule": False,
        "overrideAt": None,
        "transient": [],
        "summary": "",
        "settings": [],
        "schemaSource": None,
    }

    led = _led_binary()
    if not led:
        state["error"] = "led binary not found; looked in " + ", ".join(LED_CANDIDATES)
        return state

    if not os.path.isfile(CONFIG_PATH):
        state["error"] = "no config at " + CONFIG_PATH
        return state

    rc, out, err = _run([led, "--list"])
    if rc != 0:
        state["error"] = err or "led --list failed"
        return state

    state["effects"] = sorted(line.strip() for line in out.splitlines() if line.strip())
    state["transient"] = transient_effects(state["effects"])
    try:
        state["schemaSource"] = effect_schema.load()[1]
    except Exception:  # noqa: BLE001
        state["schemaSource"] = None

    try:
        cfg = _read_config()
    except Exception as exc:  # noqa: BLE001
        state["error"] = "config is not valid JSON: %s" % exc
        return state

    strip_cfg = cfg.get("strip", {}) or {}
    state["brightness"] = float(strip_cfg.get("brightness", 1.0))
    state["reverse"] = bool(strip_cfg.get("reverse", False))
    state["leds"] = int(strip_cfg.get("leds", 0))
    state["effect"] = _current_override(cfg)
    rules = cfg.get("rules", []) or []
    state["hasDownloadRule"] = has_download_rule(cfg)
    state["overrideAt"] = next(
        (i for i, r in enumerate(rules) if _marked(r, OVERRIDE_KEY)),
        None,
    )
    state["colorKey"] = _color_key(state["effect"])
    state["effectKnown"] = _effect_known(state["effect"])
    state["paletteStops"] = palette_stops(state["effect"])
    info = _info(state["effect"]) or {}
    state["summary"] = info.get("summary", "")

    override = next((r for r in rules if _marked(r, OVERRIDE_KEY)), None)
    current = (override or {}).get("settings") or {}
    if not isinstance(current, dict):
        current = {}
    settings = []
    for spec in tunables(state["effect"]):
        entry = dict(spec)
        value = current.get(spec["key"])
        entry["value"] = spec["default"] if value is None else value
        entry["changed"] = value is not None and value != spec["default"]
        settings.append(entry)
    state["settings"] = settings

    if state["colorKey"]:
        for rule in cfg.get("rules", []) or []:
            if _marked(rule, OVERRIDE_KEY):
                settings = rule.get("settings") or {}
                raw = settings.get(state["colorKey"])
                stops = [x.strip() for x in str(raw).split(",")] if raw else []
                state["color"] = stops[0] if stops else None
                state["color2"] = stops[1] if len(stops) > 1 else None
                break

    status = _service_status()
    state["service"] = status
    state["running"] = status in UP
    state["ok"] = True
    return state


def takes_color(effect):
    """Whether this effect can be given a colour at all."""
    return _color_key(effect) is not None


def takes_blend(effect):
    return _color_key(effect) == "palette"


def set_effect(name, color=None, color2=None, keep_download=True, tuning=None):
    specs = {s["key"]: s for s in tunables(name)}

    def mutate(cfg):
        _strip_overrides(cfg)
        if name:
            rules = cfg.get("rules")
            if not isinstance(rules, list):
                rules = []
            entry = {"effect": name, "settings": {OVERRIDE_KEY: True}}
            key = _color_key(name)
            if key and color:
                entry["settings"][key] = _color_value(key, color, color2)
            # settings remembered for this effect from the last time it was
            # tuned; only keys the effect still reads survive a daemon update
            for setting, value in (tuning or {}).items():
                spec = specs.get(setting)
                if spec is None:
                    continue
                value = _coerce(spec, value)
                if value is not None:
                    entry["settings"][setting] = value
            at = _insert_index(rules, keep_download)
            cfg["rules"] = rules[:at] + [entry] + rules[at:]

    return _apply_config(mutate)


def move_override(keep_download):
    """Re-place an existing pin without changing which effect is pinned."""

    def mutate(cfg):
        rules = cfg.get("rules")
        if not isinstance(rules, list):
            return
        entry = next(
            (r for r in rules if _marked(r, OVERRIDE_KEY)), None
        )
        if entry is None:
            return
        rest = [r for r in rules if r is not entry]
        at = _insert_index(rest, keep_download)
        cfg["rules"] = rest[:at] + [entry] + rest[at:]

    return _apply_config(mutate)


def set_color(value, value2=None):
    def mutate(cfg):
        for rule in cfg.get("rules", []) or []:
            if not (_marked(rule, OVERRIDE_KEY)):
                continue
            key = _color_key(rule.get("effect"))
            if not key:
                return
            settings = rule.get("settings")
            if not isinstance(settings, dict):
                settings = {}
            if value:
                settings[key] = _color_value(key, value, value2)
            else:
                settings.pop(key, None)
            if settings:
                rule["settings"] = settings
            else:
                rule.pop("settings", None)
            return

    return _apply_config(mutate)


def set_setting(key, value):
    """Set one of the pinned effect's settings; None puts back its default.

    Returns the value written (None when reset), or raises ValueError for a
    key the pinned effect does not read.
    """
    result = {"value": None, "effect": None}

    def mutate(cfg):
        for rule in cfg.get("rules", []) or []:
            if not _marked(rule, OVERRIDE_KEY):
                continue
            effect = rule.get("effect")
            spec = next((s for s in tunables(effect) if s["key"] == key), None)
            if spec is None:
                return
            settings = rule.get("settings")
            if not isinstance(settings, dict):
                settings = rule["settings"] = {}
            coerced = None if value is None else _coerce(spec, value)
            if coerced is None or coerced == spec["default"]:
                settings.pop(key, None)
            else:
                settings[key] = coerced
            result["value"] = settings.get(key)
            result["effect"] = effect
            return

    ok = _apply_config(mutate)
    return ok, result["effect"], result["value"]


def reset_settings():
    """Drop every tuned setting from the pinned effect, keeping its color."""
    result = {"effect": None}

    def mutate(cfg):
        for rule in cfg.get("rules", []) or []:
            if not _marked(rule, OVERRIDE_KEY):
                continue
            result["effect"] = rule.get("effect")
            settings = rule.get("settings")
            if isinstance(settings, dict):
                for spec in tunables(rule.get("effect")):
                    settings.pop(spec["key"], None)
            return

    ok = _apply_config(mutate)
    return ok, result["effect"]


def set_reverse(value):
    """Flip which physical end of the strip is LED 0.

    The steam_download effect has no direction of its own -- its only settings
    are palette and done_color -- so the bar's direction comes from the strip's
    own orientation. This is the daemon's strip.reverse, which remaps the whole
    strip, so every directional effect flips with it. That is what you want
    when the case has been physically turned: the strip really did change
    orientation, not just the download bar.
    """

    def mutate(cfg):
        cfg.setdefault("strip", {})["reverse"] = bool(value)

    return _apply_config(mutate)


def set_brightness(value):
    value = max(0.0, min(1.0, float(value)))

    def mutate(cfg):
        cfg.setdefault("strip", {})["brightness"] = round(value, 3)

    return _apply_config(mutate)


def set_power(on):
    return _systemctl("start" if on else "stop")


def restart():
    return _systemctl("restart")


def reachable():
    return bool(_led_binary()) and os.path.isfile(CONFIG_PATH)


def settling():
    """True while the unit is between states, so a reading now would be wrong."""
    return _service_status() in TRANSITIONAL
