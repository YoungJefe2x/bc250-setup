"""Live copy of what the front strip is showing, for the panel preview.

The led daemon mirrors every frame it sends to the receiver onto a local
datagram socket (its VirtualSink, /tmp/led-strip.sock), where its own
virtual-strip viewer listens. When nothing is bound there the daemon's send
is a no-op. The panel binds it only while the preview is on screen and lets
it go a few seconds after the last read, so the daemon is untouched and the
plugin costs nothing when the panel is closed.
"""

import os
import socket
import stat
import threading
import time

SOCK_PATH = "/tmp/led-strip.sock"
LINGER_S = 5.0  # keep listening this long after the panel last asked
SYNC0 = 0xAA
SYNC_8BIT = 0x55
SYNC_DEEP = 0x57
HEADER = 9


def parse(buf):
    """(count, [(r16, g16, b16)]) from one wire pixel frame, or None.

    Values are 8.8 fixed point (8-bit code x 256), already through the
    daemon's brightness/gamma/white-balance LUT.
    """
    if len(buf) < HEADER + 1 or buf[0] != SYNC0:
        return None
    count = buf[3] | (buf[4] << 8)
    if buf[1] == SYNC_DEEP:
        need = HEADER + count * 6 + 1
        if count == 0 or len(buf) < need:
            return None
        data = buf[HEADER:HEADER + count * 6]
        vals = [data[i] | (data[i + 1] << 8) for i in range(0, len(data), 2)]
    elif buf[1] == SYNC_8BIT:
        need = HEADER + count * 3 + 1
        if count == 0 or len(buf) < need:
            return None
        vals = [v << 8 for v in buf[HEADER:HEADER + count * 3]]
    else:
        return None
    return [tuple(vals[i:i + 3]) for i in range(0, len(vals), 3)]


class StripTap:
    def __init__(self, logger=None):
        self._lock = threading.Lock()
        self._thread = None
        self._wanted_at = 0.0
        self._frame = None
        self._frame_at = 0.0
        self._log = logger
        self.error = None

    def latest(self, max_age=1.0):
        """The last frame if one arrived recently; also keeps the tap open."""
        with self._lock:
            self._wanted_at = time.monotonic()
            if self._thread is None or not self._thread.is_alive():
                self._thread = threading.Thread(target=self._run, daemon=True)
                self._thread.start()
            if self._frame is not None and time.monotonic() - self._frame_at <= max_age:
                return self._frame
            return None

    def _bind(self):
        try:
            mode = os.lstat(SOCK_PATH).st_mode
            if not stat.S_ISSOCK(mode):
                self.error = "%s exists and is not a socket" % SOCK_PATH
                return None
            # a socket file nobody is bound to (a viewer that crashed, or
            # this plugin's own after a restart) is safe to replace; a live
            # one belongs to someone's viewer, so leave it alone
            probe = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
            try:
                probe.connect(SOCK_PATH)
                self.error = "another strip viewer is running"
                return None
            except OSError:
                os.unlink(SOCK_PATH)
            finally:
                probe.close()
        except FileNotFoundError:
            pass
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        sock.bind(SOCK_PATH)
        sock.settimeout(0.5)
        self.error = None
        return sock

    def _run(self):
        try:
            sock = self._bind()
        except OSError as exc:
            self.error = "could not listen on %s: %s" % (SOCK_PATH, exc)
            sock = None
        if sock is None:
            if self._log:
                self._log.info("strip preview unavailable: %s", self.error)
            time.sleep(LINGER_S)
            return
        try:
            while time.monotonic() - self._wanted_at < LINGER_S:
                try:
                    buf = sock.recv(16384)
                except socket.timeout:
                    continue
                pixels = parse(buf)
                if pixels:
                    with self._lock:
                        self._frame = pixels
                        self._frame_at = time.monotonic()
        finally:
            sock.close()
            try:
                os.unlink(SOCK_PATH)
            except OSError:
                pass
