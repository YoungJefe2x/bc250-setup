"""What each strip effect takes, read from the led daemon's own source.

The daemon only answers `led --list` with bare names, so everything else the
panel needs -- which key carries the color, how many stops the default palette
has, which settings an effect reads and their defaults, whether it is a
one-shot or driven by host data -- is read from the effect sources the setup
tool keeps checked out next to the build. Each effect file reads its tuning
through cfg.get/getInt/getFloat/getBool/getColor("key", default) and documents
the keys in a "config:" comment block, so a newly added effect is understood
as soon as the daemon is updated, with no plugin change.

When the checkout is missing, a snapshot generated from the daemon at build
time (effects.json next to the plugin) stands in. Run this file directly to
regenerate it:

    python3 py_modules/effect_schema.py /path/to/bc250_ws2812b_controller > effects.json
"""

import json
import math
import os
import re
import sys

SOURCE_CANDIDATES = [
    "/opt/bc250/bc250_ws2812b_controller",
]

SNAPSHOT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "effects.json")

# settings that are plumbing, not tuning: shown nowhere in the panel
INTERNAL_KEYS = {"frame_ms", "source", "effects", "order", "sensors"}

# a palette of this many stops or more is the effect itself (ink's five inks,
# lava's six): one or two picked colors would flatten it, so it is left alone
FIXED_PALETTE_MIN_STOPS = 4

_REGISTER = re.compile(r'REGISTER_EFFECT\(\s*"([A-Za-z0-9_]+)"\s*,\s*(\w+)\s*\)')
_CALL = re.compile(r'\bcfg\.(get|getInt|getFloat|getBool|getColor)\(\s*"([A-Za-z0-9_]+)"')
_STRING = re.compile(r'\s*"((?:[^"\\]|\\.)*)"')
_NUMBER = re.compile(r'\s*(-?(?:\d+\.?\d*|\.\d+)(?:[eE]-?\d+)?)[fF]?\s*\)')
_HEXNUM = re.compile(r'\s*0[xX]([0-9a-fA-F]{1,6})\s*\)')
_BOOL = re.compile(r'\s*(true|false)\s*\)')
_RANGE = re.compile(r'(-?\d+(?:\.\d+)?)\s*\.\.\s*(-?\d+(?:\.\d+)?)')
_HEX6 = re.compile(r'[0-9a-fA-F]{6}')

_KIND = {
    "get": "string",
    "getInt": "int",
    "getFloat": "float",
    "getBool": "bool",
    "getColor": "color",
}


def _default(kind, rest):
    """The literal default following the key, or None when it is computed."""
    if not rest.startswith(","):
        return None
    rest = rest[1:]
    if kind == "string":
        # adjacent literals concatenate: "a,b,"\n "c,d"
        parts = []
        pos = 0
        while True:
            m = _STRING.match(rest, pos)
            if not m:
                break
            parts.append(m.group(1))
            pos = m.end()
        if not parts or not re.match(r"\s*\)", rest[pos:]):
            return None
        return "".join(parts)
    if kind == "color":
        m = _HEXNUM.match(rest)
        return "%06x" % int(m.group(1), 16) if m else None
    if kind == "bool":
        m = _BOOL.match(rest)
        return (m.group(1) == "true") if m else None
    m = _NUMBER.match(rest)
    if not m:
        return None
    value = float(m.group(1))
    return int(value) if kind == "int" else value


def _doc(text):
    """key -> description from the effect's "config:" comment block."""
    lines = text.splitlines()
    docs = {}
    start = None
    for i, line in enumerate(lines):
        if re.match(r"\s*//\s*config:\s*$", line):
            start = i + 1
            break
    if start is None:
        return docs
    key = None
    for line in lines[start:]:
        m = re.match(r"\s*//(.*)$", line)
        if not m:
            break
        body = m.group(1)
        if not body.strip():
            key = None
            continue
        # a key line is indented a little; its continuations line up further in
        head = re.match(r"\s{1,4}([A-Za-z0-9_]+)(?:\s+(.*))?$", body)
        if head and not body.startswith(" " * 5):
            key = head.group(1)
            docs[key] = (head.group(2) or "").strip()
        elif key:
            docs[key] = (docs[key] + " " + body.strip()).strip()
    return docs


def _summary(text, class_name):
    """The comment paragraph that introduces the effect, first sentence only."""
    lines = text.splitlines()
    idx = next((i for i, l in enumerate(lines) if re.match(r"\s*class\s+%s\b" % class_name, l)), None)
    if idx is None:
        return ""
    block = []
    i = idx - 1
    while i >= 0 and lines[i].strip().startswith("//"):
        block.insert(0, lines[i].strip()[2:].strip())
        i -= 1
    para = []
    for line in block:
        if not line or line.startswith("config:"):
            break
        para.append(line)
    text = " ".join(para)
    m = re.match(r"(.+?[.!?])(\s|$)", text)
    return (m.group(1) if m else text)[:200]


def _range(key, kind, default, doc):
    """A slider range: the documented one when there is one, else around the default."""
    lo, hi = _raw_range(kind, default, doc)
    # a period, a duration or a rate of zero stalls or divides by zero
    if lo <= 0 < hi and re.search(r"seconds|period|speed|per_second|rate", key):
        lo = hi / 100.0 if kind == "float" else max(1, lo)
    return lo, hi


def _raw_range(kind, default, doc):
    m = _RANGE.search(doc or "")
    if m:
        lo, hi = float(m.group(1)), float(m.group(2))
        if hi > lo:
            return lo, hi
    if kind == "int":
        d = int(default or 0)
        return 0, max(4, d * 3)
    d = float(default or 0.0)
    if d < 0:
        return d * 3, -d * 3
    if d == 0:
        return 0.0, 1.0
    if d <= 1.0:
        return 0.0, 1.0 if d <= 0.5 else 2.0
    return 0.0, _nice_ceil(d * 3)


def _nice_ceil(x):
    """Round up to 1, 2 or 5 times a power of ten, so the slider reads cleanly."""
    exp = 10 ** math.floor(math.log10(x))
    for m in (1, 2, 5, 10):
        if x <= m * exp + 1e-9:
            return float(m * exp)
    return float(10 * exp)


def parse_effect_file(text):
    """Every effect registered in one source file, as {name: schema}."""
    found = {}
    for name, class_name in _REGISTER.findall(text):
        settings = {}
        docs = _doc(text)
        for m in _CALL.finditer(text):
            kind = _KIND[m.group(1)]
            key = m.group(2)
            default = _default(kind, text[m.end():m.end() + 400])
            prev = settings.get(key)
            # a key read twice (once with a computed default) keeps the literal
            if prev and prev.get("default") is not None and default is None:
                continue
            settings[key] = {"type": kind, "default": default, "doc": docs.get(key, "")}

        one_shot = "finished() const override" in text and name != "cycle"
        host_driven = "source" in settings

        color_key = None
        stops = 0
        if "palette" in settings:
            color_key = "palette"
            raw = settings["palette"]["default"]
            # a palette defaulting to another key (button_on's color) is one stop
            stops = len(_HEX6.findall(raw)) if raw else 1
        elif "color" in settings:
            color_key = "color"
            stops = 1

        fixed = color_key == "palette" and stops >= FIXED_PALETTE_MIN_STOPS

        tunables = []
        for key, info in settings.items():
            if key in INTERNAL_KEYS or info["type"] in ("string", "color"):
                continue
            if info["default"] is None and info["type"] != "bool":
                continue
            entry = {
                "key": key,
                "type": info["type"],
                "default": info["default"] if info["default"] is not None else False,
                "doc": info["doc"],
            }
            if info["type"] != "bool":
                lo, hi = _range(key, info["type"], info["default"], info["doc"])
                entry["min"] = lo
                entry["max"] = hi
            tunables.append(entry)

        found[name] = {
            "name": name,
            "summary": _summary(text, class_name),
            "colorKey": None if fixed else color_key,
            "paletteStops": stops if color_key == "palette" else 0,
            "fixedPalette": fixed,
            "defaultColors": _HEX6.findall(settings.get(color_key, {}).get("default") or "")
            if color_key
            else [],
            "oneShot": one_shot,
            "hostDriven": host_driven,
            # nothing to show as a pinned pick: plays once, or follows a feed
            # (download/launch progress) that sits idle most of the time
            "transient": one_shot or host_driven,
            "settings": tunables,
        }
    return found


def scan(root):
    """Parse every effect under <root>/daemon/effects; {} if it is not there."""
    effects_dir = os.path.join(root, "daemon", "effects")
    out = {}
    try:
        names = sorted(os.listdir(effects_dir))
    except OSError:
        return out
    for fname in names:
        if not fname.endswith(".cpp"):
            continue
        try:
            with open(os.path.join(effects_dir, fname), "r", errors="replace") as handle:
                out.update(parse_effect_file(handle.read()))
        except OSError:
            continue
    return out


_cache = {"key": None, "value": None}


def _source_stamp(root):
    effects_dir = os.path.join(root, "daemon", "effects")
    try:
        return max(
            os.stat(os.path.join(effects_dir, f)).st_mtime
            for f in os.listdir(effects_dir)
            if f.endswith(".cpp")
        )
    except (OSError, ValueError):
        return None


def load():
    """(schema, origin): from the daemon checkout when present, else the snapshot.

    Cached until a source file changes, so `led --update` is picked up on the
    next panel read without rescanning thirty files every refresh.
    """
    for root in SOURCE_CANDIDATES:
        stamp = _source_stamp(root)
        if stamp is None:
            continue
        key = (root, stamp)
        if _cache["key"] != key:
            schema = scan(root)
            if not schema:
                continue
            _cache["key"] = key
            _cache["value"] = (schema, root)
        return _cache["value"]

    if _cache["key"] != "snapshot":
        try:
            with open(SNAPSHOT, "r") as handle:
                _cache["value"] = (json.load(handle), "snapshot")
        except (OSError, ValueError):
            _cache["value"] = ({}, None)
        _cache["key"] = "snapshot"
    return _cache["value"]


if __name__ == "__main__":
    root = sys.argv[1] if len(sys.argv) > 1 else SOURCE_CANDIDATES[0]
    json.dump(scan(root), sys.stdout, indent=1, sort_keys=True)
    sys.stdout.write("\n")
