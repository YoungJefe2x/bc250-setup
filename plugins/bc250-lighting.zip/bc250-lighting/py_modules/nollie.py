"""Direct HID driver for Nollie ARGB controllers.

Ported from the OpenRGB NollieController driver (GPL-2.0-or-later,
Controllers/NollieController). Talking to the device directly means no OpenRGB
server, no AppImage, and no udev rules -- which matters on SteamOS, where
/etc/udev/rules.d does not survive an update. Decky runs this backend as root,
so /dev/hidraw* is directly writable.

Wire format for the small controllers (1CH, 8CH, 28):
    65-byte output reports.
    byte 0      report id, always 0
    byte 1      packet_id + channel * packet_interval
    byte 2..    three bytes per LED
    Up to 21 LEDs per packet; longer chains span several packets.
    A separate report with byte 1 = 0xFF latches the frame.

Byte order is GRB on these models, not RGB.
"""

import glob
import os
import re

# (vid, pid) -> descriptor. Interface is None when the device is not composite;
# the OS2_1 firmware exposes RGB on a specific interface and other HID nodes
# alongside it, so writing to the wrong node silently does nothing.
KNOWN_DEVICES = {
    (0x16D2, 0x1F11): {"name": "Nollie 1CH", "channels": 1, "interface": None, "power": "usb"},
    (0x16D5, 0x1F11): {"name": "Nollie 1CH (OS2)", "channels": 1, "interface": None, "power": "usb"},
    (0x16D5, 0x2A01): {"name": "Nollie 1CH (OS2_1)", "channels": 1, "interface": 2, "power": "usb"},
    (0x16D2, 0x1F01): {"name": "Nollie 8CH", "channels": 8, "interface": None, "power": "sata"},
    (0x16D5, 0x1F01): {"name": "Nollie 8CH (OS2)", "channels": 8, "interface": None, "power": "sata"},
    (0x16D5, 0x2A08): {"name": "Nollie 8CH (OS2_1)", "channels": 8, "interface": 2, "power": "sata"},
    (0x16D2, 0x1616): {"name": "Nollie 28", "channels": 28, "interface": None, "power": "sata"},
    (0x16D2, 0x1617): {"name": "Nollie 28 L1", "channels": 28, "interface": None, "power": "sata"},
    (0x16D2, 0x1618): {"name": "Nollie 28 L2", "channels": 28, "interface": None, "power": "sata"},
}

# Spacing between one channel's packet ids. Differs per model; using the wrong
# value writes into another channel's address space.
PACKET_INTERVAL = {
    0x1F11: 30,  # Nollie 1
    0x2A01: 30,
    0x1F01: 6,  # Nollie 8
    0x2A08: 6,
    0x1616: 2,  # Nollie 28
    0x1617: 2,
    0x1618: 2,
}

REPORT_SIZE = 65
LEDS_PER_PACKET = 21
CMD_LATCH = 0xFF
CMD_INIT = 0xFE
CMD_INIT_SUB = 0x03

_HID_ID = re.compile(r"HID_ID=([0-9A-Fa-f]+):([0-9A-Fa-f]+):([0-9A-Fa-f]+)")
_IFACE = re.compile(r":\d+\.(\d+)/")


def _read_uevent(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            return handle.read()
    except OSError:
        return ""


def holders(path):
    """PIDs with this hidraw node open, excluding us.

    Two processes writing the same controller at 30 fps fight, and the visible
    result is fans that look dead or flicker. An old copy of the plugin left
    installed is the usual cause.
    """
    found = []
    me = os.getpid()
    for proc in glob.glob("/proc/[0-9]*"):
        try:
            pid = int(os.path.basename(proc))
        except ValueError:
            continue
        if pid == me:
            continue
        for fd in glob.glob(proc + "/fd/*"):
            try:
                if os.readlink(fd) == path:
                    try:
                        with open(proc + "/comm", "r") as handle:
                            name = handle.read().strip()
                    except OSError:
                        name = "?"
                    found.append({"pid": pid, "name": name})
                    break
            except OSError:
                continue
    return found


def find_devices():
    """Every attached Nollie, with the hidraw node to write to."""
    found = []

    for sys_path in sorted(glob.glob("/sys/class/hidraw/hidraw*")):
        node = os.path.basename(sys_path)
        uevent = _read_uevent(os.path.join(sys_path, "device", "uevent"))

        match = _HID_ID.search(uevent)
        if not match:
            continue

        vid = int(match.group(2), 16)
        pid = int(match.group(3), 16)
        info = KNOWN_DEVICES.get((vid, pid))
        if not info:
            continue

        # Composite devices expose several hidraw nodes for one vid/pid. The
        # USB interface number is only visible in the sysfs path.
        real = os.path.realpath(sys_path)
        iface_match = _IFACE.search(real + "/")
        interface = int(iface_match.group(1)) if iface_match else None

        if info["interface"] is not None and interface != info["interface"]:
            continue

        device = "/dev/" + node
        found.append(
            {
                "path": device,
                "vid": vid,
                "pid": pid,
                "name": info["name"],
                "channels": info["channels"],
                "power": info.get("power", "usb"),
                "interface": interface,
                "writable": os.access(device, os.W_OK),
            }
        )

    return found


class Nollie:
    def __init__(self, path, pid):
        self.path = path
        self.pid = pid
        self.interval = PACKET_INTERVAL.get(pid, 25)
        self._fd = None

    def open(self):
        if self._fd is None:
            self._fd = os.open(self.path, os.O_WRONLY)
        return self

    def close(self):
        if self._fd is not None:
            try:
                os.close(self._fd)
            except OSError:
                pass
            self._fd = None

    def __enter__(self):
        return self.open()

    def __exit__(self, *_):
        self.close()

    def _write(self, buf):
        if self._fd is None:
            self.open()
        os.write(self._fd, bytes(buf))

    def set_led_counts(self, counts):
        """Tell the controller how many LEDs sit on each channel.

        Without this it does not know where the chain ends, and trailing LEDs
        keep whatever the onboard effect last left there.
        """
        buf = bytearray(REPORT_SIZE)
        buf[1] = CMD_INIT
        buf[2] = CMD_INIT_SUB
        for i, count in enumerate(counts):
            buf[3 + i * 2] = count & 0xFF
            buf[4 + i * 2] = (count >> 8) & 0xFF
        self._write(buf)

    def set_channel(self, channel, pixels):
        """Queue one channel's pixels. Call latch() to display them."""
        index = 0
        packet_id = 0

        while index < len(pixels):
            chunk = pixels[index : index + LEDS_PER_PACKET]
            buf = bytearray(REPORT_SIZE)
            buf[1] = packet_id + channel * self.interval

            for i, (r, g, b) in enumerate(chunk):
                # GRB, not RGB, on these models
                buf[2 + i * 3] = g & 0xFF
                buf[3 + i * 3] = r & 0xFF
                buf[4 + i * 3] = b & 0xFF

            self._write(buf)
            index += LEDS_PER_PACKET
            packet_id += 1

    def latch(self):
        buf = bytearray(REPORT_SIZE)
        buf[1] = CMD_LATCH
        self._write(buf)

    def show(self, pixels, channel=0):
        self.set_channel(channel, pixels)
        self.latch()

    def show_many(self, frames):
        """Display several channels as one update.

        frames maps channel index to its pixel list. Every channel is queued
        before the single latch, so a multi-channel controller updates all its
        fans on the same frame instead of tearing across them.
        """
        for channel, pixels in sorted(frames.items()):
            self.set_channel(channel, pixels)
        self.latch()
