"""Frame generators and the current budget that keeps them honest.

A WS2812B pixel draws roughly 20 mA per lit channel, so about 60 mA at full
white. Every effect runs through clamp() before it reaches a backend, which
scales frames down so a zone can never exceed its configured milliamp ceiling
no matter what the user picks in the UI.
"""

import colorsys
import math

MA_PER_CHANNEL = 20.0 / 255.0  # milliamps per unit of an 8-bit channel

# Perceived brightness is roughly the 2.2 power of emitted light, so scaling a
# frame linearly makes the top of the slider feel flat and leaves no usable
# range at the bottom -- 5% linear is still 12/255 on every channel, which is
# dimmer but not dim. Raising the slider position to this power spreads the
# useful travel across the whole slider and lets the low end reach genuinely
# faint output.
GAMMA = 2.2


def estimate_ma(pixels):
    """Worst-case draw of one frame, in milliamps."""
    total = 0
    for r, g, b in pixels:
        total += (r + g + b) * MA_PER_CHANNEL
    return total


def perceptual(brightness):
    """Slider percentage -> linear scale factor."""
    return (max(0.0, min(100.0, brightness)) / 100.0) ** GAMMA


def clamp(pixels, brightness, budget_ma):
    """Apply user brightness, then scale the whole frame under the current budget."""
    scale = perceptual(brightness)

    if scale <= 0.0:
        return [(0, 0, 0)] * len(pixels)

    # round rather than truncate: at the dim end, int() throws away most of
    # what little signal is left
    scaled = [
        (
            int(r * scale + 0.5),
            int(g * scale + 0.5),
            int(b * scale + 0.5),
        )
        for r, g, b in pixels
    ]

    # Below about 8% the gamma curve rounds everything to zero, which would
    # turn the bottom of the slider into an off switch. Rescale so the
    # brightest pixel lands on 1/255 -- the dimmest the hardware can show --
    # keeping the relative shape of the frame.
    peak_in = max((max(px) for px in pixels), default=0)
    peak_out = max((max(px) for px in scaled), default=0)
    if peak_in > 0 and peak_out == 0:
        rescue = 1.0 / peak_in
        scaled = [
            (
                int(r * rescue + 0.5),
                int(g * rescue + 0.5),
                int(b * rescue + 0.5),
            )
            for r, g, b in pixels
        ]

    if budget_ma <= 0:
        return scaled

    draw = estimate_ma(scaled)
    if draw <= budget_ma:
        return scaled

    headroom = budget_ma / draw
    return [
        (int(r * headroom), int(g * headroom), int(b * headroom))
        for r, g, b in scaled
    ]


# ------------------------------------------------------------------- effects


def solid(count, color, _t):
    return [tuple(color)] * count


def breathe(count, color, t, period=4.0):
    phase = (math.sin(2 * math.pi * t / period) + 1) / 2
    level = 0.15 + 0.85 * phase
    r, g, b = color
    return [(int(r * level), int(g * level), int(b * level))] * count


def rainbow(count, _color, t, period=6.0):
    frame = []
    for i in range(count):
        hue = ((t / period) + (i / max(count, 1))) % 1.0
        r, g, b = colorsys.hsv_to_rgb(hue, 1.0, 1.0)
        frame.append((int(r * 255), int(g * 255), int(b * 255)))
    return frame


def comet(count, color, t, period=2.5, tail=0.35):
    head = ((t / period) % 1.0) * count
    r, g, b = color
    frame = []
    for i in range(count):
        distance = (head - i) % count
        level = max(0.0, 1.0 - distance / (count * tail))
        frame.append((int(r * level), int(g * level), int(b * level)))
    return frame


# --------------------------------------------------------------- ring helpers
#
# A fan's LEDs are a closed ring, so position is an angle, not an offset. Every
# effect below wraps: the value at the last pixel meets the value at the first
# without a seam, which is what stops a rotating effect from visibly stuttering
# once per revolution.


def _arc_distance(a, b, count):
    """Shortest way round the ring between two pixel positions, in pixels."""
    raw = abs(a - b) % count
    return min(raw, count - raw)


def _hash01(*parts):
    """Deterministic pseudo-random float in [0, 1).

    Effects are rendered statelessly from (index, time), so randomness has to
    be reproducible per pixel rather than drawn fresh each frame -- otherwise
    a sparkle would re-roll 30 times a second and just look like noise.
    """
    h = 2166136261
    for value in parts:
        h ^= int(value) & 0xFFFFFFFF
        h = (h * 16777619) & 0xFFFFFFFF
    return h / 4294967296.0


def _noise(index, t, speed=1.0):
    """Smooth per-pixel value noise: lerp between successive random levels."""
    phase = t * speed
    step = math.floor(phase)
    frac = phase - step
    a = _hash01(index, step)
    b = _hash01(index, step + 1)
    # smoothstep, so the flicker eases rather than ramping linearly
    frac = frac * frac * (3 - 2 * frac)
    return a + (b - a) * frac


def _scale(color, level):
    level = max(0.0, min(1.0, level))
    r, g, b = color
    return (int(r * level), int(g * level), int(b * level))


def _shift_hue(color, delta):
    r, g, b = (c / 255.0 for c in color)
    h, s, v = colorsys.rgb_to_hsv(r, g, b)
    r, g, b = colorsys.hsv_to_rgb((h + delta) % 1.0, s, v)
    return (int(r * 255), int(g * 255), int(b * 255))


# -------------------------------------------------------------- ring effects


def spin(count, color, t, period=2.0, width=0.3):
    """A lit arc sweeping round the ring, like a blade catching the light."""
    head = (t / period) * count
    span = max(1.0, width * count)
    frame = []
    for i in range(count):
        # measured behind the head so the arc trails rather than straddles
        behind = (head - i) % count
        level = max(0.0, 1.0 - behind / span)
        frame.append(_scale(color, level * level))
    return frame


def orbit(count, color, t, period=1.6, dots=2, size=1.6):
    """Evenly spaced dots circling the ring — reads as a spinning fan."""
    head = (t / period) * count
    frame = []
    for i in range(count):
        level = 0.0
        for n in range(dots):
            centre = (head + n * count / dots) % count
            level = max(level, 1.0 - _arc_distance(i, centre, count) / size)
        frame.append(_scale(color, max(0.0, level)))
    return frame


def chase(count, color, t, spacing=3, period=0.9):
    """Theater chase: every third pixel lit, the pattern stepping round."""
    offset = int((t / period) * spacing) % spacing
    return [
        _scale(color, 1.0 if (i - offset) % spacing == 0 else 0.05)
        for i in range(count)
    ]


def wave(count, color, t, period=3.0, waves=2):
    """Standing brightness waves rotating round the ring.

    waves must divide evenly into the circle or the pattern would break at the
    wrap point, so the count is folded into the angle rather than the index.
    """
    frame = []
    for i in range(count):
        angle = 2 * math.pi * (waves * i / count - t / period)
        level = 0.12 + 0.88 * (math.sin(angle) + 1) / 2
        frame.append(_scale(color, level))
    return frame


def twinkle(count, color, t, period=1.7, density=0.55):
    """Sparkles fading in and out over a dim base.

    Each pixel keeps its own phase, derived from its index, so a given LED
    twinkles on its own schedule instead of the whole ring pulsing together.
    """
    frame = []
    for i in range(count):
        phase = (t / period + _hash01(i, 7)) % 1.0
        # triangle wave: rise then fall
        level = 1.0 - abs(phase * 2 - 1)
        lit = _hash01(i, int(t / period) + 11) < density
        frame.append(_scale(color, 0.08 + 0.92 * level if lit else 0.08))
    return frame


def fire(count, color, t, speed=2.2):
    """Flicker in the chosen hue, hot centres cooling at the edges."""
    frame = []
    for i in range(count):
        level = 0.25 + 0.75 * _noise(i, t, speed)
        # hotter pixels ride toward yellow, cooler ones sink toward red
        shifted = _shift_hue(color, 0.04 * (level - 0.5))
        frame.append(_scale(shifted, level))
    return frame


def split(count, color, t, period=5.0):
    """Two complementary halves rotating — strong colour contrast per fan."""
    other = _shift_hue(color, 0.5)
    head = (t / period) * count
    frame = []
    for i in range(count):
        ahead = (i - head) % count
        near = ahead < count / 2
        # feather the two joins so the halves blend instead of hard-cutting
        edge = min(ahead, count - ahead, abs(ahead - count / 2))
        blend = min(1.0, edge / max(1.0, count * 0.08))
        a, b = (color, other) if near else (other, color)
        mixed = tuple(int(a[c] * blend + ((a[c] + b[c]) / 2) * (1 - blend)) for c in range(3))
        frame.append(mixed)
    return frame


def glow(count, color, t, period=9.0, spread=0.07):
    """The whole ring drifting slowly around the chosen hue."""
    delta = spread * math.sin(2 * math.pi * t / period)
    shifted = _shift_hue(color, delta)
    level = 0.65 + 0.35 * (math.sin(2 * math.pi * t / (period / 2)) + 1) / 2
    return [_scale(shifted, level)] * count


# ------------------------------------------------- strip effects on a ring
#
# Ports of the led daemon's strip effects (daemon/effects/*.cpp) with the
# daemon's own default palettes and timings, reshaped for a closed ring: every
# distance is measured the short way round and every noise field repeats once
# per revolution, so nothing has a seam where the last LED meets the first.
# They ignore the picked colour, as the same effects on the strip do.

import os as _os
import time as _time


def _ease(x):
    x = 0.0 if x < 0 else 1.0 if x > 1 else x
    return x * x * x * (x * (x * 6.0 - 15.0) + 10.0)


def _pingpong(t, e=1.0):
    ph = t % 2.0
    tri = ph if ph < 1.0 else 2.0 - ph
    return tri + (_ease(tri) - tri) * e


def _hash2(x, y):
    """The daemon's motion::hash2, in 32-bit arithmetic."""
    h = ((x * 374761393) + (y * 668265263)) & 0xFFFFFFFF
    h = ((h ^ (h >> 13)) * 1274126177) & 0xFFFFFFFF
    h ^= h >> 16
    return (h & 0xFFFFFF) / float(0x1000000)


def _ring_noise(u, t, speed=1.0, cells=3, salt=0):
    """motion::noise over a ring: value noise that repeats every `cells`."""
    cells = max(1, int(round(cells)))
    fx = (u % 1.0) * cells
    fy = t * 0.15 * speed
    x0, y0 = int(math.floor(fx)), int(math.floor(fy))
    sx, sy = _ease(fx - x0), _ease(fy - y0)
    xa, xb = (x0 % cells) + salt, ((x0 + 1) % cells) + salt
    n00, n10 = _hash2(xa, y0), _hash2(xb, y0)
    n01, n11 = _hash2(xa, y0 + 1), _hash2(xb, y0 + 1)
    a = n00 + (n10 - n00) * sx
    b = n01 + (n11 - n01) * sx
    return a + (b - a) * sy


def _ring_shimmer(u, t, speed=1.0, phase=1.7):
    return 0.5 + 0.5 * math.sin(2 * math.pi * u + t * 0.23 * speed + phase)


def _ring_dist(a, b):
    """Shortest distance round a unit ring."""
    d = abs(a - b) % 1.0
    return min(d, 1.0 - d)


def _gradient(spec):
    stops = []
    for part in spec.split(","):
        n = int(part, 16)
        stops.append(((n >> 16) & 255, (n >> 8) & 255, n & 255))

    def at(x):
        n = len(stops)
        if n == 1:
            return stops[0]
        x = 0.0 if x < 0 else 1.0 if x > 1 else x
        p = x * (n - 1)
        i = min(int(p), n - 2)
        f = p - i
        a, b = stops[i], stops[i + 1]
        return tuple(a[c] + (b[c] - a[c]) * f for c in range(3))

    return at


def _px(r, g, b, v=1.0):
    return (
        int(max(0.0, min(255.0, r * v))),
        int(max(0.0, min(255.0, g * v))),
        int(max(0.0, min(255.0, b * v))),
    )


_PENDULUM = _gradient("2040ff,00d0c0,a040ff,ff4090,2040ff")


def pendulum(count, _color, t, period=60.0, swings=15.0, sharp=2.5):
    """Pendulum wave: each LED one more swing per period than its neighbour,
    drifting through travelling waves and braids back into step each minute.
    LED 0 hangs the slowest pendulum; the wave mirrors round both sides."""
    far = max(1, count // 2)
    phase = (t % period) / period
    frame = []
    for i in range(count):
        k = min(i, count - i)
        s = phase * (swings + k)
        s -= math.floor(s)
        v = (0.5 + 0.5 * math.cos(2 * math.pi * s)) ** sharp
        p = (k / far + t / 60.0) % 1.0
        frame.append(_px(*_PENDULUM(p), v))
    return frame


_SHORE = _gradient("003048,00a090,60e0c0")
_SHORE_BASE = (0, 8, 16)


def shoreline(count, _color, t, period=6.0, width=0.09, travel=1.6, stagger=0.5):
    """Waves rolling round from LED 0 in both directions, whitening into foam
    as they meet on the far side, the two directions taking turns."""
    inv2w2 = 1.0 / (2.0 * width * width)
    travel_t = period * travel
    waves = int(math.ceil(travel)) + 1
    frame = []
    for i in range(count):
        x = i / count
        light = foam_w = 0.0
        for side in (0, 1):
            ts = t - (stagger * period if side else 0.0)
            newest = int(math.floor(ts / period))
            for k in range(waves + 1):
                u = (ts - (newest - k) * period) / travel_t
                if u < 0.0 or u >= 1.0:
                    continue
                prog = math.sin(1.5707963 * u)
                pos = 1.0 - 0.5 * prog if side else 0.5 * prog
                d = _ring_dist(x, pos)
                w = math.sin(math.pi * u) * math.exp(-d * d * inv2w2)
                light += w
                foam_w += w * u * u * u
        fw = foam_w / light if light > 0 else 0.0
        light = min(1.0, light)
        g = _SHORE(light)
        c = [g[j] + (255 - g[j]) * fw for j in range(3)]
        frame.append(_px(*(_SHORE_BASE[j] + (c[j] - _SHORE_BASE[j]) * light for j in range(3))))
    return frame


_INK = _gradient("6a00ff,0080ff,00d0a0,ffb000,ff2060")


def _ink_color(j):
    p = j * 0.381966
    return _INK(p - math.floor(p))


def ink(count, _color, t, period=10.0, spread=4.0, soft=0.08, rim=0.35, sheen=0.15):
    """Drops of ink: every period a drop of the next colour lands somewhere on
    the ring and spreads both ways round until it has covered it."""
    newest = int(math.floor(t / period))
    live = int(math.ceil(spread / period)) + 1
    frame = []
    for i in range(count):
        x = i / count
        cr, cg, cb = _ink_color(newest - live)
        glisten = 0.0
        for j in range(newest - live + 1, newest + 1):
            age = t - j * period
            if age < 0:
                continue
            u = min(1.0, age / spread)
            pj = _hash2(j, 91)
            radius = _ease(u) * (0.5 + 2 * soft)
            d = _ring_dist(x, pj)
            c = _ease(max(0.0, min(1.0, (radius - d) / soft)))
            r, g, b = _ink_color(j)
            cr += (r - cr) * c
            cg += (g - cg) * c
            cb += (b - cb) * c
            if u < 1.0:
                e = (d - radius) / soft
                glisten += rim * math.exp(-e * e * 2.0) * math.sin(math.pi * u)
        glisten = min(1.0, glisten)
        cr += (255 - cr) * glisten * 0.7
        cg += (255 - cg) * glisten * 0.7
        cb += (255 - cb) * glisten * 0.7
        v = min(1.0, (1 - sheen + sheen * _ring_shimmer(x, t)) * (1 + 0.3 * glisten))
        frame.append(_px(cr, cg, cb, v))
    return frame


_SILK = _gradient("3a1078,c03080,ff9040,20b0c0,3a1078")


def silk(count, _color, t, speed=1.0, fold=0.5, sheen=0.3):
    """A palette loop drifting round the ring through a slow warp, so it folds
    and pleats like cloth, with a soft sheen passing over it."""
    frame = []
    for i in range(count):
        x = i / count
        warp = (_ring_noise(x, t, 1.6 * speed, cells=2) - 0.5) * fold
        p = (x - t * 0.045 * speed + warp) % 1.0
        v = 1 - sheen + sheen * _ring_shimmer(x + warp * 2, t, speed)
        frame.append(_px(*_SILK(p), v))
    return frame


_CAUSTICS = _gradient("020818,004060,00b0c0,a0fff0")


def caustics(count, _color, t, speed=1.0, sharp=1.5, gain=3.2):
    """Underwater light: two noise fields drifting against each other, so
    bright caustic lines form and break up like sunlight on a pool floor."""
    tt = t + 37.0
    frame = []
    for i in range(count):
        x = i / count
        n1 = _ring_noise(x, tt, speed, cells=3)
        n2 = _ring_noise(x, tt, -0.9 * speed, cells=5, salt=1000)
        v = min(1.0, n1 * n2 * gain) ** sharp
        v *= 0.85 + 0.15 * _ring_shimmer(x, t, 0.5 * speed)
        frame.append(_px(*_CAUSTICS(v), v))
    return frame


_STARS = _gradient("1030ff,00d0ff,c080ff,ff40a0")
_STAR_AMP = [0.42 * 0.55 ** p for p in range(2)]
_STAR_RATE = [
    0.03 / (a ** 1.5) * (0.9 + 0.2 * ((0.6180339887 * (p + 1)) % 1.0))
    for p, a in enumerate(_STAR_AMP)
]


def _metaballs(count, bodies, palette, core, white_hot, span):
    """Shared by stars and boil: soft bodies summed as a field, coloured by
    their own palette window, blooming toward white where they overlap."""
    frame = []
    for i in range(count):
        x = i / count
        field = 0.0
        weights = []
        for pos, inv, _base in bodies:
            d = _ring_dist(x, pos) * inv
            g = 1.0 / (1.0 + d * d)
            weights.append(g * g)
            field += g * g
        raw = field / core
        c = min(1.0, raw)
        bloom = max(0.0, min(1.0, (raw - 1.0) * white_hot))
        br = _ease(c)
        fr = fg = fb = 0.0
        for w, (_pos, _inv, base) in zip(weights, bodies):
            r, g, b = palette(base + c * span)
            fr += w * r
            fg += w * g
            fb += w * b
        inv_f = 1.0 / field if field > 0 else 0.0
        cr, cg, cb = fr * inv_f, fg * inv_f, fb * inv_f
        cr += (255 - cr) * bloom
        cg += (255 - cg) * bloom
        cb += (255 - cb) * bloom
        frame.append(_px(cr, cg, cb, br))
    return frame


def stars(count, _color, t, speed=1.0, ecc=0.3, radius=0.12):
    """Binary stars (the strip's orbit): pairs of glows circling a shared
    centre, whipping past each other and flaring white where they cross."""
    bodies = []
    for p in range(len(_STAR_AMP)):
        a = 2 * math.pi * _STAR_RATE[p] * speed * t
        angle = a - ecc * math.sin(2 * a)
        centre = 0.5 + 0.06 * (_ring_noise(0.1 * p, t + 50 * p, 0.3 * speed, cells=1) - 0.5)
        off = _STAR_AMP[p] * math.cos(angle)
        for side in (0, 1):
            b = p * 2 + side
            breathe = 1.0 + 0.15 * math.sin(t * 0.4 * speed + 2.1 * b)
            base = _ring_noise(0.0, t + 31 * b, 1.0, cells=1, salt=b) * 0.5
            bodies.append((centre + (-off if side else off), 1.0 / (radius * breathe), base))
    return _metaballs(count, bodies, _STARS, 1.5, 2.0, 0.5)


# --------------------------------------------------------------- load boil
#
# CPU and GPU load as a lava lamp: CPU blobs on one half of the ring, GPU on
# the other. The blobs move by accumulated phase, as on the strip, so a change
# in load speeds them up instead of making them jump -- which needs state
# kept between frames. Readings are cached for half a second.

_BOIL = _gradient("00e0c0,2060ff,a040ff,ff4060,ff9000")
_boil = {
    "t": None, "frames": {}, "cpu": 0.0, "gpu": 0.0,
    "phase": [[0.25, 0.75], [0.25, 0.75]],
    "read_at": 0.0, "cpu_raw": 0.0, "gpu_raw": 0.0, "stat": None,
}
_BOIL_RATE = [
    [(0.10 + 0.08 * ((0.6180339887 * (s * 8 + k + 1)) % 1.0)) * (-1 if k & 1 else 1) for k in range(2)]
    for s in range(2)
]


def _read_cpu():
    try:
        with open("/proc/stat") as handle:
            fields = [int(v) for v in handle.readline().split()[1:]]
    except (OSError, ValueError):
        return None
    idle = fields[3] + (fields[4] if len(fields) > 4 else 0)
    total = sum(fields[:8])
    prev = _boil["stat"]
    _boil["stat"] = (total, idle)
    if not prev or total <= prev[0]:
        return None
    return max(0.0, min(1.0, 1.0 - (idle - prev[1]) / float(total - prev[0])))


def _read_gpu():
    try:
        for card in sorted(_os.listdir("/sys/class/drm")):
            path = "/sys/class/drm/%s/device/gpu_busy_percent" % card
            if "-" not in card and _os.path.exists(path):
                with open(path) as handle:
                    return max(0.0, min(1.0, int(handle.read().strip()) / 100.0))
    except (OSError, ValueError):
        pass
    return None


def boil(count, _color, t):
    """Load boil: CPU and GPU load as a lava lamp. Idle drifts slow and cool;
    load makes the blobs boil faster, swell and run hot toward orange."""
    st = _boil
    if st["t"] == t and count in st["frames"]:
        return st["frames"][count]
    if st["t"] != t:
        now = _time.monotonic()
        if now - st["read_at"] >= 0.5:
            st["read_at"] = now
            cpu = _read_cpu()
            gpu = _read_gpu()
            if cpu is not None:
                st["cpu_raw"] = cpu
            if gpu is not None:
                st["gpu_raw"] = gpu
        dt = 0.0 if st["t"] is None else max(0.0, min(0.25, t - st["t"]))
        alpha = 1.0 - math.exp(-dt / 0.7) if dt > 0 else 0.0
        st["cpu"] += alpha * (st["cpu_raw"] - st["cpu"])
        st["gpu"] += alpha * (st["gpu_raw"] - st["gpu"])
        for side, load in enumerate((st["cpu"], st["gpu"])):
            vigor = 0.25 + (2.5 - 0.25) * load
            for k in range(2):
                st["phase"][side][k] += dt * _BOIL_RATE[side][k] * vigor
        st["t"] = t
        st["frames"] = {}

    bodies = []
    for side, load in enumerate((st["cpu"], st["gpu"])):
        base = load * (1 - 0.45)
        for k in range(2):
            ph = st["phase"][side][k]
            u = _pingpong(ph, 0.15)
            breathe = 1.0 + (0.10 + 0.30 * load) * math.sin(ph * 2.4 + 1.1 * (k + 4 * side))
            pos = 1.0 - 0.5 * u if side else 0.5 * u
            bodies.append((pos, 1.0 / (0.3 * 0.5 * breathe), base))
    frame = _metaballs(count, bodies, _BOIL, 1.4, 2.0, 0.45)
    st["frames"][count] = frame
    return frame


def off(count, _color, _t):
    return [(0, 0, 0)] * count


EFFECTS = {
    "solid": solid,
    "breathe": breathe,
    "glow": glow,
    "wave": wave,
    "rainbow": rainbow,
    "spin": spin,
    "orbit": orbit,
    "comet": comet,
    "chase": chase,
    "twinkle": twinkle,
    "fire": fire,
    "split": split,
    "pendulum": pendulum,
    "shoreline": shoreline,
    "ink": ink,
    "silk": silk,
    "caustics": caustics,
    "stars": stars,
    "boil": boil,
    "off": off,
}


def render(effect, count, color, t):
    generator = EFFECTS.get(effect, solid)
    return generator(count, color, t)
