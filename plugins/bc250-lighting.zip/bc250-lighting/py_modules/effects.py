"""Frame generators and the current budget that keeps them honest.

A WS2812B pixel draws roughly 20 mA per lit channel, so about 60 mA at full
white. Every effect runs through clamp() before it reaches a backend, which
scales frames down so a zone can never exceed its configured milliamp ceiling
no matter what the user picks in the UI.
"""

import colorsys
import math

MA_PER_CHANNEL = 20.0 / 255.0  # milliamps per unit of an 8-bit channel

# Perceived brightness is roughly the 2.2 power of emitted light, so scaling a
# frame linearly makes the top of the slider feel flat and leaves no usable
# range at the bottom -- 5% linear is still 12/255 on every channel, which is
# dimmer but not dim. Raising the slider position to this power spreads the
# useful travel across the whole slider and lets the low end reach genuinely
# faint output.
GAMMA = 2.2


def estimate_ma(pixels):
    """Worst-case draw of one frame, in milliamps."""
    total = 0
    for r, g, b in pixels:
        total += (r + g + b) * MA_PER_CHANNEL
    return total


def perceptual(brightness):
    """Slider percentage -> linear scale factor."""
    return (max(0.0, min(100.0, brightness)) / 100.0) ** GAMMA


def clamp(pixels, brightness, budget_ma):
    """Apply user brightness, then scale the whole frame under the current budget."""
    scale = perceptual(brightness)

    if scale <= 0.0:
        return [(0, 0, 0)] * len(pixels)

    # round rather than truncate: at the dim end, int() throws away most of
    # what little signal is left
    scaled = [
        (
            int(r * scale + 0.5),
            int(g * scale + 0.5),
            int(b * scale + 0.5),
        )
        for r, g, b in pixels
    ]

    # Below about 8% the gamma curve rounds everything to zero, which would
    # turn the bottom of the slider into an off switch. Rescale so the
    # brightest pixel lands on 1/255 -- the dimmest the hardware can show --
    # keeping the relative shape of the frame.
    peak_in = max((max(px) for px in pixels), default=0)
    peak_out = max((max(px) for px in scaled), default=0)
    if peak_in > 0 and peak_out == 0:
        rescue = 1.0 / peak_in
        scaled = [
            (
                int(r * rescue + 0.5),
                int(g * rescue + 0.5),
                int(b * rescue + 0.5),
            )
            for r, g, b in pixels
        ]

    if budget_ma <= 0:
        return scaled

    draw = estimate_ma(scaled)
    if draw <= budget_ma:
        return scaled

    headroom = budget_ma / draw
    return [
        (int(r * headroom), int(g * headroom), int(b * headroom))
        for r, g, b in scaled
    ]


# ------------------------------------------------------------------- effects


def solid(count, color, _t):
    return [tuple(color)] * count


def breathe(count, color, t, period=4.0):
    phase = (math.sin(2 * math.pi * t / period) + 1) / 2
    level = 0.15 + 0.85 * phase
    r, g, b = color
    return [(int(r * level), int(g * level), int(b * level))] * count


def rainbow(count, _color, t, period=6.0):
    frame = []
    for i in range(count):
        hue = ((t / period) + (i / max(count, 1))) % 1.0
        r, g, b = colorsys.hsv_to_rgb(hue, 1.0, 1.0)
        frame.append((int(r * 255), int(g * 255), int(b * 255)))
    return frame


def comet(count, color, t, period=2.5, tail=0.35):
    head = ((t / period) % 1.0) * count
    r, g, b = color
    frame = []
    for i in range(count):
        distance = (head - i) % count
        level = max(0.0, 1.0 - distance / (count * tail))
        frame.append((int(r * level), int(g * level), int(b * level)))
    return frame


# --------------------------------------------------------------- ring helpers
#
# A fan's LEDs are a closed ring, so position is an angle, not an offset. Every
# effect below wraps: the value at the last pixel meets the value at the first
# without a seam, which is what stops a rotating effect from visibly stuttering
# once per revolution.


def _arc_distance(a, b, count):
    """Shortest way round the ring between two pixel positions, in pixels."""
    raw = abs(a - b) % count
    return min(raw, count - raw)


def _hash01(*parts):
    """Deterministic pseudo-random float in [0, 1).

    Effects are rendered statelessly from (index, time), so randomness has to
    be reproducible per pixel rather than drawn fresh each frame -- otherwise
    a sparkle would re-roll 30 times a second and just look like noise.
    """
    h = 2166136261
    for value in parts:
        h ^= int(value) & 0xFFFFFFFF
        h = (h * 16777619) & 0xFFFFFFFF
    return h / 4294967296.0


def _noise(index, t, speed=1.0):
    """Smooth per-pixel value noise: lerp between successive random levels."""
    phase = t * speed
    step = math.floor(phase)
    frac = phase - step
    a = _hash01(index, step)
    b = _hash01(index, step + 1)
    # smoothstep, so the flicker eases rather than ramping linearly
    frac = frac * frac * (3 - 2 * frac)
    return a + (b - a) * frac


def _scale(color, level):
    level = max(0.0, min(1.0, level))
    r, g, b = color
    return (int(r * level), int(g * level), int(b * level))


def _shift_hue(color, delta):
    r, g, b = (c / 255.0 for c in color)
    h, s, v = colorsys.rgb_to_hsv(r, g, b)
    r, g, b = colorsys.hsv_to_rgb((h + delta) % 1.0, s, v)
    return (int(r * 255), int(g * 255), int(b * 255))


# -------------------------------------------------------------- ring effects


def spin(count, color, t, period=2.0, width=0.3):
    """A lit arc sweeping round the ring, like a blade catching the light."""
    head = (t / period) * count
    span = max(1.0, width * count)
    frame = []
    for i in range(count):
        # measured behind the head so the arc trails rather than straddles
        behind = (head - i) % count
        level = max(0.0, 1.0 - behind / span)
        frame.append(_scale(color, level * level))
    return frame


def orbit(count, color, t, period=1.6, dots=2, size=1.6):
    """Evenly spaced dots circling the ring — reads as a spinning fan."""
    head = (t / period) * count
    frame = []
    for i in range(count):
        level = 0.0
        for n in range(dots):
            centre = (head + n * count / dots) % count
            level = max(level, 1.0 - _arc_distance(i, centre, count) / size)
        frame.append(_scale(color, max(0.0, level)))
    return frame


def chase(count, color, t, spacing=3, period=0.9):
    """Theater chase: every third pixel lit, the pattern stepping round."""
    offset = int((t / period) * spacing) % spacing
    return [
        _scale(color, 1.0 if (i - offset) % spacing == 0 else 0.05)
        for i in range(count)
    ]


def wave(count, color, t, period=3.0, waves=2):
    """Standing brightness waves rotating round the ring.

    waves must divide evenly into the circle or the pattern would break at the
    wrap point, so the count is folded into the angle rather than the index.
    """
    frame = []
    for i in range(count):
        angle = 2 * math.pi * (waves * i / count - t / period)
        level = 0.12 + 0.88 * (math.sin(angle) + 1) / 2
        frame.append(_scale(color, level))
    return frame


def twinkle(count, color, t, period=1.7, density=0.55):
    """Sparkles fading in and out over a dim base.

    Each pixel keeps its own phase, derived from its index, so a given LED
    twinkles on its own schedule instead of the whole ring pulsing together.
    """
    frame = []
    for i in range(count):
        phase = (t / period + _hash01(i, 7)) % 1.0
        # triangle wave: rise then fall
        level = 1.0 - abs(phase * 2 - 1)
        lit = _hash01(i, int(t / period) + 11) < density
        frame.append(_scale(color, 0.08 + 0.92 * level if lit else 0.08))
    return frame


def fire(count, color, t, speed=2.2):
    """Flicker in the chosen hue, hot centres cooling at the edges."""
    frame = []
    for i in range(count):
        level = 0.25 + 0.75 * _noise(i, t, speed)
        # hotter pixels ride toward yellow, cooler ones sink toward red
        shifted = _shift_hue(color, 0.04 * (level - 0.5))
        frame.append(_scale(shifted, level))
    return frame


def split(count, color, t, period=5.0):
    """Two complementary halves rotating — strong colour contrast per fan."""
    other = _shift_hue(color, 0.5)
    head = (t / period) * count
    frame = []
    for i in range(count):
        ahead = (i - head) % count
        near = ahead < count / 2
        # feather the two joins so the halves blend instead of hard-cutting
        edge = min(ahead, count - ahead, abs(ahead - count / 2))
        blend = min(1.0, edge / max(1.0, count * 0.08))
        a, b = (color, other) if near else (other, color)
        mixed = tuple(int(a[c] * blend + ((a[c] + b[c]) / 2) * (1 - blend)) for c in range(3))
        frame.append(mixed)
    return frame


def glow(count, color, t, period=9.0, spread=0.07):
    """The whole ring drifting slowly around the chosen hue."""
    delta = spread * math.sin(2 * math.pi * t / period)
    shifted = _shift_hue(color, delta)
    level = 0.65 + 0.35 * (math.sin(2 * math.pi * t / (period / 2)) + 1) / 2
    return [_scale(shifted, level)] * count


def off(count, _color, _t):
    return [(0, 0, 0)] * count


EFFECTS = {
    "solid": solid,
    "breathe": breathe,
    "glow": glow,
    "wave": wave,
    "rainbow": rainbow,
    "spin": spin,
    "orbit": orbit,
    "comet": comet,
    "chase": chase,
    "twinkle": twinkle,
    "fire": fire,
    "split": split,
    "off": off,
}


def render(effect, count, color, t):
    generator = EFFECTS.get(effect, solid)
    return generator(count, color, t)
