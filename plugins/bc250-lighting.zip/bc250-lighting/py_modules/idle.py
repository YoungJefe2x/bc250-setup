"""Idle tracking for the LED standby timer.

Steam's own "dim screen" timer only acts on a built-in panel's backlight, so
on a TV there is nothing to observe from outside. What it counts is the same
thing measured here: time since the last controller, keyboard or mouse input.
Reading /dev/input directly (the backend runs as root) sees every pad,
including Steam Input's virtual one, without grabbing anything.

Playing audio counts as activity too, so a movie or music keeps the lights
on with nobody touching anything. That is the same test the LED daemon's
audio_playing condition makes: ALSA says a playback stream is RUNNING, and the
sound server lists an uncorked (not paused) playback stream.

Standard library only: Decky's bundled Python has no evdev module.
"""

import fcntl
import glob
import json
import os
import select
import struct
import subprocess
import threading
import time

import decky

EV_KEY = 0x01
EV_REL = 0x02
EV_ABS = 0x03

# struct input_event on 64-bit: timeval (2 x long), type, code, value
EVENT = struct.Struct("llHHi")

# Motion sensors stream constantly while the pad sits on a table, and would
# keep the lights on forever. Matched on the device name the kernel reports.
IGNORE_NAMES = ("motion sensors", "accelerometer", "gyro", "imu")

# A stick has to move this share of its range to count. Resting sticks jitter
# by a few units, and that jitter must not read as someone playing.
ABS_SHARE = 0.10

RESCAN_SECONDS = 10.0
AUDIO_SECONDS = 5.0


def _alsa_running():
    """Any playback substream RUNNING. PipeWire suspends the sink a few
    seconds after the last stream stops, so this drops soon after playback."""
    for status in glob.glob("/proc/asound/card*/pcm*p/sub*/status"):
        try:
            with open(status) as handle:
                if "RUNNING" in handle.read(200):
                    return True
        except OSError:
            continue
    return False


def _pulse_env():
    """Point pactl at the game-mode user's sound server. The backend runs as
    root with no session environment; pipewire-pulse does no cookie auth."""
    env = dict(os.environ)
    for var in ("LD_LIBRARY_PATH", "LD_PRELOAD", "PYTHONHOME", "PYTHONPATH"):
        original = env.pop(var + "_ORIG", None)
        env.pop(var, None)
        if original:
            env[var] = original
    for sock in sorted(glob.glob("/run/user/*/pulse/native")):
        env["PULSE_SERVER"] = "unix:" + sock
        env["XDG_RUNTIME_DIR"] = os.path.dirname(os.path.dirname(sock))
        break
    return env


def audio_playing():
    if not _alsa_running():
        return False
    try:
        proc = subprocess.run(
            ["pactl", "-f", "json", "list", "sink-inputs"],
            capture_output=True, text=True, timeout=5, env=_pulse_env(),
        )
        streams = json.loads(proc.stdout) if proc.returncode == 0 else None
    except (OSError, subprocess.TimeoutExpired, ValueError):
        streams = None
    if not isinstance(streams, list):
        # No verdict from the sound server. Something is feeding the card, so
        # err on the side of keeping the lights on.
        return True
    return any(isinstance(s, dict) and not s.get("corked", False) for s in streams)


def _ioc_read(nr, size):
    return (2 << 30) | (size << 16) | (ord("E") << 8) | nr


def _name(fd):
    try:
        buf = fcntl.ioctl(fd, _ioc_read(0x06, 256), bytes(256))
        return buf.split(b"\0", 1)[0].decode("utf-8", "replace")
    except OSError:
        return ""


def _abs_threshold(fd, code):
    """Minimum change on this axis that counts as a person moving it."""
    try:
        buf = fcntl.ioctl(fd, _ioc_read(0x40 + code, 24), bytes(24))
        _value, lo, hi, _fuzz, flat, _res = struct.unpack("6i", buf)
    except OSError:
        return 1
    return max(1, flat, int((hi - lo) * ABS_SHARE))


class IdleWatcher:
    def __init__(self):
        self.last_input = time.monotonic()
        self._fds = {}  # path -> fd
        self._abs = {}  # (fd, code) -> [last value, threshold]
        self._stop = threading.Event()
        self._thread = None

    def start(self):
        if self._thread:
            return
        self._thread = threading.Thread(target=self._run, name="led-idle", daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()

    def idle_seconds(self):
        return time.monotonic() - self.last_input

    def poke(self):
        self.last_input = time.monotonic()

    # ------------------------------------------------------------------ io

    def _rescan(self):
        present = set(glob.glob("/dev/input/event*"))
        for path in list(self._fds):
            if path not in present:
                self._close(path)
        for path in present - set(self._fds):
            try:
                fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK)
            except OSError:
                continue
            name = _name(fd).lower()
            if any(word in name for word in IGNORE_NAMES):
                os.close(fd)
                # remembered with no fd so it is not reopened every rescan
                self._fds[path] = None
                continue
            self._fds[path] = fd

    def _close(self, path):
        fd = self._fds.pop(path, None)
        if fd is None:
            return
        for key in [k for k in self._abs if k[0] == fd]:
            del self._abs[key]
        try:
            os.close(fd)
        except OSError:
            pass

    def _counts(self, fd, etype, code, value):
        if etype == EV_KEY:
            return True
        if etype == EV_REL:
            return value != 0
        if etype == EV_ABS:
            entry = self._abs.get((fd, code))
            if entry is None:
                self._abs[(fd, code)] = [value, _abs_threshold(fd, code)]
                return False
            if abs(value - entry[0]) >= entry[1]:
                entry[0] = value
                return True
        return False

    def _read(self, fd):
        active = False
        while True:
            try:
                data = os.read(fd, EVENT.size * 64)
            except BlockingIOError:
                return active
            except OSError:
                raise
            if not data:
                return active
            for off in range(0, len(data) - EVENT.size + 1, EVENT.size):
                _s, _us, etype, code, value = EVENT.unpack_from(data, off)
                if self._counts(fd, etype, code, value):
                    active = True

    def _run(self):
        next_scan = 0.0
        next_audio = 0.0
        while not self._stop.is_set():
            now = time.monotonic()
            if now >= next_scan:
                self._rescan()
                next_scan = now + RESCAN_SECONDS
            if now >= next_audio:
                next_audio = now + AUDIO_SECONDS
                try:
                    if audio_playing():
                        self.last_input = time.monotonic()
                except Exception:  # noqa: BLE001
                    decky.logger.exception("audio check failed")
            live = {fd: path for path, fd in self._fds.items() if fd is not None}
            if not live:
                self._stop.wait(2.0)
                continue
            try:
                ready, _, _ = select.select(list(live), [], [], 2.0)
            except (OSError, ValueError):
                next_scan = 0.0
                continue
            for fd in ready:
                try:
                    if self._read(fd):
                        self.last_input = time.monotonic()
                except OSError:
                    # unplugged mid-read; the next rescan drops it
                    self._close(live[fd])
        for path in list(self._fds):
            self._close(path)
        decky.logger.info("idle watcher stopped")
