"""Is Steam downloading right now? The same test the led daemon's steam_dl
source falls back to (daemon/sources/steam.hpp): an appmanifest whose
StateFlags has a running bit (256 or 1024), is not paused (512), and has a
download size.

Steam writes those flags as a download starts and stops, so this follows a
download within a few seconds of polling. Standard library only.
"""

import glob
import os
import re

_KV = re.compile(r'^\s*"([^"]+)"\s+"([^"]*)"')

RUNNING = 256 | 1024
PAUSED = 512


def _libraries():
    roots = set()
    for base in ("/home/*", "/var/home/*", "/root"):
        for cand in glob.glob(base):
            for rel in (".local/share/Steam", ".steam/steam"):
                path = os.path.join(cand, rel, "steamapps")
                if os.path.isdir(path):
                    roots.add(os.path.realpath(path))
    # extra library folders listed by each Steam root
    for steamapps in list(roots):
        vdf = os.path.join(steamapps, "libraryfolders.vdf")
        try:
            with open(vdf, "r", errors="replace") as handle:
                for line in handle:
                    m = _KV.match(line)
                    if m and m.group(1) == "path":
                        lib = os.path.join(m.group(2), "steamapps")
                        if os.path.isdir(lib):
                            roots.add(os.path.realpath(lib))
        except OSError:
            continue
    return sorted(roots)


def _manifest_active(path):
    """Only the app's own (depth 1) keys count: per-depot blocks nested inside
    AppState repeat BytesToDownload for their own slice."""
    flags = 0
    total = 0
    depth = 0
    try:
        with open(path, "r", errors="replace") as handle:
            for line in handle:
                stripped = line.strip()
                if stripped.startswith("{"):
                    depth += 1
                    continue
                if stripped.startswith("}"):
                    depth -= 1
                    continue
                if depth != 1:
                    continue
                m = _KV.match(line)
                if not m:
                    continue
                if m.group(1) == "StateFlags":
                    flags = int(m.group(2) or 0)
                elif m.group(1) == "BytesToDownload":
                    total = int(m.group(2) or 0)
    except (OSError, ValueError):
        return False
    return total > 0 and not flags & PAUSED and bool(flags & RUNNING)


def downloading():
    for lib in _libraries():
        for manifest in glob.glob(os.path.join(lib, "appmanifest_*.acf")):
            if _manifest_active(manifest):
                return True
    return False
