# System Updates (CachyOS)

Check for and install CachyOS system updates from Game Mode, with notifications
tuned so a rolling distro doesn't toast you every single day.

## Install (Decky developer mode)

1. Copy `system-updates.zip` to the machine.
2. In Game Mode: **Quick Access → Decky → Settings (cog) → Developer mode → on**.
3. Back in Decky, **Developer → Install Plugin from URL**.
4. Serve the zip from the machine itself and point the field at it:
   ```
   cd ~/Downloads && python -m http.server 8000
   # URL: http://127.0.0.1:8000/system-updates.zip
   ```

Or unzip it straight in and restart Decky:

```
sudo unzip -o system-updates.zip -d /home/$USER/homebrew/plugins/
sudo chown -R $USER:$USER /home/$USER/homebrew/plugins/"System Updates"
sudo systemctl restart plugin_loader
```

## What it does

**Checking.** Uses `checkupdates` from `pacman-contrib` when present. If it isn't
installed, the plugin does the same thing itself: copies the sync DB to a temp
dir, refreshes *that*, and diffs against it. Either way the real database is
never touched, so background polling can't leave you in a partial-upgrade state.

**Installing.** The upgrade runs as a transient systemd unit:

```
systemd-run --unit=decky-sysupdate --no-block --property=Type=oneshot ...
```

It survives a Steam or gamescope restart and a plugin reload, so a mid-upgrade
hiccup won't leave a stale pacman lock. Keyrings (`archlinux-keyring`,
`cachyos-keyring`) refresh first, since a stale keyring is the usual reason a
`--noconfirm` run dies. If pacman exits non-zero the script stops immediately and
surfaces the log rather than retrying — finish that one in Desktop Mode.

Every call out to `systemctl` / `systemd-run` / `pacman` runs with a scrubbed
environment. Decky's PyInstaller backend exports `LD_LIBRARY_PATH` pointing at
its own `/tmp/_MEI*` bundle, and children that inherit it pick up the wrong
libssl — the `OPENSSL_3.4.0 not found` failure.

## When it notifies

The panel always shows the true pending count. A **toast** only fires when one
of these hits:

| Rule | Default | Notes |
|---|---|---|
| Security fix | always on | via `arch-audit`, if installed. Not switchable. |
| Arch news | on | unread items; ones saying "manual intervention" **block installing** until marked read |
| Watchlist package | on | kernel, mesa, nvidia, systemd, glibc, gamescope, Steam, proton-cachyos, pipewire, cachyos-handheld, plasma, limine |
| Major version bump | on | first version component changes; first *two* for kernels, so 6.15 → 6.16 counts |
| Services need restart | on | via `arch-update -s`; running against replaced libraries |
| Failed DKMS build | on | pacman exits 0 even when a module doesn't rebuild |
| Large batch | on, ≥80 pkgs | usually a Qt/KDE or toolchain rebuild wave |
| Overdue | on, 14 days | deferring forever is how you hit keyring expiry |

### The news gate

Arch news is published precisely when an upgrade needs a human — the thing that
makes `--noconfirm` dangerous. If an unread item matches "manual intervention",
the Install button is held and says so. Read it in Desktop Mode
(`cachy-update -n`), then press **Mark news as read** to release it.

### Service restarts

The panel lists services still running against libraries an upgrade replaced.
"Restart what's safe to restart" skips `NetworkManager`, `wpa_supplicant`,
`systemd-udevd`, `systemd-resolved`, `dbus`, and `iwd` — restarting those from a
live session drops your network with the panel still open. Those are left for a
reboot, and the toast tells you how many were deferred.

### AUR is deliberately excluded

`checkupdates` is repo-only. VCS packages (`*-git`) report `-> latest-commit`
permanently, so including them would make every poll fire a notification. Run
`cachy-update` by hand when you want AUR.

Each `package@version` is announced once, with a 72-hour cooldown, so a pending
kernel doesn't re-toast every poll. Toasts are held while a game is in the
foreground and flushed when you're back at the library.

The watchlist is an editable comma-separated field and accepts globs
(`linux-cachyos*`).

## Optional, but worth having

```
sudo pacman -S pacman-contrib arch-audit
```

`pacman-contrib` gives you the real `checkupdates`; `arch-audit` enables the
security rule, which is the one category that should never be silenced.

## Before you trust it unattended

Confirm snapshots are actually being taken, so a bad upgrade is a boot-menu
rollback rather than a rescue USB:

```
snapper list
systemctl status limine-snapper-sync.service
```

## Notes

- Backend runs as root (`"flags": ["root"]` in `plugin.json`).
- Flatpak system and user installs are updated after pacman succeeds.
- Restart prompt appears when the running kernel's modules are gone, a newer
  kernel is installed, or systemd/glibc/openssl were replaced after boot.
- Logs: `~/homebrew/logs/System Updates/`, plus `journalctl -u decky-sysupdate`.

## From the setup tool

Plugin and setup-tool updates are listed with the system's packages and
install with the same button, before the packages. It checks what bc250-setup installed (from the markers in `/var/lib/bc250-setup`)
and keeps it current: a newer script is swapped in and run with `--refresh`,
the LED daemon is pulled and rebuilt when its repo moves on (and the receiver
flashed when a new firmware release is out, unless it runs the PSU switch), and the Control
Center is rebuilt from the AUR when its upstream has new commits. Each step
installs the packages it depends on.

## Steam library shortcuts

When the setup tool has installed Android TV (Waydroid), the panel adds
`~/waydroid-tv.sh` to the Steam library as "Android TV" a few seconds after
game mode starts, and removes it again once the setup tool uninstalls
Android TV. A shortcut you already made with that name is kept, not
duplicated.
