import asyncio
import fnmatch
import json
import os
import re
import shutil
import subprocess
import tempfile
import time
import zipfile
from pathlib import Path

import decky

UNIT = "decky-sysupdate"

# pacman needs room to unpack on top of the downloaded packages.
MIN_FREE_BYTES = 3 * 1024 ** 3

# Edgar's own plugins are not in the Decky store, so Decky never offers updates
# for them. The repo lists what it ships in plugins/versions.json; compare the
# installed copies against that and offer to update them here instead.
PLUGIN_REPO = "YoungJefe2x/bc250-setup"
PLUGIN_BRANCH = "main"
PLUGIN_MANIFEST = "plugins/versions.json"

# The setup tool itself. The installer writes where it lives on every run; a
# copy that was never run since that was added simply isn't offered.
TOOL_FILE = "bc250-setup.sh"
TOOL_STATE_DIR = Path("/var/lib/bc250-setup")
TOOL_PATH_FILE = TOOL_STATE_DIR / "script-path"
TOOL_REFRESH_FLAG = TOOL_STATE_DIR / ".refresh-needed"

# What the setup tool can install, by the marker file it leaves in
# TOOL_STATE_DIR. Most of it is files the script itself writes, so a new
# script plus its --refresh brings them up to date. The LED daemon and the
# Control Center come from their own upstream repos and are checked there.
TOOL_COMPONENTS = [
    ("cec", "HDMI-CEC TV control"),
    ("led", "LED strip daemon"),
    ("power", "Sleep / suspend off"),
    ("guide", "Guide button input switch"),
    ("decky", "Decky plugins"),
    ("atv", "Android TV (Waydroid)"),
    ("ctlcenter", "BC-250 Control Center"),
    ("boot", "Quick, quiet boot menu"),
]
LED_SRC = Path("/opt/bc250/bc250_ws2812b_controller")
LED_FW_REPO = "peterdk31/bc250_ws2812b_controller"
LED_FW_STATE = TOOL_STATE_DIR / "led-firmware"
LED_CONFIG = Path("/etc/led-controller/config.json")
CTLCENTER_PKG = "bc250-control-center-git"
CTLCENTER_UPSTREAM = "https://github.com/movacx/bc250-control-center.git"


_PACKAGE_RE = re.compile(r"[a-z0-9@_+][a-z0-9@._+-]*")


def _package_list(value):
    """Package names from versions.json, dropping anything that isn't one."""
    if not isinstance(value, list):
        return []
    return [p for p in value if isinstance(p, str) and _PACKAGE_RE.fullmatch(p)]


def _missing_packages(packages):
    """Which of these pacman has not installed (pacman -T lists them)."""
    if not packages:
        return []
    code, out, _ = _run(["pacman", "-T", *packages], timeout=60)
    if code == 0:
        return []
    return [p for p in out.split() if p in packages]


def _git_blob_sha(data: bytes) -> str:
    """What git (and the GitHub tree API) calls this file's id."""
    import hashlib
    return hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()


def _in_git_checkout(path: Path) -> bool:
    for parent in path.parents:
        if (parent / ".git").exists():
            return True
    return False


def _version_key(version):
    parts = []
    for piece in re.split(r"[.\-+]", str(version or "0")):
        parts.append(int(piece) if piece.isdigit() else 0)
    return parts

DEFAULT_WATCHLIST = ",".join([
    "linux-cachyos*", "linux", "linux-lts", "linux-firmware",
    "mesa", "lib32-mesa", "vulkan-radeon", "lib32-vulkan-radeon", "nvidia*",
    "systemd", "systemd-libs", "glibc",
    "gamescope*", "steam", "steam-native-runtime", "proton-cachyos",
    "pipewire", "pipewire-pulse", "wireplumber",
    "cachyos-handheld*", "cachyos-settings",
    "plasma-desktop", "plasma-workspace", "kwin", "xorg-server", "limine*",
])

DEFAULTS = {
    "poll_hours": 6,
    "notify_watchlist": True,
    "notify_major": True,
    "notify_volume": True,
    "volume_threshold": 80,
    "notify_stale": True,
    "stale_days": 14,
    "notify_services": True,
    "notify_dkms": True,
    "include_aur": True,
    "notify_aur": True,
    "notify_aur_devel": True,
    "install_aur": False,
    "notify_news": True,
    "news_count": 5,
    "block_on_intervention": True,
    "hold_in_game": True,
    "include_flatpak": True,
    "watchlist": DEFAULT_WATCHLIST,
    "cooldown_hours": 72,
}

REBOOT_MARKERS = [
    "/usr/lib/systemd/systemd",
    "/usr/lib/libc.so.6",
    "/usr/lib/libcrypto.so",
]


def _clean_env():
    """Decky's PyInstaller backend exports LD_LIBRARY_PATH pointing at its own
    /tmp/_MEI* bundle. Children inherit it and pick up the wrong libssl, which
    is what produces `OPENSSL_3.4.0 not found` from things like systemctl."""
    env = dict(os.environ)
    for key in ("LD_LIBRARY_PATH", "LD_PRELOAD", "PYTHONHOME", "PYTHONPATH", "_MEIPASS2"):
        env.pop(key, None)
    env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
    env["LC_ALL"] = "C"
    return env


def _run(args, timeout=180, stdin_devnull=False):
    try:
        proc = subprocess.run(
            args,
            env=_clean_env(),
            capture_output=True,
            text=True,
            timeout=timeout,
            stdin=subprocess.DEVNULL if stdin_devnull else None,
        )
        return proc.returncode, proc.stdout, proc.stderr
    except FileNotFoundError:
        return 127, "", f"{args[0]}: not found"
    except subprocess.TimeoutExpired:
        return 124, "", f"{args[0]}: timed out after {timeout}s"
    except Exception as exc:  # noqa: BLE001
        return 1, "", str(exc)


def _strip_epoch(version: str) -> str:
    return version.split(":", 1)[1] if ":" in version else version


def _base_parts(version: str):
    core = _strip_epoch(version).split("-", 1)[0]
    return [p for p in re.split(r"[._+]", core) if p]


def _is_major_bump(old: str, new: str, depth: int = 1) -> bool:
    a, b = _base_parts(old), _base_parts(new)
    return a[:depth] != b[:depth]


class Plugin:
    def __init__(self):
        self.settings = dict(DEFAULTS)
        self.state = {}
        self.poll_task = None
        self.finish_task = None
        self.last_run = None
        self.settings_dir = Path(
            os.environ.get("DECKY_PLUGIN_SETTINGS_DIR", "/tmp/cachy-updates")
        )
        self.runtime_dir = Path(
            os.environ.get("DECKY_PLUGIN_RUNTIME_DIR", str(self.settings_dir))
        )
        self.user = os.environ.get("DECKY_USER", "deck")
        self.plugin_updates = []
        self.plugin_error = None
        self.plugin_sha = None
        self.tool_update = None
        self.components = []
        self.components_running = False
        # Plugin files swapped in, waiting for you to restart Decky.
        self.decky_restart_pending = []
        self.plugins_root = Path(
            os.environ.get("DECKY_PLUGIN_DIR", "/tmp/plugins/x")
        ).parent

    # ---------- persistence ----------

    @property
    def _settings_file(self):
        return self.settings_dir / "settings.json"

    @property
    def _announced_file(self):
        return self.settings_dir / "announced.json"

    @property
    def _script_file(self):
        return self.runtime_dir / "run-update.sh"

    @property
    def _log_file(self):
        return self.runtime_dir / "update.log"

    @property
    def _last_run_file(self):
        return self.runtime_dir / "finish.json"

    @property
    def _result_file(self):
        return self.runtime_dir / "last-run.json"

    def _load_json(self, path, fallback):
        try:
            return json.loads(path.read_text())
        except Exception:  # noqa: BLE001
            return fallback

    def _save_json(self, path, data):
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(data, indent=2))
        except Exception as exc:  # noqa: BLE001
            decky.logger.error("could not write %s: %s", path, exc)

    # ---------- checking ----------

    def _check_via_temp_db(self):
        """What checkupdates does, done inline so pacman-contrib isn't required:
        refresh a *copy* of the sync DB in a temp dir and diff against that, so
        the real DB is never touched and we can't cause a partial upgrade."""
        tmp = Path(tempfile.mkdtemp(prefix="decky-checkup-"))
        try:
            db = tmp / "db"
            (db / "sync").mkdir(parents=True, exist_ok=True)
            source = Path("/var/lib/pacman/sync")
            if source.is_dir():
                for item in source.iterdir():
                    if item.is_file():
                        shutil.copy2(item, db / "sync" / item.name)
            (db / "local").symlink_to("/var/lib/pacman/local")

            code, out, err = _run(
                ["pacman", "-Sy", "--dbpath", str(db), "--logfile", "/dev/null"],
                timeout=300,
            )
            if code != 0:
                return None, (err or out or f"pacman -Sy exited {code}").strip()

            code, out, err = _run(["pacman", "-Qu", "--dbpath", str(db)], timeout=120)
            # -Qu exits 1 when there is simply nothing to upgrade.
            if code not in (0, 1):
                return None, (err or out or f"pacman -Qu exited {code}").strip()
            return out, None
        except Exception as exc:  # noqa: BLE001
            return None, str(exc)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def _check_pacman(self):
        if shutil.which("checkupdates"):
            code, out, err = _run(["checkupdates"], timeout=300)
            # checkupdates exits 2 when there is nothing to upgrade.
            if code not in (0, 2):
                return None, (err or out or f"checkupdates exited {code}").strip()
        else:
            out, error = self._check_via_temp_db()
            if error:
                return None, error

        packages = []
        for line in out.splitlines():
            if "[ignored]" in line:
                continue
            match = re.match(r"^(\S+)\s+(\S+)\s+->\s+(\S+)$", line.strip())
            if match:
                packages.append({
                    "name": match.group(1),
                    "old": match.group(2),
                    "new": match.group(3),
                })
        return packages, None

    def _check_flatpak(self):
        if not shutil.which("flatpak"):
            return []
        apps = []
        code, out, _ = _run(
            ["flatpak", "remote-ls", "--updates", "--columns=application"], timeout=180
        )
        if code == 0:
            apps += [l.strip() for l in out.splitlines() if l.strip()]
        code, out, _ = _run(
            ["runuser", "-u", self.user, "--",
             "flatpak", "remote-ls", "--user", "--updates", "--columns=application"],
            timeout=180,
        )
        if code == 0:
            apps += [l.strip() for l in out.splitlines() if l.strip()]
        return sorted(set(apps))

    def _check_news(self):
        """Arch news is published precisely when an upgrade needs a human, so an
        unread 'manual intervention' item is the one thing that should stop an
        unattended --noconfirm run."""
        binary = shutil.which("arch-update") or shutil.which("cachy-update")
        if not binary:
            return []
        count = int(self.settings.get("news_count", 5))
        code, out, _ = _run([binary, "-n", str(count)], timeout=120, stdin_devnull=True)
        if code not in (0, 1, 130):
            return []

        seen_store = self._load_json(self._announced_file, {})
        items = []
        in_section = False
        for line in out.splitlines():
            stripped = line.strip()
            if "Arch News:" in stripped:
                in_section = True
                continue
            if not in_section or not stripped:
                continue
            if stripped.startswith("->"):
                break
            match = re.match(r"^\d+\s+-\s+(.+?)\s*$", stripped)
            if not match:
                continue
            title = match.group(1)
            items.append({
                "title": title,
                "intervention": bool(
                    re.search(r"manual intervention|requires? action", title, re.I)
                ),
                "seen": f"news:{title}" in seen_store,
            })
        return items

    def _check_services(self):
        """arch-update -s lists services still running against deleted libraries.
        It ends on an interactive prompt, so stdin is closed to make it fall
        straight through after printing the list."""
        binary = shutil.which("arch-update") or shutil.which("cachy-update")
        if not binary:
            return []
        code, out, _ = _run([binary, "-s"], timeout=120, stdin_devnull=True)
        if code not in (0, 1, 130):
            return []
        services = []
        for line in out.splitlines():
            match = re.match(r"^\s*\d+\s+-\s+(\S+\.(?:service|socket|timer))\s*$", line)
            if match:
                services.append(match.group(1))
        return services

    def _check_dkms(self):
        """A DKMS module that failed to rebuild leaves pacman's exit code at 0,
        so a broken sensors or driver module would otherwise pass silently."""
        if not shutil.which("dkms"):
            return []
        code, out, _ = _run(["dkms", "status"], timeout=60)
        if code != 0:
            return []
        broken = []
        for line in out.splitlines():
            if not line.strip():
                continue
            lowered = line.lower()
            if "installed" in lowered or "built" in lowered:
                continue
            if any(word in lowered for word in ("error", "failed", "broken", "added")):
                broken.append(line.strip())
        return broken

    def _check_aur(self):
        """VCS packages (-git and friends) always report a pending 'update', so
        they're listed but never allowed to trigger a notification."""
        helper = None
        for candidate in ("paru", "yay"):
            if shutil.which(candidate):
                helper = candidate
                break
        if not helper:
            return []

        code, out, _ = _run(
            ["runuser", "-u", self.user, "--", helper, "-Qua", "--color", "never"],
            timeout=300,
            stdin_devnull=True,
        )
        if code not in (0, 1):
            return []

        items = []
        for line in out.splitlines():
            match = re.match(r"^(\S+)\s+(\S+)\s+->\s+(\S+)$", line.strip())
            if not match:
                continue
            name, old, new = match.groups()
            vcs = bool(
                re.search(r"-(git|svn|hg|bzr|cvs|nightly)$", name)
            ) or "latest-commit" in new
            items.append({"name": name, "old": old, "new": new, "vcs": vcs})
        return items

    def _check_security(self):
        if not shutil.which("arch-audit"):
            return []

        found = []
        code, out, _ = _run(["arch-audit", "-u", "-f", "%n|%s"], timeout=120)
        if code in (0, 1):
            for line in out.splitlines():
                if "|" in line:
                    name, severity = line.split("|", 1)
                    found.append({"name": name.strip(), "severity": severity.strip()})
        if found:
            return found

        # Either there's genuinely nothing, or this arch-audit doesn't support
        # that format string. Re-run without -f and parse the prose; a silent
        # empty list here would disable the one rule that can't be toggled off.
        code, out, _ = _run(["arch-audit", "-u"], timeout=120)
        if code not in (0, 1):
            decky.logger.warning("arch-audit failed (exit %s)", code)
            return []
        for line in out.splitlines():
            match = re.search(r"Package\s+(\S+?)\s+is affected by", line)
            if not match:
                continue
            severity = "Unknown"
            risk = re.search(r"\b(Critical|High|Medium|Low)\b\s+risk", line, re.I)
            if risk:
                severity = risk.group(1).capitalize()
            found.append({"name": match.group(1), "severity": severity})
        return found

    def _last_upgrade_ts(self):
        path = Path("/var/log/pacman.log")
        if not path.exists():
            return None
        try:
            with path.open("rb") as handle:
                handle.seek(0, os.SEEK_END)
                size = handle.tell()
                handle.seek(max(0, size - 400_000))
                tail = handle.read().decode("utf-8", errors="ignore")
        except Exception:  # noqa: BLE001
            return None
        stamp = None
        for line in tail.splitlines():
            if "starting full system upgrade" in line:
                match = re.match(r"^\[([^\]]+)\]", line)
                if match:
                    stamp = match.group(1)
        if not stamp:
            return None
        try:
            cleaned = stamp.replace("Z", "+00:00")
            from datetime import datetime
            return datetime.fromisoformat(cleaned).timestamp()
        except Exception:  # noqa: BLE001
            return None

    def _classify(self, packages, security, services=None, dkms=None, news=None,
                  aur=None):
        watchlist = [
            p.strip() for p in str(self.settings["watchlist"]).split(",") if p.strip()
        ]
        security_names = {item["name"] for item in security}
        reasons = []
        important = []

        for pkg in packages:
            flags = []
            name = pkg["name"]

            if any(fnmatch.fnmatch(name, pattern) for pattern in watchlist):
                flags.append("watchlist")

            depth = 2 if name.startswith("linux") else 1
            if _is_major_bump(pkg["old"], pkg["new"], depth):
                flags.append("major")

            if name in security_names:
                flags.append("security")

            pkg["flags"] = flags
            if flags:
                important.append(pkg)

        def _has(flag):
            return [p["name"] for p in important if flag in p["flags"]]

        if security:
            names = sorted({item["name"] for item in security})
            reasons.append({
                "kind": "security",
                "text": "Security fix ready for " + ", ".join(names[:4])
                        + (f" +{len(names) - 4} more" if len(names) > 4 else ""),
            })

        if self.settings["notify_watchlist"]:
            names = _has("watchlist")
            if names:
                reasons.append({
                    "kind": "watchlist",
                    "text": "Update ready for " + ", ".join(names[:4])
                            + (f" +{len(names) - 4} more" if len(names) > 4 else ""),
                })

        if self.settings["notify_major"]:
            names = _has("major")
            if names:
                reasons.append({
                    "kind": "major",
                    "text": "New major version of " + ", ".join(names[:4])
                            + (f" +{len(names) - 4} more" if len(names) > 4 else ""),
                })

        if self.settings["notify_volume"]:
            threshold = int(self.settings["volume_threshold"])
            if len(packages) >= threshold:
                reasons.append({
                    "kind": "volume",
                    "text": f"{len(packages)} updates waiting — a bigger batch than usual",
                })

        if self.settings.get("notify_aur", True) and aur:
            wanted = aur if self.settings.get("notify_aur_devel", True) else [
                a for a in aur if not a["vcs"]
            ]
            if wanted:
                names = ", ".join(a["name"] for a in wanted[:3])
                reasons.append({
                    "kind": "aur",
                    "text": f"AUR update ready for {names}",
                })

        if self.settings.get("notify_news", True) and news:
            unread = [n for n in news if not n["seen"]]
            blockers = [n for n in unread if n["intervention"]]
            if blockers:
                reasons.insert(0, {
                    "kind": "news",
                    "text": "This update needs a manual step: " + blockers[0]["title"],
                })
            elif unread:
                reasons.append({
                    "kind": "news",
                    "text": f"{len(unread)} thing(s) worth reading before you update",
                })

        if self.settings.get("notify_dkms", True) and dkms:
            reasons.append({
                "kind": "dkms",
                "text": "A driver didn't rebuild — sensors or fan control may be affected",
            })

        if self.settings.get("notify_services", True) and services:
            reasons.append({
                "kind": "services",
                "text": f"{len(services)} things are still running an old version",
            })

        stale_since = None
        if self.settings["notify_stale"] and packages:
            last = self._last_upgrade_ts()
            if last:
                days = (time.time() - last) / 86400
                stale_since = round(days, 1)
                if days >= float(self.settings["stale_days"]):
                    reasons.append({
                        "kind": "stale",
                        "text": f"You haven't updated in {int(days)} days",
                    })

        return important, reasons, stale_since

    def _should_announce(self, packages, reasons, aur=None):
        """Dedupe so a pending kernel update doesn't re-toast every poll."""
        if not reasons:
            return False, None
        announced = self._load_json(self._announced_file, {})
        now = time.time()
        cooldown = float(self.settings["cooldown_hours"]) * 3600

        fresh = []
        for pkg in packages:
            key = f"{pkg['name']}@{pkg['new']}"
            seen = announced.get(key)
            if seen is None or (now - seen) > cooldown:
                fresh.append(pkg["name"])
                announced[key] = now

        # Development packages report a constant "latest-commit", so key them on
        # the version you have installed - that changes when you update, which
        # is exactly when it's worth mentioning again.
        for item in aur or []:
            target = item["old"] if item["vcs"] else item["new"]
            key = f"aur:{item['name']}@{target}"
            seen = announced.get(key)
            if seen is None or (now - seen) > cooldown:
                fresh.append(item["name"])
                announced[key] = now

        standalone = ("volume", "stale", "services", "dkms", "news")
        volume_only = all(r["kind"] in standalone for r in reasons)
        if volume_only:
            key = f"__{reasons[0]['kind']}__"
            seen = announced.get(key)
            if seen is not None and (now - seen) <= cooldown:
                return False, None
            announced[key] = now
            fresh = fresh or ["batch"]

        # Prune anything older than 30 days so the file can't grow forever.
        announced = {k: v for k, v in announced.items() if (now - v) < 30 * 86400}
        self._save_json(self._announced_file, announced)
        return bool(fresh), fresh

    async def check_now(self, announce: bool = False):
        await self.check_plugins(announce=announce)
        packages, error = await asyncio.to_thread(self._check_pacman)
        if error:
            self.state = {
                "checked_at": time.time(),
                "error": error,
                "count": 0,
                "packages": [],
                "important": [],
                "reasons": [],
                "flatpak": [],
                "security": [],
                "services": [],
                "dkms": [],
                "news": [],
                "aur": [],
                "blocking_news": False,
                "stale_days_since": None,
            }
            await decky.emit("cachy_updates/state", self.state)
            return self.state

        security = await asyncio.to_thread(self._check_security)
        services = []
        if self.settings.get("notify_services", True):
            services = await asyncio.to_thread(self._check_services)
        dkms = []
        if self.settings.get("notify_dkms", True):
            dkms = await asyncio.to_thread(self._check_dkms)
        news = []
        if self.settings.get("notify_news", True):
            news = await asyncio.to_thread(self._check_news)
        aur = []
        if self.settings.get("include_aur", True):
            aur = await asyncio.to_thread(self._check_aur)
        flatpak = []
        if self.settings["include_flatpak"]:
            flatpak = await asyncio.to_thread(self._check_flatpak)

        important, reasons, stale_since = self._classify(
            packages, security, services, dkms, news, aur
        )
        blocking = bool(
            self.settings.get("block_on_intervention", True)
            and [n for n in news if n["intervention"] and not n["seen"]]
        )

        self.state = {
            "checked_at": time.time(),
            "error": None,
            "count": len(packages),
            "packages": packages,
            "important": important,
            "reasons": reasons,
            "flatpak": flatpak,
            "security": security,
            "services": services,
            "dkms": dkms,
            "news": news,
            "aur": aur,
            "blocking_news": blocking,
            "stale_days_since": stale_since,
        }
        await decky.emit("cachy_updates/state", self.state)

        if announce:
            should, _ = self._should_announce(important or packages, reasons, aur)
            if should:
                headline = reasons[0]["text"]
                extra = f" ({len(packages)} updates total)" if packages else ""
                await decky.emit("cachy_updates/notify", {
                    "title": "Updates ready",
                    "body": headline + extra,
                })
        return self.state

    async def get_state(self):
        return {
            **self.state,
            "last_run": self.last_run,
            "plugin_updates": self.plugin_updates,
            "plugin_error": self.plugin_error,
            "tool_update": self.tool_update,
            "components": self.components,
            "components_running": self.components_running,
            "decky_restart_pending": self.decky_restart_pending,
        }

    # ---------- own plugins ----------

    def _fetch(self, url, dest=None, timeout=60):
        args = ["curl", "-fsSL", "--max-time", str(timeout), "-H", "Cache-Control: no-cache"]
        if dest:
            args += ["-o", str(dest)]
        code, out, err = _run(args + [url], timeout=timeout + 10, stdin_devnull=True)
        if code != 0:
            raise RuntimeError(err.strip() or f"curl exit {code}")
        return out

    def _latest_sha(self):
        """Pin to the newest commit: raw.githubusercontent serves a branch from
        a cache for minutes, a commit never goes stale."""
        try:
            out = self._fetch(
                f"https://api.github.com/repos/{PLUGIN_REPO}/commits/{PLUGIN_BRANCH}",
                timeout=20,
            )
            sha = json.loads(out).get("sha", "")
            if re.fullmatch(r"[0-9a-f]{40}", sha):
                return sha
        except (RuntimeError, ValueError, AttributeError):
            pass
        return PLUGIN_BRANCH

    def _raw(self, sha, path):
        return f"https://raw.githubusercontent.com/{PLUGIN_REPO}/{sha}/{path}"

    def _installed_version(self, folder):
        try:
            with open(self.plugins_root / folder / "package.json") as f:
                return json.load(f).get("version")
        except (OSError, ValueError):
            return None

    def _check_plugins(self):
        sha = self._latest_sha()
        manifest = json.loads(self._fetch(self._raw(sha, PLUGIN_MANIFEST), timeout=30))
        updates = []
        for entry in manifest.get("plugins", []):
            folder = entry.get("dir")
            latest = entry.get("version")
            if not folder or not latest or "/" in folder or folder.startswith("."):
                continue
            installed = self._installed_version(folder)
            if installed is None:
                continue  # not installed here, nothing to update
            packages = _package_list(entry.get("packages"))
            newer = _version_key(latest) > _version_key(installed)
            # A plugin brought up to date some other way (or by an older copy
            # of this plugin) can still be missing a package it now needs.
            missing = [] if newer else _missing_packages(packages)
            if newer or missing:
                updates.append({
                    "dir": folder,
                    "name": entry.get("name") or folder,
                    "installed": installed,
                    "latest": latest,
                    "zip": entry.get("zip"),
                    "packages": packages,
                    "packages_only": not newer,
                    "missing": missing,
                })
        return sha, updates

    def _check_tool(self, sha):
        """Is the setup tool on disk behind the repo? Compared by git blob id,
        so nothing is downloaded until there is something to install."""
        try:
            path = Path(TOOL_PATH_FILE.read_text().strip())
            data = path.read_bytes()
        except OSError:
            return None
        if _in_git_checkout(path):
            # A checkout updates with git pull; the tool's own `u` does that.
            return None
        tree = json.loads(self._fetch(
            f"https://api.github.com/repos/{PLUGIN_REPO}/git/trees/{sha}", timeout=20,
        ))
        remote = next((e.get("sha") for e in tree.get("tree", []) if e.get("path") == TOOL_FILE), None)
        if not remote or remote == _git_blob_sha(data):
            return None
        return {"path": str(path), "blob": remote}

    async def check_plugins(self, announce: bool = False):
        try:
            sha, updates = await asyncio.to_thread(self._check_plugins)
            self.plugin_sha, self.plugin_updates, self.plugin_error = sha, updates, None
        except Exception as exc:  # noqa: BLE001
            self.plugin_error = f"Could not check your plugins: {exc}"
            decky.logger.warning(self.plugin_error)
            return await self.get_state()

        tool = None
        if re.fullmatch(r"[0-9a-f]{40}", sha or ""):
            try:
                tool = await asyncio.to_thread(self._check_tool, sha)
            except Exception as exc:  # noqa: BLE001
                decky.logger.warning("setup tool check failed: %s", exc)
        self.tool_update = tool
        try:
            self.components = await asyncio.to_thread(self._check_components, tool)
        except Exception as exc:  # noqa: BLE001
            decky.logger.warning("setup tool component check failed: %s", exc)
        if announce:
            await self._announce_components()
        if announce and tool:
            announced = self._load_json(self._announced_file, {})
            key = f"tool:{tool['blob']}"
            if key not in announced:
                announced[key] = time.time()
                self._save_json(self._announced_file, announced)
                await decky.emit("cachy_updates/notify", {
                    "title": "Setup tool update",
                    "body": "A new version of bc250-setup is out. Open System Updates to install.",
                })

        if announce and updates:
            announced = self._load_json(self._announced_file, {})
            fresh = [u for u in updates if f"plugin:{u['dir']}:{u['latest']}" not in announced]
            if fresh:
                now = time.time()
                for u in fresh:
                    announced[f"plugin:{u['dir']}:{u['latest']}"] = now
                self._save_json(self._announced_file, announced)
                names = ", ".join(u["name"] for u in fresh)
                await decky.emit("cachy_updates/notify", {
                    "title": "Plugin update",
                    "body": f"New version of {names}. Open System Updates to install.",
                })
        return await self.get_state()

    def _install_plugin_zip(self, sha, item):
        zip_path = item.get("zip") or ""
        if not re.fullmatch(r"plugins/[A-Za-z0-9._ -]+\.zip", zip_path):
            raise RuntimeError(f"bad zip path for {item['name']}")
        work = Path(tempfile.mkdtemp(prefix="plugin-update-"))
        try:
            archive = work / "plugin.zip"
            self._fetch(self._raw(sha, zip_path.replace(" ", "%20")), dest=archive, timeout=120)
            unpacked = work / "unpacked"
            with zipfile.ZipFile(archive) as zf:
                for name in zf.namelist():
                    if name.startswith("/") or ".." in Path(name).parts:
                        raise RuntimeError(f"unsafe path in {zip_path}: {name}")
                zf.extractall(unpacked)
            source = unpacked / item["dir"]
            if not (source / "plugin.json").is_file():
                raise RuntimeError(f"{zip_path} has no {item['dir']}/plugin.json")

            # Staged next to the plugins folder, not inside it: Decky watches
            # that folder and would load a half-copied plugin it found there.
            # Same filesystem, so the swap below is two renames.
            stage = self.plugins_root.parent / ".plugin-staging"
            stage.mkdir(exist_ok=True)
            target = self.plugins_root / item["dir"]
            old = stage / f"{item['dir']}.old"
            shutil.rmtree(old, ignore_errors=True)
            staged = stage / f"{item['dir']}.new"
            shutil.rmtree(staged, ignore_errors=True)
            shutil.copytree(source, staged, symlinks=True)
            for root, dirs, files in os.walk(staged):
                for n in dirs + files:
                    os.lchown(os.path.join(root, n), 0, 0)
            os.lchown(staged, 0, 0)
            if target.exists():
                os.rename(target, old)
            os.rename(staged, target)
            shutil.rmtree(old, ignore_errors=True)
        finally:
            shutil.rmtree(work, ignore_errors=True)

    # ---------- what the setup tool installed ----------

    def _remote_head(self, url):
        code, out, _ = _run(["git", "ls-remote", url, "HEAD"], timeout=60, stdin_devnull=True)
        sha = out.split()[0] if code == 0 and out.split() else ""
        return sha if re.fullmatch(r"[0-9a-f]{40}", sha) else None

    def _check_led(self):
        if not (LED_SRC / ".git").is_dir():
            return None, "Not a git checkout, so it can't be checked"
        git = ["git", "-c", f"safe.directory={LED_SRC}", "-C", str(LED_SRC)]
        code, local, _ = _run(git + ["rev-parse", "HEAD"], timeout=30)
        code2, url, _ = _run(git + ["remote", "get-url", "origin"], timeout=30)
        remote = self._remote_head(url.strip()) if code2 == 0 else None
        if code != 0 or not remote:
            return None, "Couldn't reach its repo to check"
        firmware = self._led_firmware_due()
        if local.strip() != remote:
            return remote, "Update available" + (" (with new receiver firmware)" if firmware else "")
        if firmware:
            # Keyed by the release, so the notification goes out once per release.
            return f"firmware:{firmware}", f"New receiver firmware {firmware}"
        return False, "Up to date"

    def _led_firmware_due(self):
        """The newest receiver firmware release if it isn't what was last
        flashed, else None. A receiver that switches the PSU is never flashed
        unattended, so it never counts as due."""
        try:
            cfg = json.loads(LED_CONFIG.read_text())
            if (cfg.get("power_switch") or {}).get("enabled"):
                return None
        except (OSError, ValueError):
            pass
        try:
            release = json.loads(self._fetch(
                f"https://api.github.com/repos/{LED_FW_REPO}/releases/latest", timeout=20,
            ))
        except Exception:  # noqa: BLE001
            return None
        tag = release.get("tag_name") if isinstance(release, dict) else None
        if not tag:
            return None
        try:
            flashed = LED_FW_STATE.read_text().strip()
        except OSError:
            flashed = ""
        return None if flashed == tag else tag

    def _check_ctlcenter(self):
        code, out, _ = _run(["pacman", "-Q", CTLCENTER_PKG], timeout=30)
        if code != 0:
            return None, "Not installed as a package"
        version = out.split()[-1]
        # VCS packages put the commit in their version: r123.abc1234 or
        # 1.0.r5.gabc1234.
        m = re.search(r"(?:r\d+\.g?|[.+_]g)([0-9a-f]{7,40})(?:-\d+)?$", version)
        remote = self._remote_head(CTLCENTER_UPSTREAM)
        if not m or not remote:
            return None, "Couldn't check for updates"
        if remote.startswith(m.group(1)):
            return False, "Up to date"
        return remote, "Update available"

    def _check_components(self, tool):
        found = []
        for key, name in TOOL_COMPONENTS:
            if not (TOOL_STATE_DIR / key).exists():
                continue
            item = {"id": key, "name": name, "update": False, "remote": None}
            if key == "led":
                remote, note = self._check_led()
            elif key == "ctlcenter":
                remote, note = self._check_ctlcenter()
            else:
                remote = None
                note = "Updates with the setup tool" if tool else "Up to date"
                item["update"] = bool(tool)
            if remote:
                item["update"], item["remote"] = True, remote
            item["note"] = note
            found.append(item)
        return found

    async def _announce_components(self):
        fresh = []
        announced = self._load_json(self._announced_file, {})
        for c in self.components:
            if c.get("remote"):
                key = f"component:{c['id']}:{c['remote']}"
                if key not in announced:
                    announced[key] = time.time()
                    fresh.append(c["name"])
        if fresh:
            self._save_json(self._announced_file, announced)
            await decky.emit("cachy_updates/notify", {
                "title": "Setup tool update",
                "body": f"Update for {', '.join(fresh)}. Open System Updates to install.",
            })

    def _tool_path(self):
        try:
            path = TOOL_PATH_FILE.read_text().strip()
        except OSError:
            return None
        return path if path and Path(path).is_file() else None

    def _run_tool(self, path, flag):
        code, out, err = _run(
            ["env", f"SUDO_USER={self.user}", "NO_COLOR=1", "sh", path, flag],
            timeout=1800, stdin_devnull=True,
        )
        log = (out + err).strip()
        decky.logger.info("setup tool %s exited %s:\n%s", flag, code, log[-4000:])
        return code, log

    async def update_components(self):
        """Bring everything the setup tool installed up to date, with what it
        depends on: the script and what it wrote, the LED daemon, and the
        Control Center (built from the AUR, its dependencies from the repos)."""
        if self.components_running:
            return {"ok": False, "message": "Already updating."}
        reason = await self._busy_reason()
        if reason:
            return {"ok": False, "message": reason}
        if not self.plugin_sha:
            await self.check_plugins()
        self.components_running = True
        done, failed = [], []
        try:
            if self.tool_update:
                try:
                    await asyncio.to_thread(self._install_tool, self.plugin_sha, self.tool_update)
                    self.tool_update = None
                except Exception as exc:  # noqa: BLE001
                    return {"ok": False, "message": f"Could not update the setup tool: {exc}"}
                code, log = await asyncio.to_thread(self._run_tool, self._tool_path(), "--refresh")
                if code == 0:
                    done.append("Setup tool")
                    try:
                        TOOL_REFRESH_FLAG.unlink()
                    except OSError:
                        pass
                else:
                    failed.append("Setup tool")
            path = self._tool_path()
            for c in self.components:
                flag = {"led": "--update-led", "ctlcenter": "--update-ctlcenter"}.get(c["id"])
                if not flag or not c.get("remote"):
                    continue
                if not path:
                    failed.append(c["name"])
                    continue
                code, log = await asyncio.to_thread(self._run_tool, path, flag)
                (done if code == 0 else failed).append(c["name"])
        finally:
            self.components_running = False
            try:
                self.components = await asyncio.to_thread(self._check_components, self.tool_update)
            except Exception:  # noqa: BLE001
                pass
        if failed:
            return {"ok": False, "message": f"Updated {', '.join(done) or 'nothing'}; "
                    f"{', '.join(failed)} failed. Run the setup tool to see why."}
        return {"ok": True, "message": f"Updated {', '.join(done) or 'everything'}."}

    def _install_tool(self, sha, item):
        target = Path(item["path"])
        # Same directory, so the swap is a rename and a crash leaves either the
        # old file or the new one, never half of each.
        fd, tmp = tempfile.mkstemp(prefix=".bc250-setup.", dir=str(target.parent))
        os.close(fd)
        tmp = Path(tmp)
        try:
            self._fetch(self._raw(sha, TOOL_FILE), dest=tmp, timeout=120)
            data = tmp.read_bytes()
            if _git_blob_sha(data) != item["blob"]:
                raise RuntimeError("download does not match the repo copy")
            if b"BC-250 setup" not in data:
                raise RuntimeError("download doesn't look like the setup tool")
            code, _, err = _run(["sh", "-n", str(tmp)], timeout=30)
            if code != 0:
                raise RuntimeError(f"download is not valid shell: {err.strip()}")
            st = target.stat()
            os.chown(tmp, st.st_uid, st.st_gid)
            os.chmod(tmp, st.st_mode & 0o7777)
            shutil.copy2(target, target.with_name(target.name + ".bak"))
            os.rename(tmp, target)
        finally:
            if tmp.exists():
                tmp.unlink()
        # Same as the tool's own update: helpers it wrote to disk are re-applied
        # the next time it runs.
        try:
            TOOL_REFRESH_FLAG.touch()
        except OSError:
            pass

    def _refresh_tool(self, path):
        """Have the new script re-write the helpers, units and packages of
        whatever it installed, exactly like its menu does after an update."""
        code, out, err = _run(
            ["env", f"SUDO_USER={self.user}", "NO_COLOR=1", "sh", path, "--refresh"],
            timeout=900, stdin_devnull=True,
        )
        log = (out + err).strip()
        decky.logger.info("setup tool refresh exited %s:\n%s", code, log[-4000:])
        return code, log

    async def update_tool(self):
        if not self.tool_update or not self.plugin_sha:
            await self.check_plugins()
        if not self.tool_update:
            return {"ok": True, "message": "The setup tool is already up to date."}
        reason = await self._busy_reason()
        if reason:
            return {"ok": False, "message": reason}
        try:
            await asyncio.to_thread(self._install_tool, self.plugin_sha, self.tool_update)
        except Exception as exc:  # noqa: BLE001
            decky.logger.error("setup tool update failed: %s", exc)
            return {"ok": False, "message": str(exc)}
        path = self.tool_update["path"]
        self.tool_update = None
        code, log = await asyncio.to_thread(self._refresh_tool, path)
        if code != 0:
            last = log.splitlines()[-1] if log else f"exit {code}"
            return {
                "ok": False,
                "message": f"Updated, but re-applying its changes failed ({last}). Run the tool once to finish.",
            }
        # The script clears its own flag after a refresh; make sure the menu
        # doesn't ask again for what was just done.
        try:
            TOOL_REFRESH_FLAG.unlink()
        except OSError:
            pass
        return {"ok": True, "message": "Updated and applied. Nothing else to do."}

    async def update_plugins(self):
        if not self.plugin_updates or not self.plugin_sha:
            await self.check_plugins()
        reason = await self._busy_reason()
        if reason:
            return {"ok": False, "updated": [], "failed": [{"name": "Plugins", "error": reason}]}
        items = list(self.plugin_updates)
        if not items:
            return {"ok": True, "updated": [], "failed": []}
        # This plugin replaces itself last, so the others are done if that goes
        # wrong.
        items.sort(key=lambda u: u["dir"] == Path(os.environ.get("DECKY_PLUGIN_DIR", "")).name)
        updated, failed = [], []
        for item in items:
            try:
                if not item.get("packages_only"):
                    await asyncio.to_thread(self._install_plugin_zip, self.plugin_sha, item)
                packages = item.get("packages") or []
                if packages:
                    # What the setup tool installs alongside the plugin.
                    code, out, err = await asyncio.to_thread(
                        _run, ["pacman", "-S", "--needed", "--noconfirm", *packages], 900, True,
                    )
                    if code != 0:
                        detail = (err or out).strip().splitlines()
                        raise RuntimeError(
                            "plugin files updated, but installing %s failed: %s"
                            % (" ".join(packages), detail[-1] if detail else f"exit {code}")
                        )
                updated.append(item["name"])
            except Exception as exc:  # noqa: BLE001
                decky.logger.error("plugin update %s failed: %s", item["dir"], exc)
                failed.append({"name": item["name"], "error": str(exc)})
        # New files are in place but Decky keeps running the old ones until
        # it restarts. That is left to you (restart_decky), so it never cuts
        # into a system update that is still going.
        new_files = {i["name"] for i in items if not i.get("packages_only")}
        for name in updated:
            if name in new_files and name not in self.decky_restart_pending:
                self.decky_restart_pending.append(name)
        self.plugin_updates = [u for u in self.plugin_updates if u["name"] not in updated]
        return {"ok": not failed, "updated": updated, "failed": failed}

    async def _busy_reason(self):
        """Why touching Decky or plugins now would be a bad idea, or None."""
        if (await self.update_status())["running"]:
            return "A system update is running. Let it finish first."
        if (await self.lock_state())["live"]:
            return "Another update is running. Let it finish first."
        return None

    async def restart_decky(self):
        reason = await self._busy_reason()
        if reason:
            return {"ok": False, "message": reason}
        # Scheduled through systemd so it outlives this backend, which the
        # restart stops; a few seconds lets this answer reach the panel first.
        code, _, err = await asyncio.to_thread(
            _run,
            ["systemd-run", "--on-active=3", "--collect",
             "systemctl", "restart", "plugin_loader"],
            30,
        )
        if code != 0:
            decky.logger.error("could not schedule Decky restart: %s", err)
            return {"ok": False, "message": "Could not restart Decky. Reboot to finish."}
        self.decky_restart_pending = []
        return {"ok": True, "message": "Decky is restarting."}

    # ---------- applying ----------

    def _write_script(self):
        keyrings = []
        for pkg in ("archlinux-keyring", "cachyos-keyring"):
            code, _, _ = _run(["pacman", "-Si", pkg], timeout=60)
            if code == 0:
                keyrings.append(pkg)

        build_dir = self.runtime_dir / "build"
        user = self.user
        script = f"""#!/bin/bash
LOG="{self._log_file}"
RESULT="{self._result_file}"
exec > >(tee -a "$LOG") 2>&1

finish() {{
  rc=$?
  printf '{{"rc":%d,"finished":%d}}\\n' "$rc" "$(date +%s)" > "$RESULT"
}}
trap finish EXIT

echo "=== update started $(date -Is) ==="

if [ -n "{' '.join(keyrings)}" ]; then
  echo "--- refreshing keyrings ---"
  pacman -Sy --needed --noconfirm {' '.join(keyrings)} || echo "keyring refresh failed, continuing"
fi

echo "--- pacman -Syu ---"
pacman -Syu --noconfirm --disable-download-timeout
rc=$?
if [ "$rc" -ne 0 ]; then
  echo "!!! pacman failed with exit code $rc — stopping here."
  echo "!!! Finish this one in Desktop Mode; do not re-run blindly."
  exit "$rc"
fi

if [ "$DO_FLATPAK" = "1" ] && command -v flatpak >/dev/null; then
  echo "--- flatpak (system) ---"
  flatpak update -y --noninteractive || echo "system flatpak update failed"
  echo "--- flatpak (user) ---"
  uid="$(id -u "{self.user}" 2>/dev/null)"
  if [ -n "$uid" ]; then
    runuser -u "{self.user}" -- env "XDG_RUNTIME_DIR=/run/user/$uid" \\
      flatpak update -y --noninteractive --user \\
      || echo "user flatpak update failed"
  fi
fi

if [ "$DO_AUR" = "1" ] && [ -n "$AUR_PKGS" ]; then
  echo "--- AUR ---"
  BUILD="{build_dir}"
  mkdir -p "$BUILD"
  chown "{user}" "$BUILD"
  for pkg in $AUR_PKGS; do
    echo "--- AUR: $pkg ---"
    DIR="$BUILD/$pkg"
    if [ -d "$DIR/.git" ]; then
      runuser -u "{user}" -- git -C "$DIR" fetch --depth 1 origin master \\
        && runuser -u "{user}" -- git -C "$DIR" reset --hard origin/master \\
        || {{ echo "fetch failed for $pkg"; continue; }}
    else
      rm -rf "$DIR"
      runuser -u "{user}" -- git clone --depth 1 \\
        "https://aur.archlinux.org/$pkg.git" "$DIR" \\
        || {{ echo "clone failed for $pkg"; continue; }}
    fi

    # Install build+runtime deps as root first, so makepkg never needs sudo.
    DEPS=$(runuser -u "{user}" -- bash -c "cd '$DIR' && makepkg --printsrcinfo" \\
      | awk -F' = ' '/^\\t(make)?depends/ {{print $2}}' \\
      | sed 's/[<>=].*//' | sort -u | tr '\\n' ' ')
    if [ -n "$DEPS" ]; then
      echo "deps: $DEPS"
      pacman -S --needed --asdeps --noconfirm $DEPS || echo "some deps unavailable"
    fi

    rm -f "$DIR"/*.pkg.tar.*
    # --nodeps: deps are already handled above, as root.
    if ! runuser -u "{user}" -- bash -c \\
      "cd '$DIR' && makepkg -f --noconfirm --nodeps --noprogressbar"; then
      echo "!!! build failed for $pkg — skipping, other packages continue"
      continue
    fi

    if ! pacman -U --noconfirm "$DIR"/*.pkg.tar.*; then
      echo "!!! install failed for $pkg"
    fi
  done
fi

echo "=== update finished $(date -Is) ==="
"""
        self._script_file.parent.mkdir(parents=True, exist_ok=True)
        self._script_file.write_text(script)
        self._script_file.chmod(0o755)

    async def ack_news(self):
        store = self._load_json(self._announced_file, {})
        now = time.time()
        for item in self.state.get("news", []) or []:
            store[f"news:{item['title']}"] = now
        self._save_json(self._announced_file, store)
        return await self.check_now(announce=False)

    async def lock_state(self):
        """A killed pacman can leave /var/lib/pacman/db.lck behind. Removing it
        while pacman is alive corrupts the DB, so check for a live process."""
        lock = Path("/var/lib/pacman/db.lck")
        if not lock.exists():
            return {"locked": False, "live": False, "age_min": 0}
        code, out, _ = await asyncio.to_thread(_run, ["pgrep", "-x", "pacman"], 30)
        live = code == 0 and bool(out.strip())
        try:
            age = int((time.time() - lock.stat().st_mtime) / 60)
        except OSError:
            age = 0
        return {"locked": True, "live": live, "age_min": age}

    async def clear_lock(self):
        info = await self.lock_state()
        if not info["locked"]:
            return {"ok": True, "message": "Nothing to clear."}
        if info["live"]:
            return {
                "ok": False,
                "message": "An update is still running. Let it finish.",
            }
        try:
            Path("/var/lib/pacman/db.lck").unlink()
            return {"ok": True, "message": "Cleared. Try updating again."}
        except OSError as exc:
            return {"ok": False, "message": str(exc)}

    def _preflight(self):
        """Reasons an update can't work right now, or None."""
        try:
            cmdline = Path("/proc/cmdline").read_text()
        except OSError:
            cmdline = ""
        # Limine's snapshot entries boot a read-only snapshot with changes in
        # a small RAM overlay: an update fills it, and is gone on reboot.
        if "/.snapshots/" in cmdline:
            return ("This boot is a snapshot, so an update would only go to RAM "
                    "and be lost on restart. Reboot into the normal entry first.")
        try:
            free = shutil.disk_usage("/").free
        except OSError:
            return None
        if free < MIN_FREE_BYTES:
            return (f"Only {free / 1024 ** 3:.1f} GB free on the system drive. "
                    "Free up some space first.")
        return None

    async def start_update(self):
        problem = await asyncio.to_thread(self._preflight)
        if problem:
            return {"ok": False, "error": problem}
        if self.state.get("blocking_news"):
            return {
                "ok": False,
                "error": "One update needs a manual step first. Read it, then mark it read.",
            }
        status = await self.update_status()
        if status["running"]:
            return {"ok": False, "error": "An update is already running."}
        lock = await self.lock_state()
        if lock["locked"]:
            if lock["live"]:
                return {"ok": False, "error": "Another update is already running."}
            return {
                "ok": False,
                "error": "A previous update left a lock behind. "
                         "Use Clear leftover lock in Troubleshooting.",
            }

        try:
            self._log_file.unlink(missing_ok=True)
            self._result_file.unlink(missing_ok=True)
        except Exception:  # noqa: BLE001
            pass

        await asyncio.to_thread(self._write_script)
        _run(["systemctl", "reset-failed", UNIT], timeout=30)

        # Only ever build what the last check actually reported.
        aur_list = " ".join(
            a["name"]
            for a in (self.state.get("aur") or [])
            if re.match(r"^[A-Za-z0-9@._+-]+$", a["name"])
        )

        args = [
            "systemd-run",
            f"--unit={UNIT}",
            "--property=Type=oneshot",
            # 'infinity' is the only value systemd treats as no limit; 0 gives
            # the unit a zero-second budget and it gets killed on the spot.
            "--property=TimeoutStartSec=infinity",
            "--property=TimeoutStopSec=infinity",
            # Never SIGKILL a running pacman - a half-written package DB is far
            # worse than a unit that outlives a cancel.
            "--property=KillMode=process",
            "--property=KillSignal=SIGTERM",
            "--no-block",
            f"--setenv=DO_FLATPAK={'1' if self.settings['include_flatpak'] else '0'}",
            f"--setenv=DO_AUR={'1' if self.settings.get('install_aur') else '0'}",
            f"--setenv=AUR_PKGS={aur_list}",
            "/bin/bash",
            str(self._script_file),
        ]
        code, out, err = await asyncio.to_thread(_run, args, 60)
        if code != 0:
            return {"ok": False, "error": (err or out or f"systemd-run exited {code}").strip()}
        return {"ok": True}

    async def update_status(self):
        code, out, _ = await asyncio.to_thread(
            _run, ["systemctl", "is-active", UNIT], 30
        )
        active = out.strip()
        running = active in ("activating", "active", "reloading")
        result = self._load_json(self._result_file, None)
        return {
            "running": running,
            "active": active,
            "last_rc": None if result is None else result.get("rc"),
            "finished_at": None if result is None else result.get("finished"),
        }

    async def get_log(self, lines: int = 60):
        try:
            text = self._log_file.read_text(errors="ignore")
        except Exception:  # noqa: BLE001
            code, out, _ = await asyncio.to_thread(
                _run, ["journalctl", "-u", UNIT, "-n", str(lines), "--no-pager", "-o", "cat"], 60
            )
            text = out if code == 0 else ""
        tail = text.splitlines()[-int(lines):]
        return "\n".join(tail)

    async def cancel_update(self):
        await asyncio.to_thread(_run, ["systemctl", "stop", UNIT], 60)
        return {"ok": True}

    # ---------- reboot ----------

    async def restart_services(self, names: list):
        """Restarting the network stack from inside a live session drops your
        connection, so those are deliberately excluded — a reboot handles them."""
        unsafe = {
            "NetworkManager.service", "wpa_supplicant.service",
            "systemd-udevd.service", "systemd-resolved.service",
            "dbus.service", "dbus-broker.service", "iwd.service",
        }
        done, skipped, failed = [], [], []
        for name in names or []:
            if name in unsafe:
                skipped.append(name)
                continue
            code, _, err = await asyncio.to_thread(
                _run, ["systemctl", "restart", name], 90
            )
            (done if code == 0 else failed).append(name)
            if code != 0:
                decky.logger.error("restart %s failed: %s", name, err)
        return {"restarted": done, "skipped": skipped, "failed": failed}

    async def needs_reboot(self):
        def _check():
            try:
                boot = 0
                for line in Path("/proc/stat").read_text().splitlines():
                    if line.startswith("btime "):
                        boot = int(line.split()[1])
                if not boot:
                    return {"needed": False, "reason": None}

                running = os.uname().release
                if not Path(f"/usr/lib/modules/{running}").is_dir():
                    return {"needed": True, "reason": "the running kernel's modules are gone"}

                for marker in REBOOT_MARKERS:
                    path = Path(marker)
                    if path.exists() and path.stat().st_mtime > boot:
                        return {"needed": True, "reason": f"{path.name} was updated"}

                modules = Path("/usr/lib/modules")
                if modules.is_dir():
                    for child in modules.iterdir():
                        if child.is_dir() and child.name != running and child.stat().st_mtime > boot:
                            return {"needed": True, "reason": "a newer kernel is installed"}
                return {"needed": False, "reason": None}
            except Exception as exc:  # noqa: BLE001
                decky.logger.error("reboot check failed: %s", exc)
                return {"needed": False, "reason": None}

        return await asyncio.to_thread(_check)

    async def do_reboot(self):
        await asyncio.to_thread(_run, ["systemctl", "reboot"], 30)
        return {"ok": True}

    # ---------- settings ----------

    async def get_settings(self):
        return self.settings

    async def set_settings(self, patch: dict):
        for key, value in (patch or {}).items():
            if key in DEFAULTS:
                self.settings[key] = value
        self._save_json(self._settings_file, self.settings)
        self._restart_poll()
        return self.settings

    async def reset_watchlist(self):
        self.settings["watchlist"] = DEFAULT_WATCHLIST
        self._save_json(self._settings_file, self.settings)
        return self.settings

    # ---------- background poll ----------

    def _restart_poll(self):
        if self.poll_task:
            self.poll_task.cancel()
        self.poll_task = asyncio.create_task(self._poll_loop())

    async def _poll_loop(self):
        try:
            await asyncio.sleep(90)  # let the session settle after boot
            while True:
                try:
                    await self.check_now(announce=True)
                except Exception as exc:  # noqa: BLE001
                    decky.logger.error("poll failed: %s", exc)
                hours = max(1.0, float(self.settings.get("poll_hours", 6)))
                await asyncio.sleep(hours * 3600)
        except asyncio.CancelledError:
            pass

    async def _on_finished(self, status):
        """Runs whether or not the panel is open - the UI used to own this, which
        is why a finished update left a stale count on screen."""
        before = int(self.state.get("count", 0) or 0)
        try:
            await self.check_now(announce=False)
        except Exception as exc:  # noqa: BLE001
            decky.logger.error("post-update check failed: %s", exc)
        after = int(self.state.get("count", 0) or 0)
        try:
            reboot = await self.needs_reboot()
        except Exception:  # noqa: BLE001
            reboot = {"needed": False, "reason": None}

        rc = status.get("last_rc")
        self.last_run = {
            "finished": status.get("finished_at") or time.time(),
            "rc": rc,
            "ok": rc == 0,
            "installed": max(0, before - after) if rc == 0 else 0,
            "attempted": before,
            "remaining": after,
            "reboot": reboot.get("needed", False),
            "reboot_reason": reboot.get("reason"),
        }
        self._save_json(self._last_run_file, self.last_run)

        if rc == 0:
            count = self.last_run["installed"] or self.last_run["attempted"]
            body = f"{count} update{'s' if count != 1 else ''} installed."
            if reboot.get("needed"):
                body += " Restart to finish."
            title = "Updates installed"
        else:
            title = "Update didn't finish"
            body = "Open System Updates to see what happened."

        await decky.emit("cachy_updates/finished", self.last_run)
        await decky.emit("cachy_updates/notify", {"title": title, "body": body})

    async def _finish_watcher(self):
        seen = (self._load_json(self._last_run_file, {}) or {}).get("finished")
        was_running = False
        try:
            while True:
                await asyncio.sleep(5)
                try:
                    status = await self.update_status()
                except Exception:  # noqa: BLE001
                    continue
                if status["running"]:
                    was_running = True
                    continue
                finished = status.get("finished_at")
                # Either a fresh result landed, or we watched it stop.
                if (finished and finished != seen) or was_running:
                    seen = finished
                    was_running = False
                    await self._on_finished(status)
        except asyncio.CancelledError:
            pass

    # ---------- lifecycle ----------

    async def _main(self):
        decky.logger.info("System Updates: starting")
        self.settings_dir.mkdir(parents=True, exist_ok=True)
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        stored = self._load_json(self._settings_file, {})
        for key, value in stored.items():
            if key in DEFAULTS:
                self.settings[key] = value
        self.last_run = self._load_json(self._last_run_file, None)
        self._restart_poll()
        self.finish_task = asyncio.create_task(self._finish_watcher())

    async def _unload(self):
        if self.poll_task:
            self.poll_task.cancel()
        if getattr(self, "finish_task", None):
            self.finish_task.cancel()
        decky.logger.info("System Updates: unloaded")
