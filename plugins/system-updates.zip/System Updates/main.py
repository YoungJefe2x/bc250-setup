import asyncio
import base64
import fnmatch
import glob
import json
import os
import pwd
import re
import shutil
import signal
import subprocess
import tempfile
import time
import urllib.parse
import zipfile
from pathlib import Path

import decky

UNIT = "decky-sysupdate"

# pacman needs room to unpack on top of the downloaded packages.
MIN_FREE_BYTES = 3 * 1024 ** 3

# This repo's plugins are not in the Decky store, so Decky never offers updates
# for them. The repo lists what it ships in plugins/versions.json; compare the
# installed copies against that and offer to update them here instead.
PLUGIN_REPO = "YoungJefe2x/bc250-setup"
PLUGIN_BRANCH = "main"
PLUGIN_MANIFEST = "plugins/versions.json"

# The setup tool itself. The installer writes where it lives on every run; a
# copy that was never run since that was added simply isn't offered.
TOOL_FILE = "bc250-setup.sh"
TOOL_STATE_DIR = Path("/var/lib/bc250-setup")
TOOL_PATH_FILE = TOOL_STATE_DIR / "script-path"
TOOL_REFRESH_FLAG = TOOL_STATE_DIR / ".refresh-needed"

# What the setup tool can install, by the marker file it leaves in
# TOOL_STATE_DIR. Most of it is files the script itself writes, so a new
# script plus its --refresh brings them up to date. The LED daemon and the
# Control Center come from their own upstream repos and are checked there.
TOOL_COMPONENTS = [
    ("cec", "HDMI-CEC TV control"),
    ("led", "LED strip daemon"),
    ("power", "Sleep / suspend off"),
    ("guide", "Guide button input switch"),
    ("decky", "Decky plugins"),
    ("atv", "Android TV (Waydroid)"),
    ("ctlcenter", "BC-250 Control Center"),
    ("boot", "Quick, quiet boot menu"),
]
# Setup tool options the Tools tab can install or remove, by marker name.
# Decky plugins are left out (the Updates tab keeps those current), and so
# are the Experiments, which need someone at the terminal.
SETUP_OPTIONS = [
    ("cec", "HDMI-CEC TV control"),
    ("led", "LED strip daemon"),
    ("power", "Sleep / suspend off"),
    ("guide", "Guide button input switch"),
    ("atv", "Android TV (Waydroid)"),
    ("xcloud", "Xbox Cloud Gaming"),
    ("gfn", "GeForce NOW"),
    ("discord", "Discord"),
    ("jd", "JDownloader 2"),
    ("ctlcenter", "BC-250 Control Center (AUR)"),
    ("boot", "Quick, quiet boot menu"),
    ("streamres", "Steam Link at 1080p"),
    ("claude", "Claude Code auto-update"),
]
SETUP_UNIT = "bc250-setup-job"
SETUP_ACTIONS = {"install", "remove", "install-all", "status", "test-cec", "plugin-install", "plugin-remove"}
LED_SRC = Path("/opt/bc250/bc250_ws2812b_controller")
LED_FW_REPO = "peterdk31/bc250_ws2812b_controller"
LED_FW_STATE = TOOL_STATE_DIR / "led-firmware"

# Launchers the setup tool writes that belong in the Steam library: marker
# in TOOL_STATE_DIR, display name, script in the user's home. The panel adds
# each one as a non-Steam game, and removes it once the marker is gone.
STEAM_SHORTCUTS = [
    ("atv", "Android TV", "waydroid-tv.sh"),
    ("xcloud", "Xbox Cloud Gaming", "xbox-cloud-gaming.sh"),
    ("gfn", "GeForce NOW", "geforce-now.sh"),
    ("discord", "Discord", "discord.sh"),
    ("jd", "JDownloader 2", "jdownloader.sh"),
]

# What to search SteamGridDB for, where the shortcut's name wouldn't match.
STEAM_ART_SEARCH = {"xcloud": "Xbox Cloud Gaming"}

# Icon names to look for when drawing library art, by shortcut key.
STEAM_ART_ICONS = {
    "atv": ["waydroid", "android"],
    "xcloud": ["io.github.unknownskl.greenlight"],
    "gfn": ["com.nvidia.geforcenow"],
    "discord": ["discord", "com.discordapp.Discord", "dev.vencord.Vesktop"],
    "jd": ["org.jdownloader.JDownloader", "jdownloader"],
}

# Shortcuts that get a mouse-style Steam Input layout instead of the default
# gamepad one, because the app itself has no controller support.
STEAM_MOUSE_LAYOUT = {"jd"}

# Controller types the layout is offered for. Bindings name positions
# (south face button, right trigger...), so Steam shows each pad's own glyphs.
STEAM_LAYOUT_TYPES = ["controller_xboxone", "controller_xbox360", "controller_ps4",
                      "controller_ps5", "controller_ps5_edge", "controller_xboxelite",
                      "controller_switch_pro", "controller_generic"]

STEAM_LAYOUT_FILE = "bc250_mouse_{type}.vdf"


def _bind(*bindings, label="", repeat=False):
    """One Full_Press activator; every binding fires together and the label
    (shown in Steam's layout view) goes on the last one."""
    t = "\t" * 7
    lines = "".join(f'{t}"binding"\t\t"{b}"\n' for b in bindings[:-1])
    lines += f'{t}"binding"\t\t"{bindings[-1]}, {label}, , "\n'
    settings = ""
    if repeat:
        settings = (f'{t[:-1]}"settings"\n{t[:-1]}{{\n{t}"hold_repeats"\t\t"1"\n'
                    f'{t}"repeat_rate"\t\t"60"\n{t[:-1]}}}\n')
    return ('\t\t\t\t"activators"\n\t\t\t\t{\n\t\t\t\t\t"Full_Press"\n\t\t\t\t\t{\n'
            f'{t[:-1]}"bindings"\n{t[:-1]}{{\n{lines}{t[:-1]}}}\n{settings}'
            '\t\t\t\t\t}\n\t\t\t\t}\n')


def _group(gid, mode, inputs, settings=None):
    body = "".join(f'\t\t\t"{name}"\n\t\t\t{{\n{acts}\t\t\t}}\n' for name, acts in inputs.items())
    extra = "".join(f'\t\t\t"{k}"\t\t"{v}"\n' for k, v in (settings or {}).items())
    return (f'\t"group"\n\t{{\n\t\t"id"\t\t"{gid}"\n\t\t"mode"\t\t"{mode}"\n'
            f'\t\t"inputs"\n\t\t{{\n{body}\t\t}}\n\t\t"settings"\n\t\t{{\n{extra}\t\t}}\n\t}}\n')


def mouse_layout(ctype):
    """A desktop-style Steam Input layout: right stick moves the pointer,
    triggers click, left stick scrolls."""
    groups = [
        _group(0, "four_buttons", {
            "button_a": _bind("mouse_button LEFT", label="Click"),
            "button_b": _bind("key_press ESCAPE", label="Back"),
            "button_x": _bind("key_press LEFT_CONTROL", "key_press V", label="Paste links"),
            "button_y": _bind("controller_action SHOW_KEYBOARD", label="Keyboard"),
        }),
        _group(1, "dpad", {
            "dpad_north": _bind("key_press UP_ARROW", label="Up", repeat=True),
            "dpad_south": _bind("key_press DOWN_ARROW", label="Down", repeat=True),
            "dpad_east": _bind("key_press RIGHT_ARROW", label="Right", repeat=True),
            "dpad_west": _bind("key_press LEFT_ARROW", label="Left", repeat=True),
        }),
        _group(2, "dpad", {
            "dpad_north": _bind("mouse_wheel SCROLL_UP", label="Scroll up", repeat=True),
            "dpad_south": _bind("mouse_wheel SCROLL_DOWN", label="Scroll down", repeat=True),
            "click": _bind("mouse_button MIDDLE", label="Middle click"),
        }),
        _group(3, "joystick_mouse", {
            "click": _bind("mouse_button LEFT", label="Click"),
        }),
        _group(4, "trigger", {"click": _bind("mouse_button RIGHT", label="Right click")}),
        _group(5, "trigger", {"click": _bind("mouse_button LEFT", label="Click")}),
        _group(6, "switches", {
            "button_escape": _bind("key_press RETURN", label="Enter"),
            "button_menu": _bind("key_press TAB", label="Tab"),
            "left_bumper": _bind("key_press PAGE_UP", label="Page up"),
            "right_bumper": _bind("key_press PAGE_DOWN", label="Page down"),
        }),
    ]
    sources = {6: "switch", 0: "button_diamond", 1: "dpad", 2: "joystick",
               3: "right_joystick", 4: "left_trigger", 5: "right_trigger"}
    preset = "".join(f'\t\t\t"{g}"\t\t"{src} active"\n' for g, src in sources.items())
    return ('"controller_mappings"\n{\n\t"version"\t\t"3"\n\t"revision"\t\t"1"\n'
            '\t"title"\t\t"Mouse and keyboard (BC-250)"\n'
            '\t"description"\t\t"Right stick moves the pointer, triggers click, left stick scrolls."\n'
            f'\t"controller_type"\t\t"{ctype}"\n'
            '\t"localization"\n\t{\n\t\t"english"\n\t\t{\n'
            '\t\t\t"title"\t\t"Mouse and keyboard (BC-250)"\n'
            '\t\t\t"description"\t\t"Right stick moves the pointer, triggers click, left stick scrolls."\n'
            '\t\t}\n\t}\n'
            + "".join(groups)
            + '\t"preset"\n\t{\n\t\t"id"\t\t"0"\n\t\t"name"\t\t"Default"\n'
            '\t\t"group_source_bindings"\n\t\t{\n' + preset + '\t\t}\n\t}\n'
            '\t"settings"\n\t{\n\t}\n}\n')

LED_CONFIG = Path("/etc/led-controller/config.json")
CTLCENTER_PKG = "bc250-control-center-git"
CTLCENTER_UPSTREAM = "https://github.com/movacx/bc250-control-center.git"


_PACKAGE_RE = re.compile(r"[a-z0-9@_+][a-z0-9@._+-]*")


def _package_list(value):
    """Package names from versions.json, dropping anything that isn't one."""
    if not isinstance(value, list):
        return []
    return [p for p in value if isinstance(p, str) and _PACKAGE_RE.fullmatch(p)]


def _missing_packages(packages):
    """Which of these pacman has not installed (pacman -T lists them)."""
    if not packages:
        return []
    code, out, _ = _run(["pacman", "-T", *packages], timeout=60)
    if code == 0:
        return []
    return [p for p in out.split() if p in packages]


def _git_blob_sha(data: bytes) -> str:
    """What git (and the GitHub tree API) calls this file's id."""
    import hashlib
    return hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()


def _in_git_checkout(path: Path) -> bool:
    for parent in path.parents:
        if (parent / ".git").exists():
            return True
    return False


def _version_key(version):
    parts = []
    for piece in re.split(r"[.\-+]", str(version or "0")):
        parts.append(int(piece) if piece.isdigit() else 0)
    return parts

DEFAULT_WATCHLIST = ",".join([
    "linux-cachyos*", "linux", "linux-lts", "linux-firmware",
    "mesa", "lib32-mesa", "vulkan-radeon", "lib32-vulkan-radeon", "nvidia*",
    "systemd", "systemd-libs", "glibc",
    "gamescope*", "steam", "steam-native-runtime", "proton-cachyos",
    "pipewire", "pipewire-pulse", "wireplumber",
    "cachyos-handheld*", "cachyos-settings",
    "plasma-desktop", "plasma-workspace", "kwin", "xorg-server", "limine*",
])

DEFAULTS = {
    "poll_hours": 6,
    "notify_watchlist": True,
    "notify_major": True,
    "notify_volume": True,
    "volume_threshold": 80,
    "notify_stale": True,
    "stale_days": 14,
    "notify_services": True,
    "notify_dkms": True,
    "include_aur": True,
    "notify_aur": True,
    "notify_aur_devel": True,
    "install_aur": False,
    "notify_news": True,
    "news_count": 5,
    "block_on_intervention": True,
    "hold_in_game": True,
    "include_flatpak": True,
    "steamgriddb_key": "",
    # The Tools tab's setup tool options; hidden once the box is set up.
    "show_setup_tools": True,
    "watchlist": DEFAULT_WATCHLIST,
    "cooldown_hours": 72,
}

REBOOT_MARKERS = [
    "/usr/lib/systemd/systemd",
    "/usr/lib/libc.so.6",
    "/usr/lib/libcrypto.so",
]


def _clean_env():
    """Decky's PyInstaller backend exports LD_LIBRARY_PATH pointing at its own
    /tmp/_MEI* bundle. Children inherit it and pick up the wrong libssl, which
    is what produces `OPENSSL_3.4.0 not found` from things like systemctl."""
    env = dict(os.environ)
    for key in ("LD_LIBRARY_PATH", "LD_PRELOAD", "PYTHONHOME", "PYTHONPATH", "_MEIPASS2"):
        env.pop(key, None)
    env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
    env["LC_ALL"] = "C"
    return env


def _run(args, timeout=180, stdin_devnull=False):
    try:
        proc = subprocess.run(
            args,
            env=_clean_env(),
            capture_output=True,
            text=True,
            timeout=timeout,
            stdin=subprocess.DEVNULL if stdin_devnull else None,
        )
        return proc.returncode, proc.stdout, proc.stderr
    except FileNotFoundError:
        return 127, "", f"{args[0]}: not found"
    except subprocess.TimeoutExpired:
        return 124, "", f"{args[0]}: timed out after {timeout}s"
    except Exception as exc:  # noqa: BLE001
        return 1, "", str(exc)


def _strip_epoch(version: str) -> str:
    return version.split(":", 1)[1] if ":" in version else version


def _base_parts(version: str):
    core = _strip_epoch(version).split("-", 1)[0]
    return [p for p in re.split(r"[._+]", core) if p]


def _is_major_bump(old: str, new: str, depth: int = 1) -> bool:
    a, b = _base_parts(old), _base_parts(new)
    return a[:depth] != b[:depth]


def _read_binary_vdf(data):
    """Parse Steam's binary KeyValues (shortcuts.vdf) into nested dicts."""
    pos = 0

    def cstr():
        nonlocal pos
        end = data.index(b"\x00", pos)
        text = data[pos:end].decode("utf-8", "replace")
        pos = end + 1
        return text

    def table():
        nonlocal pos
        out = {}
        while pos < len(data):
            kind = data[pos]
            pos += 1
            if kind == 0x08:
                return out
            key = cstr()
            if kind == 0x00:
                out[key] = table()
            elif kind == 0x01:
                out[key] = cstr()
            elif kind == 0x02:
                out[key] = int.from_bytes(data[pos:pos + 4], "little", signed=True)
                pos += 4
            elif kind == 0x07:
                out[key] = int.from_bytes(data[pos:pos + 8], "little")
                pos += 8
            else:
                raise ValueError(f"unknown vdf type {kind}")
        return out

    return table()


def steam_shortcuts_on_disk(home, account_id=None):
    """Non-Steam shortcuts in shortcuts.vdf as {appid, name, exe}. Uses the
    given Steam account's file, else the newest one. None when it can't be
    read (no Steam user yet, or a file we don't understand); [] when the
    account has no shortcuts."""
    userdata = Path(home) / ".local/share/Steam/userdata"
    if account_id:
        path = userdata / str(account_id) / "config/shortcuts.vdf"
        if not path.is_file():
            return [] if (userdata / str(account_id)).is_dir() else None
    else:
        files = sorted(userdata.glob("*/config/shortcuts.vdf"),
                       key=lambda f: f.stat().st_mtime, reverse=True)
        if not files:
            return None
        path = files[0]
    try:
        root = _read_binary_vdf(path.read_bytes())
    except Exception as exc:  # noqa: BLE001
        decky.logger.error("could not read %s: %s", path, exc)
        return None
    out = []
    for entry in (root.get("shortcuts") or {}).values():
        if not isinstance(entry, dict):
            continue
        fields = {k.lower(): v for k, v in entry.items()}
        appid = fields.get("appid")
        if not isinstance(appid, int) or not appid:
            continue
        out.append({"appid": appid & 0xFFFFFFFF,
                    "name": str(fields.get("appname", "")),
                    "exe": str(fields.get("exe", "")).strip().strip('"')})
    return out


class Plugin:
    def __init__(self):
        self.settings = dict(DEFAULTS)
        self.state = {}
        self.poll_task = None
        self.finish_task = None
        self.last_run = None
        self.settings_dir = Path(
            os.environ.get("DECKY_PLUGIN_SETTINGS_DIR", "/tmp/cachy-updates")
        )
        self.runtime_dir = Path(
            os.environ.get("DECKY_PLUGIN_RUNTIME_DIR", str(self.settings_dir))
        )
        self.user = os.environ.get("DECKY_USER", "deck")
        self.plugin_updates = []
        self.plugin_error = None
        self.plugin_sha = None
        self.tool_update = None
        self.components = []
        self.components_running = False
        # Plugin files swapped in, waiting for you to restart Decky.
        self.decky_restart_pending = []
        self._plugin_names = {}
        self.plugins_root = Path(
            os.environ.get("DECKY_PLUGIN_DIR", "/tmp/plugins/x")
        ).parent

    # ---------- persistence ----------

    @property
    def _settings_file(self):
        return self.settings_dir / "settings.json"

    @property
    def _announced_file(self):
        return self.settings_dir / "announced.json"

    @property
    def _script_file(self):
        return self.runtime_dir / "run-update.sh"

    @property
    def _log_file(self):
        return self.runtime_dir / "update.log"

    @property
    def _last_run_file(self):
        return self.runtime_dir / "finish.json"

    @property
    def _result_file(self):
        return self.runtime_dir / "last-run.json"

    @property
    def _cancel_file(self):
        return self.runtime_dir / "cancel-requested"

    def _load_json(self, path, fallback):
        try:
            return json.loads(path.read_text())
        except Exception:  # noqa: BLE001
            return fallback

    def _save_json(self, path, data):
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(data, indent=2))
        except Exception as exc:  # noqa: BLE001
            decky.logger.error("could not write %s: %s", path, exc)

    # ---------- Steam library shortcuts ----------

    @property
    def _shortcuts_file(self):
        return self.settings_dir / "steam-shortcuts.json"

    async def steam_shortcut_plan(self, account_id=None):
        """Shortcuts to add ("want", with the appid added last time if any)
        and ones to take back out ("drop") because their component is gone.
        Each wanted one also lists the shortcuts Steam already has on disk
        for it ("found"), so the panel can adopt one and remove copies;
        "listed" is false when Steam's shortcut list couldn't be read."""
        try:
            home = pwd.getpwnam(self.user).pw_dir
        except KeyError:
            home = f"/home/{self.user}"
        added = self._load_json(self._shortcuts_file, {})
        on_disk = steam_shortcuts_on_disk(home, account_id)
        want, drop = [], []
        for key, name, script in STEAM_SHORTCUTS:
            exe = os.path.join(home, script)
            if (TOOL_STATE_DIR / key).exists() and os.path.isfile(exe):
                found = []
                for sc in on_disk or []:
                    ours = sc["exe"] == exe
                    if ours or sc["name"].lower() == name.lower():
                        found.append({"appid": sc["appid"], "ours": ours})
                want.append({"key": key, "name": name, "exe": exe,
                             "start_dir": home, "appid": added.get(key),
                             "found": found, "listed": on_disk is not None})
                if key in STEAM_MOUSE_LAYOUT:
                    self._offer_mouse_layout(home, name)
            elif key in added:
                copies = [sc["appid"] for sc in on_disk or [] if sc["exe"] == exe]
                drop.append({"key": key, "name": name, "appid": added[key],
                             "copies": copies})
        return {"want": want, "drop": drop}

    def _offer_mouse_layout(self, home, name):
        """Make the mouse-style layout the default for this shortcut on each
        controller type. Steam reads these files when a controller connects;
        a layout you pick yourself for the app is never replaced."""
        steam = Path(home) / ".local/share/Steam"
        try:
            pw = pwd.getpwnam(self.user)
            templates = steam / "controller_base/templates"
            for ctype in STEAM_LAYOUT_TYPES:
                dest = templates / STEAM_LAYOUT_FILE.format(type=ctype)
                text = mouse_layout(ctype)
                if templates.is_dir() and (not dest.exists() or dest.read_text() != text):
                    dest.write_text(text)
                    os.chown(dest, pw.pw_uid, pw.pw_gid)
            entry = re.escape(f'"{name.lower()}"')
            for account in (steam / "steamapps/common/Steam Controller Configs").glob("[0-9]*/config"):
                for ctype in STEAM_LAYOUT_TYPES:
                    cfg = account / f"configset_{ctype}.vdf"
                    text = cfg.read_text() if cfg.exists() else '"controller_config"\n{\n}\n'
                    if re.search(rf"^\t{entry}\s*$", text, re.M) or text.rstrip()[-1:] != "}":
                        continue
                    block = (f'\t"{name.lower()}"\n\t{{\n\t\t"template"\t\t'
                             f'"{STEAM_LAYOUT_FILE.format(type=ctype)}"\n\t}}\n')
                    cut = text.rstrip().rindex("}")
                    cfg.write_text(text[:cut] + block + "}\n")
                    os.chown(cfg, pw.pw_uid, pw.pw_gid)
        except (OSError, KeyError) as exc:
            decky.logger.error("could not set the controller layout for %s: %s", name, exc)

    def _sgdb_key(self, home):
        """Your own SteamGridDB API key: the setting in this panel, else the
        file ~/.config/steamgriddb-key. (The SteamGridDB Decky plugin's
        built-in key is private to that plugin and is never used here.)"""
        if (self.settings.get("steamgriddb_key") or "").strip():
            return self.settings["steamgriddb_key"].strip()
        try:
            return Path(f"{home}/.config/steamgriddb-key").read_text().strip() or None
        except OSError:
            return None

    def _sgdb_download(self, api_key, game_name, art_key):
        """Top-rated capsule, wide capsule, hero, logo and icon for a game
        name: {kind: (b64, ext)} for the ones found (the icon, kind 4, is
        saved to a file and returned as (path, ext))."""
        base = "https://www.steamgriddb.com/api/v2"
        auth = ["-H", f"Authorization: Bearer {api_key}"]

        def get_json(path):
            rc, out, _ = _run(["curl", "-fsSL", "--max-time", "20", *auth, base + path], timeout=30)
            if rc != 0:
                return None
            try:
                return json.loads(out).get("data")
            except ValueError:
                return None

        found = get_json("/search/autocomplete/" + urllib.parse.quote(game_name))
        if not found:
            return {}
        gid = found[0].get("id")
        # The same filters the SteamGridDB plugin starts with, so the first
        # result here is the first one it shows.
        grid_styles = "alternate,white_logo,no_logo,blurred,material"
        wanted = {
            0: f"/grids/game/{gid}?dimensions=600x900,342x482,660x930&styles={grid_styles}",
            3: f"/grids/game/{gid}?dimensions=460x215,920x430&styles={grid_styles}",
            1: f"/heroes/game/{gid}?dimensions=1920x620,3840x1240,1600x650&styles=alternate,blurred,material",
            2: f"/logos/game/{gid}?styles=official,white,black,custom",
            4: f"/icons/game/{gid}",
        }
        result = {}
        for kind, path in wanted.items():
            items = get_json(path)
            if not items:
                continue
            url = items[0].get("url", "")
            if not url.startswith("https://"):
                continue
            ext = url.rsplit(".", 1)[-1].lower()
            if ext not in ("png", "jpg", "jpeg", "webp"):
                continue
            tmp = tempfile.NamedTemporaryFile(delete=False)
            tmp.close()
            try:
                rc, _, _ = _run(["curl", "-fsSL", "--max-time", "30", "-o", tmp.name, url], timeout=40)
                if rc == 0 and 0 < os.path.getsize(tmp.name) < 8_000_000:
                    ext = "jpg" if ext == "jpeg" else ext
                    if kind == 4:
                        dest = self.settings_dir / "art" / f"{art_key}-icon.{ext}"
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copyfile(tmp.name, dest)
                        result[kind] = (str(dest), ext)
                    else:
                        with open(tmp.name, "rb") as f:
                            result[kind] = (base64.b64encode(f.read()).decode(), ext)
            finally:
                os.unlink(tmp.name)
        return result

    async def steam_art_download(self, key, name):
        """Library art from SteamGridDB: {kind: {"b64", "ext"}}, empty when
        there is no API key or nothing was found."""
        try:
            home = pwd.getpwnam(self.user).pw_dir
        except KeyError:
            home = f"/home/{self.user}"
        api_key = self._sgdb_key(home)
        if not api_key:
            return {}
        term = STEAM_ART_SEARCH.get(key, name)
        got = await asyncio.to_thread(self._sgdb_download, api_key, term, key)
        return {str(k): ({"path": b, "ext": e} if k == 4 else {"b64": b, "ext": e})
                for k, (b, e) in got.items()}

    async def steam_art_source(self, key):
        """The app's own icon (largest PNG found) for drawing library art:
        {"b64", "path"}, or None when no icon is installed."""
        try:
            home = pwd.getpwnam(self.user).pw_dir
        except KeyError:
            home = f"/home/{self.user}"
        roots = [f"{home}/.local/share/flatpak/exports/share/icons",
                 "/var/lib/flatpak/exports/share/icons", "/usr/share/icons"]
        best, best_size = None, -1
        for name in STEAM_ART_ICONS.get(key, []):
            for root in roots:
                for path in glob.glob(f"{root}/hicolor/*/apps/{name}.png"):
                    try:
                        size = int(Path(path).parts[-3].split("x")[0])
                    except ValueError:
                        continue
                    if size > best_size:
                        best, best_size = path, size
            if best is None:
                for path in (f"/usr/share/pixmaps/{name}.png",):
                    if os.path.isfile(path):
                        best = path
            if best:
                break
        if not best:
            return None
        try:
            with open(best, "rb") as f:
                data = f.read()
        except OSError:
            return None
        if len(data) > 4_000_000:
            return None
        return {"b64": base64.b64encode(data).decode(), "path": best}

    async def steam_shortcut_record(self, key, appid):
        added = self._load_json(self._shortcuts_file, {})
        if appid:
            added[key] = appid
        else:
            added.pop(key, None)
        self._save_json(self._shortcuts_file, added)
        return True

    # ---------- checking ----------

    def _check_via_temp_db(self):
        """What checkupdates does, done inline so pacman-contrib isn't required:
        refresh a *copy* of the sync DB in a temp dir and diff against that, so
        the real DB is never touched and we can't cause a partial upgrade."""
        tmp = Path(tempfile.mkdtemp(prefix="decky-checkup-"))
        try:
            db = tmp / "db"
            (db / "sync").mkdir(parents=True, exist_ok=True)
            source = Path("/var/lib/pacman/sync")
            if source.is_dir():
                for item in source.iterdir():
                    if item.is_file():
                        shutil.copy2(item, db / "sync" / item.name)
            (db / "local").symlink_to("/var/lib/pacman/local")

            code, out, err = _run(
                ["pacman", "-Sy", "--dbpath", str(db), "--logfile", "/dev/null"],
                timeout=300,
            )
            if code != 0:
                return None, (err or out or f"pacman -Sy exited {code}").strip()

            code, out, err = _run(["pacman", "-Qu", "--dbpath", str(db)], timeout=120)
            # -Qu exits 1 when there is simply nothing to upgrade.
            if code not in (0, 1):
                return None, (err or out or f"pacman -Qu exited {code}").strip()
            return out, None
        except Exception as exc:  # noqa: BLE001
            return None, str(exc)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def _check_pacman(self):
        if shutil.which("checkupdates"):
            code, out, err = _run(["checkupdates"], timeout=300)
            # checkupdates exits 2 when there is nothing to upgrade.
            if code not in (0, 2):
                return None, (err or out or f"checkupdates exited {code}").strip()
        else:
            out, error = self._check_via_temp_db()
            if error:
                return None, error

        packages = []
        for line in out.splitlines():
            if "[ignored]" in line:
                continue
            match = re.match(r"^(\S+)\s+(\S+)\s+->\s+(\S+)$", line.strip())
            if match:
                packages.append({
                    "name": match.group(1),
                    "old": match.group(2),
                    "new": match.group(3),
                })
        return packages, None

    def _check_flatpak(self):
        if not shutil.which("flatpak"):
            return []
        apps = []
        code, out, _ = _run(
            ["flatpak", "remote-ls", "--updates", "--columns=application"], timeout=180
        )
        if code == 0:
            apps += [l.strip() for l in out.splitlines() if l.strip()]
        code, out, _ = _run(
            ["runuser", "-u", self.user, "--",
             "flatpak", "remote-ls", "--user", "--updates", "--columns=application"],
            timeout=180,
        )
        if code == 0:
            apps += [l.strip() for l in out.splitlines() if l.strip()]
        return sorted(set(apps))

    def _check_news(self):
        """Arch news is published precisely when an upgrade needs a human, so an
        unread 'manual intervention' item is the one thing that should stop an
        unattended --noconfirm run."""
        binary = shutil.which("arch-update") or shutil.which("cachy-update")
        if not binary:
            return []
        count = int(self.settings.get("news_count", 5))
        code, out, _ = _run([binary, "-n", str(count)], timeout=120, stdin_devnull=True)
        if code not in (0, 1, 130):
            return []

        seen_store = self._load_json(self._announced_file, {})
        items = []
        in_section = False
        for line in out.splitlines():
            stripped = line.strip()
            if "Arch News:" in stripped:
                in_section = True
                continue
            if not in_section or not stripped:
                continue
            if stripped.startswith("->"):
                break
            match = re.match(r"^\d+\s+-\s+(.+?)\s*$", stripped)
            if not match:
                continue
            title = match.group(1)
            items.append({
                "title": title,
                "intervention": bool(
                    re.search(r"manual intervention|requires? action", title, re.I)
                ),
                "seen": f"news:{title}" in seen_store,
            })
        return items

    def _check_services(self):
        """arch-update -s lists services still running against deleted libraries.
        It ends on an interactive prompt, so stdin is closed to make it fall
        straight through after printing the list."""
        binary = shutil.which("arch-update") or shutil.which("cachy-update")
        if not binary:
            return []
        code, out, _ = _run([binary, "-s"], timeout=120, stdin_devnull=True)
        if code not in (0, 1, 130):
            return []
        services = []
        for line in out.splitlines():
            match = re.match(r"^\s*\d+\s+-\s+(\S+\.(?:service|socket|timer))\s*$", line)
            if match:
                services.append(match.group(1))
        return services

    def _check_dkms(self):
        """A DKMS module that failed to rebuild leaves pacman's exit code at 0,
        so a broken sensors or driver module would otherwise pass silently."""
        if not shutil.which("dkms"):
            return []
        code, out, _ = _run(["dkms", "status"], timeout=60)
        if code != 0:
            return []
        broken = []
        for line in out.splitlines():
            if not line.strip():
                continue
            lowered = line.lower()
            if "installed" in lowered or "built" in lowered:
                continue
            if any(word in lowered for word in ("error", "failed", "broken", "added")):
                broken.append(line.strip())
        return broken

    def _check_aur(self):
        """VCS packages (-git and friends) always report a pending 'update', so
        they're listed but never allowed to trigger a notification."""
        helper = None
        for candidate in ("paru", "yay"):
            if shutil.which(candidate):
                helper = candidate
                break
        if not helper:
            return []

        code, out, _ = _run(
            ["runuser", "-u", self.user, "--", helper, "-Qua", "--color", "never"],
            timeout=300,
            stdin_devnull=True,
        )
        if code not in (0, 1):
            return []

        items = []
        for line in out.splitlines():
            match = re.match(r"^(\S+)\s+(\S+)\s+->\s+(\S+)$", line.strip())
            if not match:
                continue
            name, old, new = match.groups()
            vcs = bool(
                re.search(r"-(git|svn|hg|bzr|cvs|nightly)$", name)
            ) or "latest-commit" in new
            if name == CTLCENTER_PKG and vcs and self._check_ctlcenter()[0] is False:
                # The helper can't tell a -git build is current; the
                # Control Center check compares its commit with GitHub.
                continue
            items.append({"name": name, "old": old, "new": new, "vcs": vcs})
        return items

    def _list_aur(self):
        """Every installed package that no configured repo provides: AUR
        builds, and anything installed by hand from a file."""
        code, out, _ = _run(["pacman", "-Qm"], timeout=60)
        if code not in (0, 1):
            return []
        items = []
        for line in out.splitlines():
            parts = line.split()
            if len(parts) == 2:
                items.append({"name": parts[0], "version": parts[1]})
        return items

    def _check_security(self):
        if not shutil.which("arch-audit"):
            return []

        found = []
        code, out, _ = _run(["arch-audit", "-u", "-f", "%n|%s"], timeout=120)
        if code in (0, 1):
            for line in out.splitlines():
                if "|" in line:
                    name, severity = line.split("|", 1)
                    found.append({"name": name.strip(), "severity": severity.strip()})
        if found:
            return found

        # Either there's genuinely nothing, or this arch-audit doesn't support
        # that format string. Re-run without -f and parse the prose; a silent
        # empty list here would disable the one rule that can't be toggled off.
        code, out, _ = _run(["arch-audit", "-u"], timeout=120)
        if code not in (0, 1):
            decky.logger.warning("arch-audit failed (exit %s)", code)
            return []
        for line in out.splitlines():
            match = re.search(r"Package\s+(\S+?)\s+is affected by", line)
            if not match:
                continue
            severity = "Unknown"
            risk = re.search(r"\b(Critical|High|Medium|Low)\b\s+risk", line, re.I)
            if risk:
                severity = risk.group(1).capitalize()
            found.append({"name": match.group(1), "severity": severity})
        return found

    def _last_upgrade_ts(self):
        path = Path("/var/log/pacman.log")
        if not path.exists():
            return None
        try:
            with path.open("rb") as handle:
                handle.seek(0, os.SEEK_END)
                size = handle.tell()
                handle.seek(max(0, size - 400_000))
                tail = handle.read().decode("utf-8", errors="ignore")
        except Exception:  # noqa: BLE001
            return None
        stamp = None
        for line in tail.splitlines():
            if "starting full system upgrade" in line:
                match = re.match(r"^\[([^\]]+)\]", line)
                if match:
                    stamp = match.group(1)
        if not stamp:
            return None
        try:
            cleaned = stamp.replace("Z", "+00:00")
            from datetime import datetime
            return datetime.fromisoformat(cleaned).timestamp()
        except Exception:  # noqa: BLE001
            return None

    def _classify(self, packages, security, services=None, dkms=None, news=None,
                  aur=None):
        watchlist = [
            p.strip() for p in str(self.settings["watchlist"]).split(",") if p.strip()
        ]
        security_names = {item["name"] for item in security}
        reasons = []
        important = []

        for pkg in packages:
            flags = []
            name = pkg["name"]

            if any(fnmatch.fnmatch(name, pattern) for pattern in watchlist):
                flags.append("watchlist")

            depth = 2 if name.startswith("linux") else 1
            if _is_major_bump(pkg["old"], pkg["new"], depth):
                flags.append("major")

            if name in security_names:
                flags.append("security")

            pkg["flags"] = flags
            if flags:
                important.append(pkg)

        def _has(flag):
            return [p["name"] for p in important if flag in p["flags"]]

        if security:
            names = sorted({item["name"] for item in security})
            reasons.append({
                "kind": "security",
                "text": "Security fix ready for " + ", ".join(names[:4])
                        + (f" +{len(names) - 4} more" if len(names) > 4 else ""),
            })

        if self.settings["notify_watchlist"]:
            names = _has("watchlist")
            if names:
                reasons.append({
                    "kind": "watchlist",
                    "text": "Update ready for " + ", ".join(names[:4])
                            + (f" +{len(names) - 4} more" if len(names) > 4 else ""),
                })

        if self.settings["notify_major"]:
            names = _has("major")
            if names:
                reasons.append({
                    "kind": "major",
                    "text": "New major version of " + ", ".join(names[:4])
                            + (f" +{len(names) - 4} more" if len(names) > 4 else ""),
                })

        if self.settings["notify_volume"]:
            threshold = int(self.settings["volume_threshold"])
            if len(packages) >= threshold:
                reasons.append({
                    "kind": "volume",
                    "text": f"{len(packages)} updates waiting — a bigger batch than usual",
                })

        if self.settings.get("notify_aur", True) and aur:
            wanted = aur if self.settings.get("notify_aur_devel", True) else [
                a for a in aur if not a["vcs"]
            ]
            if wanted:
                names = ", ".join(a["name"] for a in wanted[:3])
                reasons.append({
                    "kind": "aur",
                    "text": f"AUR update ready for {names}",
                })

        if self.settings.get("notify_news", True) and news:
            unread = [n for n in news if not n["seen"]]
            blockers = [n for n in unread if n["intervention"]]
            if blockers:
                reasons.insert(0, {
                    "kind": "news",
                    "text": "This update needs a manual step: " + blockers[0]["title"],
                })
            elif unread:
                reasons.append({
                    "kind": "news",
                    "text": f"{len(unread)} thing(s) worth reading before you update",
                })

        if self.settings.get("notify_dkms", True) and dkms:
            reasons.append({
                "kind": "dkms",
                "text": "A driver didn't rebuild — sensors or fan control may be affected",
            })

        if self.settings.get("notify_services", True) and services:
            reasons.append({
                "kind": "services",
                "text": f"{len(services)} things are still running an old version",
            })

        stale_since = None
        if self.settings["notify_stale"] and packages:
            last = self._last_upgrade_ts()
            if last:
                days = (time.time() - last) / 86400
                stale_since = round(days, 1)
                if days >= float(self.settings["stale_days"]):
                    reasons.append({
                        "kind": "stale",
                        "text": f"You haven't updated in {int(days)} days",
                    })

        return important, reasons, stale_since

    def _should_announce(self, packages, reasons, aur=None):
        """Dedupe so a pending kernel update doesn't re-toast every poll."""
        if not reasons:
            return False, None
        announced = self._load_json(self._announced_file, {})
        now = time.time()
        cooldown = float(self.settings["cooldown_hours"]) * 3600

        fresh = []
        for pkg in packages:
            key = f"{pkg['name']}@{pkg['new']}"
            seen = announced.get(key)
            if seen is None or (now - seen) > cooldown:
                fresh.append(pkg["name"])
                announced[key] = now

        # Development packages report a constant "latest-commit", so key them on
        # the version you have installed - that changes when you update, which
        # is exactly when it's worth mentioning again.
        for item in aur or []:
            target = item["old"] if item["vcs"] else item["new"]
            key = f"aur:{item['name']}@{target}"
            seen = announced.get(key)
            if seen is None or (now - seen) > cooldown:
                fresh.append(item["name"])
                announced[key] = now

        standalone = ("volume", "stale", "services", "dkms", "news")
        volume_only = all(r["kind"] in standalone for r in reasons)
        if volume_only:
            key = f"__{reasons[0]['kind']}__"
            seen = announced.get(key)
            if seen is not None and (now - seen) <= cooldown:
                return False, None
            announced[key] = now
            fresh = fresh or ["batch"]

        # Prune anything older than 30 days so the file can't grow forever.
        announced = {k: v for k, v in announced.items() if (now - v) < 30 * 86400}
        self._save_json(self._announced_file, announced)
        return bool(fresh), fresh

    async def check_now(self, announce: bool = False):
        await self.check_plugins(announce=announce)
        packages, error = await asyncio.to_thread(self._check_pacman)
        if error:
            self.state = {
                "checked_at": time.time(),
                "error": error,
                "count": 0,
                "packages": [],
                "important": [],
                "reasons": [],
                "flatpak": [],
                "security": [],
                "services": [],
                "dkms": [],
                "news": [],
                "aur": [],
                "aur_installed": [],
                "blocking_news": False,
                "stale_days_since": None,
            }
            await decky.emit("cachy_updates/state", self.state)
            return self.state

        security = await asyncio.to_thread(self._check_security)
        services = []
        if self.settings.get("notify_services", True):
            services = await asyncio.to_thread(self._check_services)
        dkms = []
        if self.settings.get("notify_dkms", True):
            dkms = await asyncio.to_thread(self._check_dkms)
        news = []
        if self.settings.get("notify_news", True):
            news = await asyncio.to_thread(self._check_news)
        aur = []
        aur_installed = []
        if self.settings.get("include_aur", True):
            aur = await asyncio.to_thread(self._check_aur)
            aur_installed = await asyncio.to_thread(self._list_aur)
        flatpak = []
        if self.settings["include_flatpak"]:
            flatpak = await asyncio.to_thread(self._check_flatpak)

        important, reasons, stale_since = self._classify(
            packages, security, services, dkms, news, aur
        )
        blocking = bool(
            self.settings.get("block_on_intervention", True)
            and [n for n in news if n["intervention"] and not n["seen"]]
        )

        self.state = {
            "checked_at": time.time(),
            "error": None,
            "count": len(packages),
            "packages": packages,
            "important": important,
            "reasons": reasons,
            "flatpak": flatpak,
            "security": security,
            "services": services,
            "dkms": dkms,
            "news": news,
            "aur": aur,
            "aur_installed": aur_installed,
            "blocking_news": blocking,
            "stale_days_since": stale_since,
        }
        await decky.emit("cachy_updates/state", self.state)

        if announce:
            should, _ = self._should_announce(important or packages, reasons, aur)
            if should:
                headline = reasons[0]["text"]
                extra = f" ({len(packages)} updates total)" if packages else ""
                await decky.emit("cachy_updates/notify", {
                    "title": "Updates ready",
                    "body": headline + extra,
                })
        return self.state

    async def get_state(self):
        return {
            **self.state,
            "last_run": self.last_run,
            "plugin_updates": self.plugin_updates,
            "plugin_error": self.plugin_error,
            "tool_update": self.tool_update,
            "components": self.components,
            "components_running": self.components_running,
            "decky_restart_pending": self.decky_restart_pending,
        }

    # ---------- own plugins ----------

    def _fetch(self, url, dest=None, timeout=60):
        args = ["curl", "-fsSL", "--max-time", str(timeout), "-H", "Cache-Control: no-cache"]
        if dest:
            args += ["-o", str(dest)]
        code, out, err = _run(args + [url], timeout=timeout + 10, stdin_devnull=True)
        if code != 0:
            raise RuntimeError(err.strip() or f"curl exit {code}")
        return out

    def _latest_sha(self):
        """Pin to the newest commit: raw.githubusercontent serves a branch from
        a cache for minutes, a commit never goes stale."""
        try:
            out = self._fetch(
                f"https://api.github.com/repos/{PLUGIN_REPO}/commits/{PLUGIN_BRANCH}",
                timeout=20,
            )
            sha = json.loads(out).get("sha", "")
            if re.fullmatch(r"[0-9a-f]{40}", sha):
                return sha
        except (RuntimeError, ValueError, AttributeError):
            pass
        return PLUGIN_BRANCH

    def _raw(self, sha, path):
        return f"https://raw.githubusercontent.com/{PLUGIN_REPO}/{sha}/{path}"

    def _installed_version(self, folder):
        try:
            with open(self.plugins_root / folder / "package.json") as f:
                return json.load(f).get("version")
        except (OSError, ValueError):
            return None

    def _check_plugins(self):
        sha = self._latest_sha()
        manifest = json.loads(self._fetch(self._raw(sha, PLUGIN_MANIFEST), timeout=30))
        updates = []
        for entry in manifest.get("plugins", []):
            folder = entry.get("dir")
            latest = entry.get("version")
            if not folder or not latest or "/" in folder or folder.startswith("."):
                continue
            installed = self._installed_version(folder)
            if installed is None:
                continue  # not installed here, nothing to update
            packages = _package_list(entry.get("packages"))
            newer = _version_key(latest) > _version_key(installed)
            # A plugin brought up to date some other way (or by an older copy
            # of this plugin) can still be missing a package it now needs.
            missing = [] if newer else _missing_packages(packages)
            if newer or missing:
                updates.append({
                    "dir": folder,
                    "name": entry.get("name") or folder,
                    "installed": installed,
                    "latest": latest,
                    "zip": entry.get("zip"),
                    "packages": packages,
                    "packages_only": not newer,
                    "missing": missing,
                })
        return sha, updates

    def _check_tool(self, sha):
        """Is the setup tool on disk behind the repo? Compared by git blob id,
        so nothing is downloaded until there is something to install."""
        try:
            path = Path(TOOL_PATH_FILE.read_text().strip())
            data = path.read_bytes()
        except OSError:
            return None
        if _in_git_checkout(path):
            # A checkout updates with git pull; the tool's own `u` does that.
            return None
        tree = json.loads(self._fetch(
            f"https://api.github.com/repos/{PLUGIN_REPO}/git/trees/{sha}", timeout=20,
        ))
        remote = next((e.get("sha") for e in tree.get("tree", []) if e.get("path") == TOOL_FILE), None)
        if not remote or remote == _git_blob_sha(data):
            return None
        return {"path": str(path), "blob": remote}

    async def check_plugins(self, announce: bool = False):
        try:
            sha, updates = await asyncio.to_thread(self._check_plugins)
            self.plugin_sha, self.plugin_updates, self.plugin_error = sha, updates, None
        except Exception as exc:  # noqa: BLE001
            self.plugin_error = f"Could not check your plugins: {exc}"
            decky.logger.warning(self.plugin_error)
            return await self.get_state()

        tool = None
        if re.fullmatch(r"[0-9a-f]{40}", sha or ""):
            try:
                tool = await asyncio.to_thread(self._check_tool, sha)
            except Exception as exc:  # noqa: BLE001
                decky.logger.warning("setup tool check failed: %s", exc)
        self.tool_update = tool
        try:
            self.components = await asyncio.to_thread(self._check_components, tool)
        except Exception as exc:  # noqa: BLE001
            decky.logger.warning("setup tool component check failed: %s", exc)
        if announce:
            await self._announce_components()
        if announce and tool:
            announced = self._load_json(self._announced_file, {})
            key = f"tool:{tool['blob']}"
            if key not in announced:
                announced[key] = time.time()
                self._save_json(self._announced_file, announced)
                await decky.emit("cachy_updates/notify", {
                    "title": "Setup tool update",
                    "body": "A new version of bc250-setup is out. Open System Updates to install.",
                })

        if announce and updates:
            announced = self._load_json(self._announced_file, {})
            fresh = [u for u in updates if f"plugin:{u['dir']}:{u['latest']}" not in announced]
            if fresh:
                now = time.time()
                for u in fresh:
                    announced[f"plugin:{u['dir']}:{u['latest']}"] = now
                self._save_json(self._announced_file, announced)
                names = ", ".join(u["name"] for u in fresh)
                await decky.emit("cachy_updates/notify", {
                    "title": "Plugin update",
                    "body": f"New version of {names}. Open System Updates to install.",
                })
        return await self.get_state()

    def _install_plugin_zip(self, sha, item):
        zip_path = item.get("zip") or ""
        if not re.fullmatch(r"plugins/[A-Za-z0-9._ -]+\.zip", zip_path):
            raise RuntimeError(f"bad zip path for {item['name']}")
        work = Path(tempfile.mkdtemp(prefix="plugin-update-"))
        try:
            archive = work / "plugin.zip"
            self._fetch(self._raw(sha, zip_path.replace(" ", "%20")), dest=archive, timeout=120)
            unpacked = work / "unpacked"
            with zipfile.ZipFile(archive) as zf:
                for name in zf.namelist():
                    if name.startswith("/") or ".." in Path(name).parts:
                        raise RuntimeError(f"unsafe path in {zip_path}: {name}")
                zf.extractall(unpacked)
            source = unpacked / item["dir"]
            if not (source / "plugin.json").is_file():
                raise RuntimeError(f"{zip_path} has no {item['dir']}/plugin.json")

            # Staged next to the plugins folder, not inside it: Decky watches
            # that folder and would load a half-copied plugin it found there.
            # Same filesystem, so the swap below is two renames.
            stage = self.plugins_root.parent / ".plugin-staging"
            stage.mkdir(exist_ok=True)
            target = self.plugins_root / item["dir"]
            old = stage / f"{item['dir']}.old"
            shutil.rmtree(old, ignore_errors=True)
            staged = stage / f"{item['dir']}.new"
            shutil.rmtree(staged, ignore_errors=True)
            shutil.copytree(source, staged, symlinks=True)
            for root, dirs, files in os.walk(staged):
                for n in dirs + files:
                    os.lchown(os.path.join(root, n), 0, 0)
            os.lchown(staged, 0, 0)
            if target.exists():
                os.rename(target, old)
            os.rename(staged, target)
            shutil.rmtree(old, ignore_errors=True)
        finally:
            shutil.rmtree(work, ignore_errors=True)

    # ---------- what the setup tool installed ----------

    def _remote_head(self, url):
        code, out, _ = _run(["git", "ls-remote", url, "HEAD"], timeout=60, stdin_devnull=True)
        sha = out.split()[0] if code == 0 and out.split() else ""
        return sha if re.fullmatch(r"[0-9a-f]{40}", sha) else None

    def _check_led(self):
        if not (LED_SRC / ".git").is_dir():
            return None, "Not a git checkout, so it can't be checked"
        git = ["git", "-c", f"safe.directory={LED_SRC}", "-C", str(LED_SRC)]
        code, local, _ = _run(git + ["rev-parse", "HEAD"], timeout=30)
        code2, url, _ = _run(git + ["remote", "get-url", "origin"], timeout=30)
        remote = self._remote_head(url.strip()) if code2 == 0 else None
        if code != 0 or not remote:
            return None, "Couldn't reach its repo to check"
        firmware = self._led_firmware_due()
        if local.strip() != remote:
            return remote, "Update available" + (" (with new receiver firmware)" if firmware else "")
        if firmware:
            # Keyed by the release, so the notification goes out once per release.
            return f"firmware:{firmware}", f"New receiver firmware {firmware}"
        return False, "Up to date"

    def _led_firmware_due(self):
        """The newest receiver firmware release if it isn't what was last
        flashed, else None. A receiver that switches the PSU is never flashed
        unattended, so it never counts as due."""
        try:
            cfg = json.loads(LED_CONFIG.read_text())
            if (cfg.get("power_switch") or {}).get("enabled"):
                return None
        except (OSError, ValueError):
            pass
        try:
            release = json.loads(self._fetch(
                f"https://api.github.com/repos/{LED_FW_REPO}/releases/latest", timeout=20,
            ))
        except Exception:  # noqa: BLE001
            return None
        tag = release.get("tag_name") if isinstance(release, dict) else None
        if not tag:
            return None
        try:
            flashed = LED_FW_STATE.read_text().strip()
        except OSError:
            flashed = ""
        return None if flashed == tag else tag

    def _check_ctlcenter(self):
        code, out, _ = _run(["pacman", "-Q", CTLCENTER_PKG], timeout=30)
        if code != 0:
            return None, "Not installed as a package"
        version = out.split()[-1]
        # VCS packages put the commit in their version: r123.abc1234 or
        # 1.0.r5.gabc1234.
        m = re.search(r"(?:r\d+\.g?|[.+_]g)([0-9a-f]{7,40})(?:-\d+)?$", version)
        remote = self._remote_head(CTLCENTER_UPSTREAM)
        if not m or not remote:
            return None, "Couldn't check for updates"
        if remote.startswith(m.group(1)):
            return False, "Up to date"
        return remote, "Update available"

    def _check_components(self, tool):
        found = []
        for key, name in TOOL_COMPONENTS:
            if not (TOOL_STATE_DIR / key).exists():
                continue
            item = {"id": key, "name": name, "update": False, "remote": None}
            if key == "led":
                remote, note = self._check_led()
            elif key == "ctlcenter":
                remote, note = self._check_ctlcenter()
            else:
                remote = None
                note = "Updates with the setup tool" if tool else "Up to date"
                item["update"] = bool(tool)
            if remote:
                item["update"], item["remote"] = True, remote
            item["note"] = note
            found.append(item)
        return found

    async def _announce_components(self):
        fresh = []
        announced = self._load_json(self._announced_file, {})
        for c in self.components:
            if c.get("remote"):
                key = f"component:{c['id']}:{c['remote']}"
                if key not in announced:
                    announced[key] = time.time()
                    fresh.append(c["name"])
        if fresh:
            self._save_json(self._announced_file, announced)
            await decky.emit("cachy_updates/notify", {
                "title": "Setup tool update",
                "body": f"Update for {', '.join(fresh)}. Open System Updates to install.",
            })

    def _tool_path(self):
        try:
            path = TOOL_PATH_FILE.read_text().strip()
        except OSError:
            return None
        return path if path and Path(path).is_file() else None

    def _run_tool(self, path, flag):
        code, out, err = _run(
            ["env", f"SUDO_USER={self.user}", "NO_COLOR=1", "sh", path, flag],
            timeout=1800, stdin_devnull=True,
        )
        log = (out + err).strip()
        decky.logger.info("setup tool %s exited %s:\n%s", flag, code, log[-4000:])
        return code, log

    async def update_components(self):
        """Bring everything the setup tool installed up to date, with what it
        depends on: the script and what it wrote, the LED daemon, and the
        Control Center (built from the AUR, its dependencies from the repos)."""
        if self.components_running:
            return {"ok": False, "message": "Already updating."}
        reason = await self._busy_reason()
        if reason:
            return {"ok": False, "message": reason}
        # Always re-check first: a check made before the latest push would
        # otherwise install the commit it found then.
        await self.check_plugins()
        self.components_running = True
        done, failed = [], []
        try:
            if self.tool_update:
                try:
                    await asyncio.to_thread(self._install_tool, self.plugin_sha, self.tool_update)
                    self.tool_update = None
                except Exception as exc:  # noqa: BLE001
                    return {"ok": False, "message": f"Could not update the setup tool: {exc}"}
                code, log = await asyncio.to_thread(self._run_tool, self._tool_path(), "--refresh")
                if code == 0:
                    done.append("Setup tool")
                    try:
                        TOOL_REFRESH_FLAG.unlink()
                    except OSError:
                        pass
                else:
                    failed.append("Setup tool")
            path = self._tool_path()
            for c in self.components:
                flag = {"led": "--update-led", "ctlcenter": "--update-ctlcenter"}.get(c["id"])
                if not flag or not c.get("remote"):
                    continue
                if not path:
                    failed.append(c["name"])
                    continue
                code, log = await asyncio.to_thread(self._run_tool, path, flag)
                (done if code == 0 else failed).append(c["name"])
        finally:
            self.components_running = False
            try:
                self.components = await asyncio.to_thread(self._check_components, self.tool_update)
            except Exception:  # noqa: BLE001
                pass
        if failed:
            return {"ok": False, "message": f"Updated {', '.join(done) or 'nothing'}; "
                    f"{', '.join(failed)} failed. Run the setup tool to see why."}
        return {"ok": True, "message": f"Updated {', '.join(done) or 'everything'}."}

    def _install_tool(self, sha, item):
        target = Path(item["path"])
        # Same directory, so the swap is a rename and a crash leaves either the
        # old file or the new one, never half of each.
        fd, tmp = tempfile.mkstemp(prefix=".bc250-setup.", dir=str(target.parent))
        os.close(fd)
        tmp = Path(tmp)
        try:
            self._fetch(self._raw(sha, TOOL_FILE), dest=tmp, timeout=120)
            data = tmp.read_bytes()
            if _git_blob_sha(data) != item["blob"]:
                raise RuntimeError("download does not match the repo copy")
            if b"BC-250 setup" not in data:
                raise RuntimeError("download doesn't look like the setup tool")
            code, _, err = _run(["sh", "-n", str(tmp)], timeout=30)
            if code != 0:
                raise RuntimeError(f"download is not valid shell: {err.strip()}")
            st = target.stat()
            os.chown(tmp, st.st_uid, st.st_gid)
            os.chmod(tmp, st.st_mode & 0o7777)
            shutil.copy2(target, target.with_name(target.name + ".bak"))
            os.rename(tmp, target)
        finally:
            if tmp.exists():
                tmp.unlink()
        # Same as the tool's own update: helpers it wrote to disk are re-applied
        # the next time it runs.
        try:
            TOOL_REFRESH_FLAG.touch()
        except OSError:
            pass

    def _refresh_tool(self, path):
        """Have the new script re-write the helpers, units and packages of
        whatever it installed, exactly like its menu does after an update."""
        code, out, err = _run(
            ["env", f"SUDO_USER={self.user}", "NO_COLOR=1", "sh", path, "--refresh"],
            timeout=900, stdin_devnull=True,
        )
        log = (out + err).strip()
        decky.logger.info("setup tool refresh exited %s:\n%s", code, log[-4000:])
        return code, log

    async def update_tool(self):
        await self.check_plugins()
        if not self.tool_update:
            return {"ok": True, "message": "The setup tool is already up to date."}
        reason = await self._busy_reason()
        if reason:
            return {"ok": False, "message": reason}
        try:
            await asyncio.to_thread(self._install_tool, self.plugin_sha, self.tool_update)
        except Exception as exc:  # noqa: BLE001
            decky.logger.error("setup tool update failed: %s", exc)
            return {"ok": False, "message": str(exc)}
        path = self.tool_update["path"]
        self.tool_update = None
        code, log = await asyncio.to_thread(self._refresh_tool, path)
        if code != 0:
            last = log.splitlines()[-1] if log else f"exit {code}"
            return {
                "ok": False,
                "message": f"Updated, but re-applying its changes failed ({last}). Run the tool once to finish.",
            }
        # The script clears its own flag after a refresh; make sure the menu
        # doesn't ask again for what was just done.
        try:
            TOOL_REFRESH_FLAG.unlink()
        except OSError:
            pass
        return {"ok": True, "message": "Updated and applied. Nothing else to do."}

    async def update_plugins(self):
        await self.check_plugins()
        reason = await self._busy_reason()
        if reason:
            return {"ok": False, "updated": [], "failed": [{"name": "Plugins", "error": reason}]}
        items = list(self.plugin_updates)
        if not items:
            return {"ok": True, "updated": [], "failed": []}
        # This plugin replaces itself last, so the others are done if that goes
        # wrong.
        items.sort(key=lambda u: u["dir"] == Path(os.environ.get("DECKY_PLUGIN_DIR", "")).name)
        updated, failed = [], []
        for item in items:
            try:
                if not item.get("packages_only"):
                    await asyncio.to_thread(self._install_plugin_zip, self.plugin_sha, item)
                packages = item.get("packages") or []
                if packages:
                    # What the setup tool installs alongside the plugin.
                    code, out, err = await asyncio.to_thread(
                        _run, ["pacman", "-S", "--needed", "--noconfirm", *packages], 900, True,
                    )
                    if code != 0:
                        detail = (err or out).strip().splitlines()
                        raise RuntimeError(
                            "plugin files updated, but installing %s failed: %s"
                            % (" ".join(packages), detail[-1] if detail else f"exit {code}")
                        )
                updated.append(item["name"])
            except Exception as exc:  # noqa: BLE001
                decky.logger.error("plugin update %s failed: %s", item["dir"], exc)
                failed.append({"name": item["name"], "error": str(exc)})
        # New files are in place but Decky keeps running the old ones until
        # it restarts. That is left to you (restart_decky), so it never cuts
        # into a system update that is still going.
        new_files = {i["name"] for i in items if not i.get("packages_only")}
        for name in updated:
            if name in new_files and name not in self.decky_restart_pending:
                self.decky_restart_pending.append(name)
        self.plugin_updates = [u for u in self.plugin_updates if u["name"] not in updated]
        return {"ok": not failed, "updated": updated, "failed": failed}

    # ---------- setup tool options (Tools tab) ----------

    @property
    def _setup_log(self):
        return self.runtime_dir / "setup-job.log"

    @property
    def _setup_meta(self):
        return self.runtime_dir / "setup-job.json"

    def _setup_active(self):
        _, out, _ = _run(["systemctl", "is-active", SETUP_UNIT], 30)
        return out.strip() in ("activating", "active", "reloading")

    async def setup_options(self):
        """Each option with whether it is installed, plus the last job."""
        return {
            "available": bool(self._tool_path()),
            "options": [
                {"id": key, "name": name, "installed": (TOOL_STATE_DIR / key).exists()}
                for key, name in SETUP_OPTIONS
            ],
            "job": await self.setup_job(),
        }

    async def setup_job(self, lines: int = 40):
        meta = self._load_json(self._setup_meta, None)
        running = await asyncio.to_thread(self._setup_active)
        log = ""
        try:
            text = self._setup_log.read_text(errors="ignore")
            log = "\n".join(text.splitlines()[-lines:])
        except OSError:
            pass
        rc = None
        if meta and not running:
            try:
                rc = int((self.runtime_dir / "setup-job.rc").read_text().strip())
            except (OSError, ValueError):
                rc = None
        # A plugin installed or removed from Tools loads after Decky restarts.
        if meta and rc == 0 and meta.get("action", "").startswith("plugin-") and not meta.get("noted"):
            label = meta.get("name") or meta.get("option")
            if label and label not in self.decky_restart_pending:
                self.decky_restart_pending.append(label)
            meta["noted"] = True
            self._save_json(self._setup_meta, meta)
        return {"running": running, "meta": meta, "rc": rc, "log": log}

    async def decky_plugins(self):
        """Every Decky plugin the setup tool offers, with its state."""
        path = self._tool_path()
        if not path:
            return {"ok": False, "plugins": [], "message": "The setup tool hasn't been run on this box yet."}
        code, log = await asyncio.to_thread(self._run_tool, path, "--plugins")
        plugins = []
        for line in log.splitlines():
            parts = line.split("\t")
            if len(parts) >= 7 and parts[0] == "PLUGIN":
                _, pid, name, state, have, offered, source = parts[:7]
                plugins.append({
                    "id": pid, "name": name, "state": state,
                    "installed": have, "offered": offered, "source": source,
                })
        self._plugin_names = {p["id"]: p["name"] for p in plugins}
        if code != 0 and not plugins:
            return {"ok": False, "plugins": [], "message": "Couldn't list the plugins."}
        return {"ok": True, "plugins": plugins, "message": ""}

    async def setup_run(self, action: str, option: str = ""):
        """Run one setup tool option in the background, as the menu would."""
        ids = {key for key, _ in SETUP_OPTIONS}
        if action not in SETUP_ACTIONS:
            return {"ok": False, "message": "Unknown action."}
        if action in ("install", "remove") and option not in ids:
            return {"ok": False, "message": "Unknown option."}
        if action.startswith("plugin-"):
            if not re.match(r"^[A-Za-z0-9 ._/-]+$", option or ""):
                return {"ok": False, "message": "Unknown plugin."}
            if action == "plugin-remove" and option == "system-updates":
                return {"ok": False, "message": "System Updates can't remove itself."}
        path = self._tool_path()
        if not path:
            return {"ok": False, "message": "The setup tool hasn't been run on this box yet."}
        if self.components_running:
            return {"ok": False, "message": "The setup tool is updating. Try again after."}
        reason = await self._busy_reason()
        if reason:
            return {"ok": False, "message": reason}
        rc_file = self.runtime_dir / "setup-job.rc"
        for f in (self._setup_log, rc_file):
            f.unlink(missing_ok=True)
        name = dict(SETUP_OPTIONS).get(option, "") or self._plugin_names.get(option, option)
        self._save_json(self._setup_meta, {
            "action": action, "option": option, "name": name, "started": time.time(),
        })
        flag = f"--{action}"
        await asyncio.to_thread(_run, ["systemctl", "reset-failed", SETUP_UNIT], 30)
        code, out, err = await asyncio.to_thread(_run, [
            "systemd-run", f"--unit={SETUP_UNIT}", "--collect", "--no-block",
            "--property=Type=oneshot",
            "--property=TimeoutStartSec=infinity",
            "/bin/sh", "-c",
            'env SUDO_USER="$1" NO_COLOR=1 sh "$2" "$3" ${6:+"$6"} </dev/null >"$4" 2>&1; echo $? >"$5"',
            "sh", self.user, path, flag, str(self._setup_log), str(rc_file), option,
        ], 60)
        if code != 0:
            return {"ok": False, "message": (err or out or f"systemd-run exited {code}").strip()}
        return {"ok": True, "message": "Started."}

    async def _busy_reason(self):
        """Why touching Decky or plugins now would be a bad idea, or None."""
        if await asyncio.to_thread(self._setup_active):
            return "The setup tool is still working. Let it finish first."
        if (await self.update_status())["running"]:
            return "A system update is running. Let it finish first."
        if (await self.lock_state())["live"]:
            return "Another update is running. Let it finish first."
        return None

    async def restart_decky(self):
        # A second press while the first restart is still pending restarted
        # Decky twice in a row (seen 2026-10-08), and Steam's screen came back
        # from that without D-pad or stick navigation until Steam restarted.
        if time.monotonic() - getattr(self, "_decky_restart_at", -1e9) < 60:
            return {"ok": True, "message": "Decky is already restarting."}
        reason = await self._busy_reason()
        if reason:
            return {"ok": False, "message": reason}
        # Scheduled through systemd so it outlives this backend, which the
        # restart stops; a few seconds lets this answer reach the panel first.
        code, _, err = await asyncio.to_thread(
            _run,
            ["systemd-run", "--on-active=3", "--collect",
             "systemctl", "restart", "plugin_loader"],
            30,
        )
        if code != 0:
            decky.logger.error("could not schedule Decky restart: %s", err)
            return {"ok": False, "message": "Could not restart Decky. Reboot to finish."}
        self._decky_restart_at = time.monotonic()
        self.decky_restart_pending = []
        return {"ok": True, "message": "Decky is restarting."}

    # ---------- applying ----------

    def _write_script(self):
        keyrings = []
        for pkg in ("archlinux-keyring", "cachyos-keyring"):
            code, _, _ = _run(["pacman", "-Si", pkg], timeout=60)
            if code == 0:
                keyrings.append(pkg)

        # Some PKGBUILDs pass $pkgdir unquoted (input-remapper-git's
        # "--root $pkgdir"), so the build path must not contain a space, and
        # this plugin's own data folder ("System Updates") does.
        try:
            home = Path(pwd.getpwnam(self.user).pw_dir)
        except KeyError:
            home = Path("/home") / self.user
        build_dir = home / ".cache" / "cachy-updates" / "build"
        old_build_dir = self.runtime_dir / "build"
        user = self.user
        script = f"""#!/bin/bash
LOG="{self._log_file}"
RESULT="{self._result_file}"
CANCEL="{self._cancel_file}"
PACKAGES_DONE=0
exec > >(tee -a "$LOG") 2>&1

finish() {{
  rc=$?
  cancelled=0
  [ -e "$CANCEL" ] && cancelled=1
  printf '{{"rc":%d,"cancelled":%d,"packages_done":%d,"finished":%d}}\\n' \\
    "$rc" "$cancelled" "$PACKAGES_DONE" "$(date +%s)" > "$RESULT"
}}
trap finish EXIT

# A stop request (systemctl stop, shutdown) must never take a running pacman
# down with this script: bash runs these traps only once the current command
# has exited, so note the request and stop before the next step instead.
trap 'touch "$CANCEL"' TERM INT HUP

stop_if_cancelled() {{
  if [ -e "$CANCEL" ]; then
    echo "=== stopped on request $(date -Is) ==="
    exit 130
  fi
}}

echo "=== update started $(date -Is) ==="

if [ -n "{' '.join(keyrings)}" ]; then
  echo "--- refreshing keyrings ---"
  pacman -Sy --needed --noconfirm {' '.join(keyrings)} || echo "keyring refresh failed, continuing"
fi
stop_if_cancelled

echo "--- pacman -Syu ---"
pacman -Syu --noconfirm --disable-download-timeout
rc=$?
[ "$rc" -eq 0 ] && PACKAGES_DONE=1
stop_if_cancelled
if [ "$rc" -ne 0 ]; then
  echo "!!! pacman failed with exit code $rc — stopping here."
  echo "!!! Finish this one in Desktop Mode; do not re-run blindly."
  exit "$rc"
fi

if [ "$DO_FLATPAK" = "1" ] && command -v flatpak >/dev/null; then
  echo "--- flatpak (system) ---"
  flatpak update -y --noninteractive || echo "system flatpak update failed"
  stop_if_cancelled
  echo "--- flatpak (user) ---"
  uid="$(id -u "{self.user}" 2>/dev/null)"
  if [ -n "$uid" ]; then
    runuser -u "{self.user}" -- env "XDG_RUNTIME_DIR=/run/user/$uid" \\
      flatpak update -y --noninteractive --user \\
      || echo "user flatpak update failed"
  fi
fi
stop_if_cancelled

if [ "$DO_AUR" = "1" ] && [ -n "$AUR_PKGS" ]; then
  echo "--- AUR ---"
  BUILD="{build_dir}"
  rm -rf "{old_build_dir}"
  runuser -u "{user}" -- mkdir -p "$BUILD"
  AUR_FAILED=0
  for pkg in $AUR_PKGS; do
    stop_if_cancelled
    echo "--- AUR: $pkg ---"
    DIR="$BUILD/$pkg"
    if [ -d "$DIR/.git" ]; then
      runuser -u "{user}" -- git -C "$DIR" fetch --depth 1 origin master \\
        && runuser -u "{user}" -- git -C "$DIR" reset --hard origin/master \\
        || {{ echo "fetch failed for $pkg"; AUR_FAILED=1; continue; }}
    else
      rm -rf "$DIR"
      runuser -u "{user}" -- git clone --depth 1 \\
        "https://aur.archlinux.org/$pkg.git" "$DIR" \\
        || {{ echo "clone failed for $pkg"; AUR_FAILED=1; continue; }}
    fi

    # Install build+runtime deps as root first, so makepkg never needs sudo.
    DEPS=$(runuser -u "{user}" -- bash -c "cd '$DIR' && makepkg --printsrcinfo" \\
      | awk -F' = ' '/^\\t(make)?depends/ {{print $2}}' \\
      | sed 's/[<>=].*//' | sort -u | tr '\\n' ' ')
    if [ -n "$DEPS" ]; then
      echo "deps: $DEPS"
      pacman -S --needed --asdeps --noconfirm $DEPS || echo "some deps unavailable"
    fi

    rm -f "$DIR"/*.pkg.tar.*
    # --nodeps: deps are already handled above, as root.
    if ! runuser -u "{user}" -- bash -c \\
      "cd '$DIR' && makepkg -f --noconfirm --nodeps --noprogressbar"; then
      echo "!!! build failed for $pkg — skipping, other packages continue"
      AUR_FAILED=1
      continue
    fi

    if ! pacman -U --noconfirm "$DIR"/*.pkg.tar.*; then
      echo "!!! install failed for $pkg"
      AUR_FAILED=1
    fi
  done

  # The helper calls a -git package outdated until its own record of the
  # upstream commit matches; a makepkg build never updates that record, so
  # every check offered the same packages again. --gendb only adds packages
  # missing from the record, so drop it first and let it be rebuilt from
  # what upstream has now. Skipped after a failure, which would otherwise
  # mark the package that failed as current.
  if [ "$AUR_FAILED" = "0" ]; then
    UHOME="{home}"
    if command -v paru >/dev/null; then
      rm -f "$UHOME/.cache/paru/devel.toml" "$UHOME/.cache/paru/devel.json" \
        "$UHOME/.local/state/paru/devel.toml" "$UHOME/.local/state/paru/devel.json"
      runuser -u "{user}" -- paru --gendb || echo "could not refresh paru's devel record"
    elif command -v yay >/dev/null; then
      rm -f "$UHOME/.cache/yay/vcs.json"
      runuser -u "{user}" -- yay -Y --gendb || echo "could not refresh yay's devel record"
    fi
  else
    echo "some AUR packages failed; they stay listed so they are retried"
  fi
fi

echo "=== update finished $(date -Is) ==="
"""
        self._script_file.parent.mkdir(parents=True, exist_ok=True)
        self._script_file.write_text(script)
        self._script_file.chmod(0o755)

    async def ack_news(self):
        store = self._load_json(self._announced_file, {})
        now = time.time()
        for item in self.state.get("news", []) or []:
            store[f"news:{item['title']}"] = now
        self._save_json(self._announced_file, store)
        return await self.check_now(announce=False)

    async def lock_state(self):
        """A killed pacman can leave /var/lib/pacman/db.lck behind. Removing it
        while pacman is alive corrupts the DB, so check for a live process."""
        lock = Path("/var/lib/pacman/db.lck")
        if not lock.exists():
            return {"locked": False, "live": False, "age_min": 0}
        code, out, _ = await asyncio.to_thread(_run, ["pgrep", "-x", "pacman"], 30)
        live = code == 0 and bool(out.strip())
        try:
            age = int((time.time() - lock.stat().st_mtime) / 60)
        except OSError:
            age = 0
        return {"locked": True, "live": live, "age_min": age}

    async def clear_lock(self):
        info = await self.lock_state()
        if not info["locked"]:
            return {"ok": True, "message": "Nothing to clear."}
        if info["live"]:
            return {
                "ok": False,
                "message": "An update is still running. Let it finish.",
            }
        try:
            Path("/var/lib/pacman/db.lck").unlink()
            return {"ok": True, "message": "Cleared. Try updating again."}
        except OSError as exc:
            return {"ok": False, "message": str(exc)}

    def _preflight(self):
        """Reasons an update can't work right now, or None."""
        try:
            cmdline = Path("/proc/cmdline").read_text()
        except OSError:
            cmdline = ""
        # Limine's snapshot entries boot a read-only snapshot with changes in
        # a small RAM overlay: an update fills it, and is gone on reboot.
        if "/.snapshots/" in cmdline:
            return ("This boot is a snapshot, so an update would only go to RAM "
                    "and be lost on restart. Reboot into the normal entry first.")
        try:
            free = shutil.disk_usage("/").free
        except OSError:
            return None
        if free < MIN_FREE_BYTES:
            return (f"Only {free / 1024 ** 3:.1f} GB free on the system drive. "
                    "Free up some space first.")
        return None

    async def start_update(self):
        problem = await asyncio.to_thread(self._preflight)
        if problem:
            return {"ok": False, "error": problem}
        if self.state.get("blocking_news"):
            return {
                "ok": False,
                "error": "One update needs a manual step first. Read it, then mark it read.",
            }
        status = await self.update_status()
        if status["running"]:
            return {"ok": False, "error": "An update is already running."}
        if await asyncio.to_thread(self._setup_active):
            return {"ok": False, "error": "The setup tool is still working. Let it finish first."}
        lock = await self.lock_state()
        if lock["locked"]:
            if lock["live"]:
                return {"ok": False, "error": "Another update is already running."}
            return {
                "ok": False,
                "error": "A previous update left a lock behind. "
                         "Use Clear leftover lock in Tools.",
            }

        try:
            self._log_file.unlink(missing_ok=True)
            self._result_file.unlink(missing_ok=True)
            self._cancel_file.unlink(missing_ok=True)
        except Exception:  # noqa: BLE001
            pass

        await asyncio.to_thread(self._write_script)
        _run(["systemctl", "reset-failed", UNIT], timeout=30)

        # Only ever build what the last check actually reported.
        aur_list = " ".join(
            a["name"]
            for a in (self.state.get("aur") or [])
            if re.match(r"^[A-Za-z0-9@._+-]+$", a["name"])
        )

        args = [
            "systemd-run",
            f"--unit={UNIT}",
            "--property=Type=oneshot",
            # 'infinity' is the only value systemd treats as no limit; 0 gives
            # the unit a zero-second budget and it gets killed on the spot.
            "--property=TimeoutStartSec=infinity",
            "--property=TimeoutStopSec=infinity",
            # Never SIGKILL a running pacman - a half-written package DB is far
            # worse than a unit that outlives a cancel.
            "--property=KillMode=process",
            "--property=KillSignal=SIGTERM",
            "--no-block",
            f"--setenv=DO_FLATPAK={'1' if self.settings['include_flatpak'] else '0'}",
            f"--setenv=DO_AUR={'1' if self.settings.get('install_aur') else '0'}",
            f"--setenv=AUR_PKGS={aur_list}",
            "/bin/bash",
            str(self._script_file),
        ]
        code, out, err = await asyncio.to_thread(_run, args, 60)
        if code != 0:
            return {"ok": False, "error": (err or out or f"systemd-run exited {code}").strip()}
        return {"ok": True}

    async def update_status(self):
        code, out, _ = await asyncio.to_thread(
            _run, ["systemctl", "is-active", UNIT], 30
        )
        active = out.strip()
        running = active in ("activating", "active", "reloading")
        result = self._load_json(self._result_file, None)
        # pacman can outlive the update unit (a stop from an older version of
        # this plugin left one running), and the update is not over until it is.
        code, out, _ = await asyncio.to_thread(_run, ["pgrep", "-x", "pacman"], 30)
        return {
            "running": running,
            "active": active,
            "cancelling": running and self._cancel_file.exists(),
            "progress": self._progress() if running else None,
            "pacman_live": code == 0 and bool(out.strip()),
            "last_rc": None if result is None else result.get("rc"),
            "cancelled": bool(result and result.get("cancelled")),
            "packages_done": bool(result and result.get("packages_done")),
            "finished_at": None if result is None else result.get("finished"),
        }

    async def get_log(self, lines: int = 60):
        try:
            text = self._log_file.read_text(errors="ignore")
        except Exception:  # noqa: BLE001
            code, out, _ = await asyncio.to_thread(
                _run, ["journalctl", "-u", UNIT, "-n", str(lines), "--no-pager", "-o", "cat"], 60
            )
            text = out if code == 0 else ""
        tail = text.splitlines()[-int(lines):]
        return "\n".join(tail)

    def _progress(self):
        """How far the running update has got, read from its log. Without a
        terminal pacman prints a "Packages (N)" summary, one "downloading..."
        line per package and one "(i/N) upgrading ..." line per package."""
        try:
            lines = self._log_file.read_text(errors="ignore").splitlines()
        except OSError:
            return None
        step = ""
        for i in range(len(lines) - 1, -1, -1):
            if lines[i].startswith("--- "):
                step = lines[i].strip("- ").strip()
                lines = lines[i + 1:]
                break
        if step.startswith("flatpak"):
            return {"label": "Updating apps", "percent": None}
        if step.startswith("AUR"):
            return {"label": f"Building {step[4:].strip() or 'AUR packages'}", "percent": None}
        if step == "refreshing keyrings":
            return {"label": "Refreshing keys", "percent": None}
        if step != "pacman -Syu":
            return {"label": "Getting ready", "percent": None}

        total = downloaded = 0
        label, percent = "Checking for updates", 0
        for line in lines:
            m = re.match(r"^Packages \((\d+)\)", line)
            if m:
                total, downloaded = int(m.group(1)), 0
                label = f"Downloading 0 of {total}"
                continue
            if total and line.rstrip().endswith("downloading..."):
                downloaded = min(downloaded + 1, total)
                label, percent = f"Downloading {downloaded} of {total}", 45 * downloaded // total
                continue
            if line.startswith(":: Processing package changes"):
                label, percent = "Installing", 50
                continue
            if line.startswith(":: Running post-transaction hooks"):
                label, percent = "Finishing up", 98
                continue
            m = re.match(r"^\(\s*(\d+)/(\d+)\) (\w+)", line)
            if not m or percent >= 98:
                continue
            done, count, verb = int(m.group(1)), int(m.group(2)), m.group(3)
            if verb in ("upgrading", "installing", "reinstalling", "downgrading", "removing"):
                label = f"Installing {done} of {count}"
                percent = 50 + 48 * done // max(count, 1)
            elif verb in ("checking", "loading"):
                label, percent = "Verifying downloads", max(percent, 46)
        return {"label": label, "percent": percent}

    def _unit_processes(self):
        """(main pid, [(pid, command name)]) for everything in the update unit."""
        code, out, _ = _run(
            ["systemctl", "show", "-p", "MainPID", "-p", "ControlGroup", UNIT], timeout=30
        )
        if code != 0:
            return 0, []
        props = dict(line.split("=", 1) for line in out.splitlines() if "=" in line)
        try:
            main_pid = int(props.get("MainPID") or 0)
        except ValueError:
            main_pid = 0
        cgroup = (props.get("ControlGroup") or "").strip()
        if not cgroup:
            return main_pid, []
        try:
            pids = Path("/sys/fs/cgroup" + cgroup, "cgroup.procs").read_text().split()
        except OSError:
            return main_pid, []
        procs = []
        for pid in pids:
            try:
                procs.append((int(pid), Path(f"/proc/{pid}/comm").read_text().strip()))
            except (OSError, ValueError):
                continue  # already gone
        return main_pid, procs

    def _pacman_committing(self):
        """Whether the current step's pacman is past downloading and changing
        the system. From there an interrupt leaves a partial upgrade (or skips
        the post-transaction hooks), so it has to run to the end."""
        try:
            lines = self._log_file.read_text(errors="ignore").splitlines()
        except OSError:
            return True  # can't tell, so don't risk it
        for i in range(len(lines) - 1, -1, -1):
            if lines[i].startswith("--- "):
                lines = lines[i + 1:]
                break
        return any(
            ":: Processing package changes" in line
            or ":: Running pre-transaction hooks" in line
            or ":: Running post-transaction hooks" in line
            for line in lines
        )

    def _cancel(self):
        # The script checks this between steps and stops at the next one.
        self._cancel_file.touch()
        main_pid, procs = self._unit_processes()
        pacman = [pid for pid, name in procs if name == "pacman"]
        if pacman:
            if self._pacman_committing():
                return {
                    "ok": True,
                    "message": "Packages are being installed, and stopping that now "
                               "could break the system. It stops as soon as they're done.",
                }
            # Before the transaction pacman treats SIGINT like Ctrl+C: it drops
            # the download, releases its lock and exits with nothing changed.
            for pid in pacman:
                try:
                    os.kill(pid, signal.SIGINT)
                except OSError:
                    pass
            return {"ok": True, "message": "Stopping. Nothing new gets installed."}
        # Flatpak, git and makepkg are safe to end mid-way. Leave the script
        # itself and the tee that writes its log; the script exits on its own.
        for pid, name in procs:
            if pid == main_pid or name == "tee":
                continue
            try:
                os.kill(pid, signal.SIGTERM)
            except OSError:
                pass
        return {"ok": True, "message": "Stopping."}

    async def cancel_update(self):
        if not (await self.update_status())["running"]:
            return {"ok": False, "message": "No update is running."}
        return await asyncio.to_thread(self._cancel)

    # ---------- reboot ----------

    async def restart_services(self, names: list):
        """Restarting the network stack from inside a live session drops your
        connection, so those are deliberately excluded — a reboot handles them."""
        unsafe = {
            "NetworkManager.service", "wpa_supplicant.service",
            "systemd-udevd.service", "systemd-resolved.service",
            "dbus.service", "dbus-broker.service", "iwd.service",
        }
        done, skipped, failed = [], [], []
        for name in names or []:
            if name in unsafe:
                skipped.append(name)
                continue
            code, _, err = await asyncio.to_thread(
                _run, ["systemctl", "restart", name], 90
            )
            (done if code == 0 else failed).append(name)
            if code != 0:
                decky.logger.error("restart %s failed: %s", name, err)
        return {"restarted": done, "skipped": skipped, "failed": failed}

    async def needs_reboot(self):
        def _check():
            try:
                boot = 0
                for line in Path("/proc/stat").read_text().splitlines():
                    if line.startswith("btime "):
                        boot = int(line.split()[1])
                if not boot:
                    return {"needed": False, "reason": None}

                running = os.uname().release
                if not Path(f"/usr/lib/modules/{running}").is_dir():
                    return {"needed": True, "reason": "the running kernel's modules are gone"}

                for marker in REBOOT_MARKERS:
                    path = Path(marker)
                    if path.exists() and path.stat().st_mtime > boot:
                        return {"needed": True, "reason": f"{path.name} was updated"}

                # Kernels of other flavors (zen, lts, plain cachyos) are
                # never booted here, so a restart can't apply them.
                def child_flavor(d):
                    try:
                        return (d / "pkgbase").read_text().strip()
                    except OSError:
                        return None

                flavor = child_flavor(Path(f"/usr/lib/modules/{running}"))
                modules = Path("/usr/lib/modules")
                if modules.is_dir():
                    for child in modules.iterdir():
                        if not child.is_dir() or child.name == running:
                            continue
                        # Only a real kernel counts, judged by its image: the
                        # folder itself is touched by depmod and DKMS builds
                        # after every boot, and header-only folders have no image.
                        image = child / "vmlinuz"
                        if not image.is_file() or child_flavor(child) != flavor:
                            continue
                        if image.stat().st_mtime > boot:
                            return {"needed": True, "reason": "a newer kernel is installed"}
                return {"needed": False, "reason": None}
            except Exception as exc:  # noqa: BLE001
                decky.logger.error("reboot check failed: %s", exc)
                return {"needed": False, "reason": None}

        return await asyncio.to_thread(_check)

    async def do_reboot(self):
        await asyncio.to_thread(_run, ["systemctl", "reboot"], 30)
        return {"ok": True}

    # ---------- settings ----------

    async def get_settings(self):
        return self.settings

    async def set_settings(self, patch: dict):
        for key, value in (patch or {}).items():
            if key in DEFAULTS:
                self.settings[key] = value
        self._save_json(self._settings_file, self.settings)
        self._restart_poll()
        return self.settings

    async def reset_watchlist(self):
        self.settings["watchlist"] = DEFAULT_WATCHLIST
        self._save_json(self._settings_file, self.settings)
        return self.settings

    # ---------- background poll ----------

    def _restart_poll(self):
        if self.poll_task:
            self.poll_task.cancel()
        self.poll_task = asyncio.create_task(self._poll_loop())

    async def _poll_loop(self):
        try:
            await asyncio.sleep(90)  # let the session settle after boot
            while True:
                try:
                    await self.check_now(announce=True)
                except Exception as exc:  # noqa: BLE001
                    decky.logger.error("poll failed: %s", exc)
                hours = max(1.0, float(self.settings.get("poll_hours", 6)))
                await asyncio.sleep(hours * 3600)
        except asyncio.CancelledError:
            pass

    async def _on_finished(self, status):
        """Runs whether or not the panel is open - the UI used to own this, which
        is why a finished update left a stale count on screen."""
        before = int(self.state.get("count", 0) or 0)
        try:
            await self.check_now(announce=False)
        except Exception as exc:  # noqa: BLE001
            decky.logger.error("post-update check failed: %s", exc)
        after = int(self.state.get("count", 0) or 0)
        try:
            reboot = await self.needs_reboot()
        except Exception:  # noqa: BLE001
            reboot = {"needed": False, "reason": None}

        rc = status.get("last_rc")
        cancelled = bool(status.get("cancelled"))
        packages_done = rc == 0 or bool(status.get("packages_done"))
        self.last_run = {
            "finished": status.get("finished_at") or time.time(),
            "rc": rc,
            "ok": rc == 0,
            "cancelled": cancelled,
            "packages_done": packages_done,
            "installed": max(0, before - after) if packages_done else 0,
            "attempted": before,
            "remaining": after,
            "reboot": reboot.get("needed", False),
            "reboot_reason": reboot.get("reason"),
        }
        self._save_json(self._last_run_file, self.last_run)

        if rc == 0:
            count = self.last_run["installed"] or self.last_run["attempted"]
            body = f"{count} update{'s' if count != 1 else ''} installed."
            if reboot.get("needed"):
                body += " Restart to finish."
            title = "Updates installed"
        elif cancelled:
            title = "Update stopped"
            body = ("System packages were installed; the rest was skipped."
                    if packages_done else "Nothing new was installed.")
        else:
            title = "Update didn't finish"
            body = "Open System Updates to see what happened."

        await decky.emit("cachy_updates/finished", self.last_run)
        await decky.emit("cachy_updates/notify", {"title": title, "body": body})

    async def _finish_watcher(self):
        seen = (self._load_json(self._last_run_file, {}) or {}).get("finished")
        was_running = False
        try:
            while True:
                await asyncio.sleep(5)
                try:
                    status = await self.update_status()
                except Exception:  # noqa: BLE001
                    continue
                if status["running"]:
                    was_running = True
                    continue
                if status.get("pacman_live"):
                    continue  # not over until pacman is
                finished = status.get("finished_at")
                # Either a fresh result landed, or we watched it stop.
                if (finished and finished != seen) or was_running:
                    seen = finished
                    was_running = False
                    await self._on_finished(status)
        except asyncio.CancelledError:
            pass

    # ---------- lifecycle ----------

    async def _main(self):
        decky.logger.info("System Updates: starting")
        self.settings_dir.mkdir(parents=True, exist_ok=True)
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        stored = self._load_json(self._settings_file, {})
        for key, value in stored.items():
            if key in DEFAULTS:
                self.settings[key] = value
        self.last_run = self._load_json(self._last_run_file, None)
        # A restart has happened since that update, so it no longer asks for one.
        try:
            boot = 0
            for line in Path("/proc/stat").read_text().splitlines():
                if line.startswith("btime "):
                    boot = int(line.split()[1])
            if boot and self.last_run and (self.last_run.get("finished") or 0) < boot:
                self.last_run["reboot"] = False
        except (OSError, ValueError):
            pass
        self._restart_poll()
        self.finish_task = asyncio.create_task(self._finish_watcher())

    async def _unload(self):
        if self.poll_task:
            self.poll_task.cancel()
        if getattr(self, "finish_task", None):
            self.finish_task.cancel()
        decky.logger.info("System Updates: unloaded")
