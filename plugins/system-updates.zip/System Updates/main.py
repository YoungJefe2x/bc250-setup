import asyncio
import fnmatch
import json
import os
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

import decky

UNIT = "decky-sysupdate"

DEFAULT_WATCHLIST = ",".join([
    "linux-cachyos*", "linux", "linux-lts", "linux-firmware",
    "mesa", "lib32-mesa", "vulkan-radeon", "lib32-vulkan-radeon", "nvidia*",
    "systemd", "systemd-libs", "glibc",
    "gamescope*", "steam", "steam-native-runtime", "proton-cachyos",
    "pipewire", "pipewire-pulse", "wireplumber",
    "cachyos-handheld*", "cachyos-settings",
    "plasma-desktop", "plasma-workspace", "kwin", "xorg-server", "limine*",
])

DEFAULTS = {
    "poll_hours": 6,
    "notify_watchlist": True,
    "notify_major": True,
    "notify_volume": True,
    "volume_threshold": 80,
    "notify_stale": True,
    "stale_days": 14,
    "notify_services": True,
    "notify_dkms": True,
    "include_aur": True,
    "notify_aur": True,
    "notify_aur_devel": True,
    "install_aur": False,
    "notify_news": True,
    "news_count": 5,
    "block_on_intervention": True,
    "hold_in_game": True,
    "include_flatpak": True,
    "watchlist": DEFAULT_WATCHLIST,
    "cooldown_hours": 72,
}

REBOOT_MARKERS = [
    "/usr/lib/systemd/systemd",
    "/usr/lib/libc.so.6",
    "/usr/lib/libcrypto.so",
]


def _clean_env():
    """Decky's PyInstaller backend exports LD_LIBRARY_PATH pointing at its own
    /tmp/_MEI* bundle. Children inherit it and pick up the wrong libssl, which
    is what produces `OPENSSL_3.4.0 not found` from things like systemctl."""
    env = dict(os.environ)
    for key in ("LD_LIBRARY_PATH", "LD_PRELOAD", "PYTHONHOME", "PYTHONPATH", "_MEIPASS2"):
        env.pop(key, None)
    env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
    env["LC_ALL"] = "C"
    return env


def _run(args, timeout=180, stdin_devnull=False):
    try:
        proc = subprocess.run(
            args,
            env=_clean_env(),
            capture_output=True,
            text=True,
            timeout=timeout,
            stdin=subprocess.DEVNULL if stdin_devnull else None,
        )
        return proc.returncode, proc.stdout, proc.stderr
    except FileNotFoundError:
        return 127, "", f"{args[0]}: not found"
    except subprocess.TimeoutExpired:
        return 124, "", f"{args[0]}: timed out after {timeout}s"
    except Exception as exc:  # noqa: BLE001
        return 1, "", str(exc)


def _strip_epoch(version: str) -> str:
    return version.split(":", 1)[1] if ":" in version else version


def _base_parts(version: str):
    core = _strip_epoch(version).split("-", 1)[0]
    return [p for p in re.split(r"[._+]", core) if p]


def _is_major_bump(old: str, new: str, depth: int = 1) -> bool:
    a, b = _base_parts(old), _base_parts(new)
    return a[:depth] != b[:depth]


class Plugin:
    def __init__(self):
        self.settings = dict(DEFAULTS)
        self.state = {}
        self.poll_task = None
        self.finish_task = None
        self.last_run = None
        self.settings_dir = Path(
            os.environ.get("DECKY_PLUGIN_SETTINGS_DIR", "/tmp/cachy-updates")
        )
        self.runtime_dir = Path(
            os.environ.get("DECKY_PLUGIN_RUNTIME_DIR", str(self.settings_dir))
        )
        self.user = os.environ.get("DECKY_USER", "deck")

    # ---------- persistence ----------

    @property
    def _settings_file(self):
        return self.settings_dir / "settings.json"

    @property
    def _announced_file(self):
        return self.settings_dir / "announced.json"

    @property
    def _script_file(self):
        return self.runtime_dir / "run-update.sh"

    @property
    def _log_file(self):
        return self.runtime_dir / "update.log"

    @property
    def _last_run_file(self):
        return self.runtime_dir / "finish.json"

    @property
    def _result_file(self):
        return self.runtime_dir / "last-run.json"

    def _load_json(self, path, fallback):
        try:
            return json.loads(path.read_text())
        except Exception:  # noqa: BLE001
            return fallback

    def _save_json(self, path, data):
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(data, indent=2))
        except Exception as exc:  # noqa: BLE001
            decky.logger.error("could not write %s: %s", path, exc)

    # ---------- checking ----------

    def _check_via_temp_db(self):
        """What checkupdates does, done inline so pacman-contrib isn't required:
        refresh a *copy* of the sync DB in a temp dir and diff against that, so
        the real DB is never touched and we can't cause a partial upgrade."""
        tmp = Path(tempfile.mkdtemp(prefix="decky-checkup-"))
        try:
            db = tmp / "db"
            (db / "sync").mkdir(parents=True, exist_ok=True)
            source = Path("/var/lib/pacman/sync")
            if source.is_dir():
                for item in source.iterdir():
                    if item.is_file():
                        shutil.copy2(item, db / "sync" / item.name)
            (db / "local").symlink_to("/var/lib/pacman/local")

            code, out, err = _run(
                ["pacman", "-Sy", "--dbpath", str(db), "--logfile", "/dev/null"],
                timeout=300,
            )
            if code != 0:
                return None, (err or out or f"pacman -Sy exited {code}").strip()

            code, out, err = _run(["pacman", "-Qu", "--dbpath", str(db)], timeout=120)
            # -Qu exits 1 when there is simply nothing to upgrade.
            if code not in (0, 1):
                return None, (err or out or f"pacman -Qu exited {code}").strip()
            return out, None
        except Exception as exc:  # noqa: BLE001
            return None, str(exc)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def _check_pacman(self):
        if shutil.which("checkupdates"):
            code, out, err = _run(["checkupdates"], timeout=300)
            # checkupdates exits 2 when there is nothing to upgrade.
            if code not in (0, 2):
                return None, (err or out or f"checkupdates exited {code}").strip()
        else:
            out, error = self._check_via_temp_db()
            if error:
                return None, error

        packages = []
        for line in out.splitlines():
            if "[ignored]" in line:
                continue
            match = re.match(r"^(\S+)\s+(\S+)\s+->\s+(\S+)$", line.strip())
            if match:
                packages.append({
                    "name": match.group(1),
                    "old": match.group(2),
                    "new": match.group(3),
                })
        return packages, None

    def _check_flatpak(self):
        if not shutil.which("flatpak"):
            return []
        apps = []
        code, out, _ = _run(
            ["flatpak", "remote-ls", "--updates", "--columns=application"], timeout=180
        )
        if code == 0:
            apps += [l.strip() for l in out.splitlines() if l.strip()]
        code, out, _ = _run(
            ["runuser", "-u", self.user, "--",
             "flatpak", "remote-ls", "--user", "--updates", "--columns=application"],
            timeout=180,
        )
        if code == 0:
            apps += [l.strip() for l in out.splitlines() if l.strip()]
        return sorted(set(apps))

    def _check_news(self):
        """Arch news is published precisely when an upgrade needs a human, so an
        unread 'manual intervention' item is the one thing that should stop an
        unattended --noconfirm run."""
        binary = shutil.which("arch-update") or shutil.which("cachy-update")
        if not binary:
            return []
        count = int(self.settings.get("news_count", 5))
        code, out, _ = _run([binary, "-n", str(count)], timeout=120, stdin_devnull=True)
        if code not in (0, 1, 130):
            return []

        seen_store = self._load_json(self._announced_file, {})
        items = []
        in_section = False
        for line in out.splitlines():
            stripped = line.strip()
            if "Arch News:" in stripped:
                in_section = True
                continue
            if not in_section or not stripped:
                continue
            if stripped.startswith("->"):
                break
            match = re.match(r"^\d+\s+-\s+(.+?)\s*$", stripped)
            if not match:
                continue
            title = match.group(1)
            items.append({
                "title": title,
                "intervention": bool(
                    re.search(r"manual intervention|requires? action", title, re.I)
                ),
                "seen": f"news:{title}" in seen_store,
            })
        return items

    def _check_services(self):
        """arch-update -s lists services still running against deleted libraries.
        It ends on an interactive prompt, so stdin is closed to make it fall
        straight through after printing the list."""
        binary = shutil.which("arch-update") or shutil.which("cachy-update")
        if not binary:
            return []
        code, out, _ = _run([binary, "-s"], timeout=120, stdin_devnull=True)
        if code not in (0, 1, 130):
            return []
        services = []
        for line in out.splitlines():
            match = re.match(r"^\s*\d+\s+-\s+(\S+\.(?:service|socket|timer))\s*$", line)
            if match:
                services.append(match.group(1))
        return services

    def _check_dkms(self):
        """A DKMS module that failed to rebuild leaves pacman's exit code at 0,
        so a broken sensors or driver module would otherwise pass silently."""
        if not shutil.which("dkms"):
            return []
        code, out, _ = _run(["dkms", "status"], timeout=60)
        if code != 0:
            return []
        broken = []
        for line in out.splitlines():
            if not line.strip():
                continue
            lowered = line.lower()
            if "installed" in lowered or "built" in lowered:
                continue
            if any(word in lowered for word in ("error", "failed", "broken", "added")):
                broken.append(line.strip())
        return broken

    def _check_aur(self):
        """VCS packages (-git and friends) always report a pending 'update', so
        they're listed but never allowed to trigger a notification."""
        helper = None
        for candidate in ("paru", "yay"):
            if shutil.which(candidate):
                helper = candidate
                break
        if not helper:
            return []

        code, out, _ = _run(
            ["runuser", "-u", self.user, "--", helper, "-Qua", "--color", "never"],
            timeout=300,
            stdin_devnull=True,
        )
        if code not in (0, 1):
            return []

        items = []
        for line in out.splitlines():
            match = re.match(r"^(\S+)\s+(\S+)\s+->\s+(\S+)$", line.strip())
            if not match:
                continue
            name, old, new = match.groups()
            vcs = bool(
                re.search(r"-(git|svn|hg|bzr|cvs|nightly)$", name)
            ) or "latest-commit" in new
            items.append({"name": name, "old": old, "new": new, "vcs": vcs})
        return items

    def _check_security(self):
        if not shutil.which("arch-audit"):
            return []

        found = []
        code, out, _ = _run(["arch-audit", "-u", "-f", "%n|%s"], timeout=120)
        if code in (0, 1):
            for line in out.splitlines():
                if "|" in line:
                    name, severity = line.split("|", 1)
                    found.append({"name": name.strip(), "severity": severity.strip()})
        if found:
            return found

        # Either there's genuinely nothing, or this arch-audit doesn't support
        # that format string. Re-run without -f and parse the prose; a silent
        # empty list here would disable the one rule that can't be toggled off.
        code, out, _ = _run(["arch-audit", "-u"], timeout=120)
        if code not in (0, 1):
            decky.logger.warning("arch-audit failed (exit %s)", code)
            return []
        for line in out.splitlines():
            match = re.search(r"Package\s+(\S+?)\s+is affected by", line)
            if not match:
                continue
            severity = "Unknown"
            risk = re.search(r"\b(Critical|High|Medium|Low)\b\s+risk", line, re.I)
            if risk:
                severity = risk.group(1).capitalize()
            found.append({"name": match.group(1), "severity": severity})
        return found

    def _last_upgrade_ts(self):
        path = Path("/var/log/pacman.log")
        if not path.exists():
            return None
        try:
            with path.open("rb") as handle:
                handle.seek(0, os.SEEK_END)
                size = handle.tell()
                handle.seek(max(0, size - 400_000))
                tail = handle.read().decode("utf-8", errors="ignore")
        except Exception:  # noqa: BLE001
            return None
        stamp = None
        for line in tail.splitlines():
            if "starting full system upgrade" in line:
                match = re.match(r"^\[([^\]]+)\]", line)
                if match:
                    stamp = match.group(1)
        if not stamp:
            return None
        try:
            cleaned = stamp.replace("Z", "+00:00")
            from datetime import datetime
            return datetime.fromisoformat(cleaned).timestamp()
        except Exception:  # noqa: BLE001
            return None

    def _classify(self, packages, security, services=None, dkms=None, news=None,
                  aur=None):
        watchlist = [
            p.strip() for p in str(self.settings["watchlist"]).split(",") if p.strip()
        ]
        security_names = {item["name"] for item in security}
        reasons = []
        important = []

        for pkg in packages:
            flags = []
            name = pkg["name"]

            if any(fnmatch.fnmatch(name, pattern) for pattern in watchlist):
                flags.append("watchlist")

            depth = 2 if name.startswith("linux") else 1
            if _is_major_bump(pkg["old"], pkg["new"], depth):
                flags.append("major")

            if name in security_names:
                flags.append("security")

            pkg["flags"] = flags
            if flags:
                important.append(pkg)

        def _has(flag):
            return [p["name"] for p in important if flag in p["flags"]]

        if security:
            names = sorted({item["name"] for item in security})
            reasons.append({
                "kind": "security",
                "text": "Security fix ready for " + ", ".join(names[:4])
                        + (f" +{len(names) - 4} more" if len(names) > 4 else ""),
            })

        if self.settings["notify_watchlist"]:
            names = _has("watchlist")
            if names:
                reasons.append({
                    "kind": "watchlist",
                    "text": "Update ready for " + ", ".join(names[:4])
                            + (f" +{len(names) - 4} more" if len(names) > 4 else ""),
                })

        if self.settings["notify_major"]:
            names = _has("major")
            if names:
                reasons.append({
                    "kind": "major",
                    "text": "New major version of " + ", ".join(names[:4])
                            + (f" +{len(names) - 4} more" if len(names) > 4 else ""),
                })

        if self.settings["notify_volume"]:
            threshold = int(self.settings["volume_threshold"])
            if len(packages) >= threshold:
                reasons.append({
                    "kind": "volume",
                    "text": f"{len(packages)} updates waiting — a bigger batch than usual",
                })

        if self.settings.get("notify_aur", True) and aur:
            wanted = aur if self.settings.get("notify_aur_devel", True) else [
                a for a in aur if not a["vcs"]
            ]
            if wanted:
                names = ", ".join(a["name"] for a in wanted[:3])
                reasons.append({
                    "kind": "aur",
                    "text": f"AUR update ready for {names}",
                })

        if self.settings.get("notify_news", True) and news:
            unread = [n for n in news if not n["seen"]]
            blockers = [n for n in unread if n["intervention"]]
            if blockers:
                reasons.insert(0, {
                    "kind": "news",
                    "text": "This update needs a manual step: " + blockers[0]["title"],
                })
            elif unread:
                reasons.append({
                    "kind": "news",
                    "text": f"{len(unread)} thing(s) worth reading before you update",
                })

        if self.settings.get("notify_dkms", True) and dkms:
            reasons.append({
                "kind": "dkms",
                "text": "A driver didn't rebuild — sensors or fan control may be affected",
            })

        if self.settings.get("notify_services", True) and services:
            reasons.append({
                "kind": "services",
                "text": f"{len(services)} things are still running an old version",
            })

        stale_since = None
        if self.settings["notify_stale"] and packages:
            last = self._last_upgrade_ts()
            if last:
                days = (time.time() - last) / 86400
                stale_since = round(days, 1)
                if days >= float(self.settings["stale_days"]):
                    reasons.append({
                        "kind": "stale",
                        "text": f"You haven't updated in {int(days)} days",
                    })

        return important, reasons, stale_since

    def _should_announce(self, packages, reasons, aur=None):
        """Dedupe so a pending kernel update doesn't re-toast every poll."""
        if not reasons:
            return False, None
        announced = self._load_json(self._announced_file, {})
        now = time.time()
        cooldown = float(self.settings["cooldown_hours"]) * 3600

        fresh = []
        for pkg in packages:
            key = f"{pkg['name']}@{pkg['new']}"
            seen = announced.get(key)
            if seen is None or (now - seen) > cooldown:
                fresh.append(pkg["name"])
                announced[key] = now

        # Development packages report a constant "latest-commit", so key them on
        # the version you have installed - that changes when you update, which
        # is exactly when it's worth mentioning again.
        for item in aur or []:
            target = item["old"] if item["vcs"] else item["new"]
            key = f"aur:{item['name']}@{target}"
            seen = announced.get(key)
            if seen is None or (now - seen) > cooldown:
                fresh.append(item["name"])
                announced[key] = now

        standalone = ("volume", "stale", "services", "dkms", "news")
        volume_only = all(r["kind"] in standalone for r in reasons)
        if volume_only:
            key = f"__{reasons[0]['kind']}__"
            seen = announced.get(key)
            if seen is not None and (now - seen) <= cooldown:
                return False, None
            announced[key] = now
            fresh = fresh or ["batch"]

        # Prune anything older than 30 days so the file can't grow forever.
        announced = {k: v for k, v in announced.items() if (now - v) < 30 * 86400}
        self._save_json(self._announced_file, announced)
        return bool(fresh), fresh

    async def check_now(self, announce: bool = False):
        packages, error = await asyncio.to_thread(self._check_pacman)
        if error:
            self.state = {
                "checked_at": time.time(),
                "error": error,
                "count": 0,
                "packages": [],
                "important": [],
                "reasons": [],
                "flatpak": [],
                "security": [],
                "services": [],
                "dkms": [],
                "news": [],
                "aur": [],
                "blocking_news": False,
                "stale_days_since": None,
            }
            await decky.emit("cachy_updates/state", self.state)
            return self.state

        security = await asyncio.to_thread(self._check_security)
        services = []
        if self.settings.get("notify_services", True):
            services = await asyncio.to_thread(self._check_services)
        dkms = []
        if self.settings.get("notify_dkms", True):
            dkms = await asyncio.to_thread(self._check_dkms)
        news = []
        if self.settings.get("notify_news", True):
            news = await asyncio.to_thread(self._check_news)
        aur = []
        if self.settings.get("include_aur", True):
            aur = await asyncio.to_thread(self._check_aur)
        flatpak = []
        if self.settings["include_flatpak"]:
            flatpak = await asyncio.to_thread(self._check_flatpak)

        important, reasons, stale_since = self._classify(
            packages, security, services, dkms, news, aur
        )
        blocking = bool(
            self.settings.get("block_on_intervention", True)
            and [n for n in news if n["intervention"] and not n["seen"]]
        )

        self.state = {
            "checked_at": time.time(),
            "error": None,
            "count": len(packages),
            "packages": packages,
            "important": important,
            "reasons": reasons,
            "flatpak": flatpak,
            "security": security,
            "services": services,
            "dkms": dkms,
            "news": news,
            "aur": aur,
            "blocking_news": blocking,
            "stale_days_since": stale_since,
        }
        await decky.emit("cachy_updates/state", self.state)

        if announce:
            should, _ = self._should_announce(important or packages, reasons, aur)
            if should:
                headline = reasons[0]["text"]
                extra = f" ({len(packages)} updates total)" if packages else ""
                await decky.emit("cachy_updates/notify", {
                    "title": "Updates ready",
                    "body": headline + extra,
                })
        return self.state

    async def get_state(self):
        return {**self.state, "last_run": self.last_run}

    # ---------- applying ----------

    def _write_script(self):
        keyrings = []
        for pkg in ("archlinux-keyring", "cachyos-keyring"):
            code, _, _ = _run(["pacman", "-Si", pkg], timeout=60)
            if code == 0:
                keyrings.append(pkg)

        build_dir = self.runtime_dir / "build"
        user = self.user
        script = f"""#!/bin/bash
LOG="{self._log_file}"
RESULT="{self._result_file}"
exec > >(tee -a "$LOG") 2>&1

finish() {{
  rc=$?
  printf '{{"rc":%d,"finished":%d}}\\n' "$rc" "$(date +%s)" > "$RESULT"
}}
trap finish EXIT

echo "=== update started $(date -Is) ==="

if [ -n "{' '.join(keyrings)}" ]; then
  echo "--- refreshing keyrings ---"
  pacman -Sy --needed --noconfirm {' '.join(keyrings)} || echo "keyring refresh failed, continuing"
fi

echo "--- pacman -Syu ---"
pacman -Syu --noconfirm --disable-download-timeout
rc=$?
if [ "$rc" -ne 0 ]; then
  echo "!!! pacman failed with exit code $rc — stopping here."
  echo "!!! Finish this one in Desktop Mode; do not re-run blindly."
  exit "$rc"
fi

if [ "$DO_FLATPAK" = "1" ] && command -v flatpak >/dev/null; then
  echo "--- flatpak (system) ---"
  flatpak update -y --noninteractive || echo "system flatpak update failed"
  echo "--- flatpak (user) ---"
  uid="$(id -u "{self.user}" 2>/dev/null)"
  if [ -n "$uid" ]; then
    runuser -u "{self.user}" -- env "XDG_RUNTIME_DIR=/run/user/$uid" \\
      flatpak update -y --noninteractive --user \\
      || echo "user flatpak update failed"
  fi
fi

if [ "$DO_AUR" = "1" ] && [ -n "$AUR_PKGS" ]; then
  echo "--- AUR ---"
  BUILD="{build_dir}"
  mkdir -p "$BUILD"
  chown "{user}" "$BUILD"
  for pkg in $AUR_PKGS; do
    echo "--- AUR: $pkg ---"
    DIR="$BUILD/$pkg"
    if [ -d "$DIR/.git" ]; then
      runuser -u "{user}" -- git -C "$DIR" fetch --depth 1 origin master \\
        && runuser -u "{user}" -- git -C "$DIR" reset --hard origin/master \\
        || {{ echo "fetch failed for $pkg"; continue; }}
    else
      rm -rf "$DIR"
      runuser -u "{user}" -- git clone --depth 1 \\
        "https://aur.archlinux.org/$pkg.git" "$DIR" \\
        || {{ echo "clone failed for $pkg"; continue; }}
    fi

    # Install build+runtime deps as root first, so makepkg never needs sudo.
    DEPS=$(runuser -u "{user}" -- bash -c "cd '$DIR' && makepkg --printsrcinfo" \\
      | awk -F' = ' '/^\\t(make)?depends/ {{print $2}}' \\
      | sed 's/[<>=].*//' | sort -u | tr '\\n' ' ')
    if [ -n "$DEPS" ]; then
      echo "deps: $DEPS"
      pacman -S --needed --asdeps --noconfirm $DEPS || echo "some deps unavailable"
    fi

    rm -f "$DIR"/*.pkg.tar.*
    # --nodeps: deps are already handled above, as root.
    if ! runuser -u "{user}" -- bash -c \\
      "cd '$DIR' && makepkg -f --noconfirm --nodeps --noprogressbar"; then
      echo "!!! build failed for $pkg — skipping, other packages continue"
      continue
    fi

    if ! pacman -U --noconfirm "$DIR"/*.pkg.tar.*; then
      echo "!!! install failed for $pkg"
    fi
  done
fi

echo "=== update finished $(date -Is) ==="
"""
        self._script_file.parent.mkdir(parents=True, exist_ok=True)
        self._script_file.write_text(script)
        self._script_file.chmod(0o755)

    async def ack_news(self):
        store = self._load_json(self._announced_file, {})
        now = time.time()
        for item in self.state.get("news", []) or []:
            store[f"news:{item['title']}"] = now
        self._save_json(self._announced_file, store)
        return await self.check_now(announce=False)

    async def lock_state(self):
        """A killed pacman can leave /var/lib/pacman/db.lck behind. Removing it
        while pacman is alive corrupts the DB, so check for a live process."""
        lock = Path("/var/lib/pacman/db.lck")
        if not lock.exists():
            return {"locked": False, "live": False, "age_min": 0}
        code, out, _ = await asyncio.to_thread(_run, ["pgrep", "-x", "pacman"], 30)
        live = code == 0 and bool(out.strip())
        try:
            age = int((time.time() - lock.stat().st_mtime) / 60)
        except OSError:
            age = 0
        return {"locked": True, "live": live, "age_min": age}

    async def clear_lock(self):
        info = await self.lock_state()
        if not info["locked"]:
            return {"ok": True, "message": "Nothing to clear."}
        if info["live"]:
            return {
                "ok": False,
                "message": "An update is still running. Let it finish.",
            }
        try:
            Path("/var/lib/pacman/db.lck").unlink()
            return {"ok": True, "message": "Cleared. Try updating again."}
        except OSError as exc:
            return {"ok": False, "message": str(exc)}

    async def start_update(self):
        if self.state.get("blocking_news"):
            return {
                "ok": False,
                "error": "One update needs a manual step first. Read it, then mark it read.",
            }
        status = await self.update_status()
        if status["running"]:
            return {"ok": False, "error": "An update is already running."}
        lock = await self.lock_state()
        if lock["locked"]:
            if lock["live"]:
                return {"ok": False, "error": "Another update is already running."}
            return {
                "ok": False,
                "error": "A previous update left a lock behind. "
                         "Use Clear leftover lock in Troubleshooting.",
            }

        try:
            self._log_file.unlink(missing_ok=True)
            self._result_file.unlink(missing_ok=True)
        except Exception:  # noqa: BLE001
            pass

        await asyncio.to_thread(self._write_script)
        _run(["systemctl", "reset-failed", UNIT], timeout=30)

        # Only ever build what the last check actually reported.
        aur_list = " ".join(
            a["name"]
            for a in (self.state.get("aur") or [])
            if re.match(r"^[A-Za-z0-9@._+-]+$", a["name"])
        )

        args = [
            "systemd-run",
            f"--unit={UNIT}",
            "--property=Type=oneshot",
            # 'infinity' is the only value systemd treats as no limit; 0 gives
            # the unit a zero-second budget and it gets killed on the spot.
            "--property=TimeoutStartSec=infinity",
            "--property=TimeoutStopSec=infinity",
            # Never SIGKILL a running pacman - a half-written package DB is far
            # worse than a unit that outlives a cancel.
            "--property=KillMode=process",
            "--property=KillSignal=SIGTERM",
            "--no-block",
            f"--setenv=DO_FLATPAK={'1' if self.settings['include_flatpak'] else '0'}",
            f"--setenv=DO_AUR={'1' if self.settings.get('install_aur') else '0'}",
            f"--setenv=AUR_PKGS={aur_list}",
            "/bin/bash",
            str(self._script_file),
        ]
        code, out, err = await asyncio.to_thread(_run, args, 60)
        if code != 0:
            return {"ok": False, "error": (err or out or f"systemd-run exited {code}").strip()}
        return {"ok": True}

    async def update_status(self):
        code, out, _ = await asyncio.to_thread(
            _run, ["systemctl", "is-active", UNIT], 30
        )
        active = out.strip()
        running = active in ("activating", "active", "reloading")
        result = self._load_json(self._result_file, None)
        return {
            "running": running,
            "active": active,
            "last_rc": None if result is None else result.get("rc"),
            "finished_at": None if result is None else result.get("finished"),
        }

    async def get_log(self, lines: int = 60):
        try:
            text = self._log_file.read_text(errors="ignore")
        except Exception:  # noqa: BLE001
            code, out, _ = await asyncio.to_thread(
                _run, ["journalctl", "-u", UNIT, "-n", str(lines), "--no-pager", "-o", "cat"], 60
            )
            text = out if code == 0 else ""
        tail = text.splitlines()[-int(lines):]
        return "\n".join(tail)

    async def cancel_update(self):
        await asyncio.to_thread(_run, ["systemctl", "stop", UNIT], 60)
        return {"ok": True}

    # ---------- reboot ----------

    async def restart_services(self, names: list):
        """Restarting the network stack from inside a live session drops your
        connection, so those are deliberately excluded — a reboot handles them."""
        unsafe = {
            "NetworkManager.service", "wpa_supplicant.service",
            "systemd-udevd.service", "systemd-resolved.service",
            "dbus.service", "dbus-broker.service", "iwd.service",
        }
        done, skipped, failed = [], [], []
        for name in names or []:
            if name in unsafe:
                skipped.append(name)
                continue
            code, _, err = await asyncio.to_thread(
                _run, ["systemctl", "restart", name], 90
            )
            (done if code == 0 else failed).append(name)
            if code != 0:
                decky.logger.error("restart %s failed: %s", name, err)
        return {"restarted": done, "skipped": skipped, "failed": failed}

    async def needs_reboot(self):
        def _check():
            try:
                boot = 0
                for line in Path("/proc/stat").read_text().splitlines():
                    if line.startswith("btime "):
                        boot = int(line.split()[1])
                if not boot:
                    return {"needed": False, "reason": None}

                running = os.uname().release
                if not Path(f"/usr/lib/modules/{running}").is_dir():
                    return {"needed": True, "reason": "the running kernel's modules are gone"}

                for marker in REBOOT_MARKERS:
                    path = Path(marker)
                    if path.exists() and path.stat().st_mtime > boot:
                        return {"needed": True, "reason": f"{path.name} was updated"}

                modules = Path("/usr/lib/modules")
                if modules.is_dir():
                    for child in modules.iterdir():
                        if child.is_dir() and child.name != running and child.stat().st_mtime > boot:
                            return {"needed": True, "reason": "a newer kernel is installed"}
                return {"needed": False, "reason": None}
            except Exception as exc:  # noqa: BLE001
                decky.logger.error("reboot check failed: %s", exc)
                return {"needed": False, "reason": None}

        return await asyncio.to_thread(_check)

    async def do_reboot(self):
        await asyncio.to_thread(_run, ["systemctl", "reboot"], 30)
        return {"ok": True}

    # ---------- settings ----------

    async def get_settings(self):
        return self.settings

    async def set_settings(self, patch: dict):
        for key, value in (patch or {}).items():
            if key in DEFAULTS:
                self.settings[key] = value
        self._save_json(self._settings_file, self.settings)
        self._restart_poll()
        return self.settings

    async def reset_watchlist(self):
        self.settings["watchlist"] = DEFAULT_WATCHLIST
        self._save_json(self._settings_file, self.settings)
        return self.settings

    # ---------- background poll ----------

    def _restart_poll(self):
        if self.poll_task:
            self.poll_task.cancel()
        self.poll_task = asyncio.create_task(self._poll_loop())

    async def _poll_loop(self):
        try:
            await asyncio.sleep(90)  # let the session settle after boot
            while True:
                try:
                    await self.check_now(announce=True)
                except Exception as exc:  # noqa: BLE001
                    decky.logger.error("poll failed: %s", exc)
                hours = max(1.0, float(self.settings.get("poll_hours", 6)))
                await asyncio.sleep(hours * 3600)
        except asyncio.CancelledError:
            pass

    async def _on_finished(self, status):
        """Runs whether or not the panel is open - the UI used to own this, which
        is why a finished update left a stale count on screen."""
        before = int(self.state.get("count", 0) or 0)
        try:
            await self.check_now(announce=False)
        except Exception as exc:  # noqa: BLE001
            decky.logger.error("post-update check failed: %s", exc)
        after = int(self.state.get("count", 0) or 0)
        try:
            reboot = await self.needs_reboot()
        except Exception:  # noqa: BLE001
            reboot = {"needed": False, "reason": None}

        rc = status.get("last_rc")
        self.last_run = {
            "finished": status.get("finished_at") or time.time(),
            "rc": rc,
            "ok": rc == 0,
            "installed": max(0, before - after) if rc == 0 else 0,
            "attempted": before,
            "remaining": after,
            "reboot": reboot.get("needed", False),
            "reboot_reason": reboot.get("reason"),
        }
        self._save_json(self._last_run_file, self.last_run)

        if rc == 0:
            count = self.last_run["installed"] or self.last_run["attempted"]
            body = f"{count} update{'s' if count != 1 else ''} installed."
            if reboot.get("needed"):
                body += " Restart to finish."
            title = "Updates installed"
        else:
            title = "Update didn't finish"
            body = "Open System Updates to see what happened."

        await decky.emit("cachy_updates/finished", self.last_run)
        await decky.emit("cachy_updates/notify", {"title": title, "body": body})

    async def _finish_watcher(self):
        seen = (self._load_json(self._last_run_file, {}) or {}).get("finished")
        was_running = False
        try:
            while True:
                await asyncio.sleep(5)
                try:
                    status = await self.update_status()
                except Exception:  # noqa: BLE001
                    continue
                if status["running"]:
                    was_running = True
                    continue
                finished = status.get("finished_at")
                # Either a fresh result landed, or we watched it stop.
                if (finished and finished != seen) or was_running:
                    seen = finished
                    was_running = False
                    await self._on_finished(status)
        except asyncio.CancelledError:
            pass

    # ---------- lifecycle ----------

    async def _main(self):
        decky.logger.info("System Updates: starting")
        self.settings_dir.mkdir(parents=True, exist_ok=True)
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        stored = self._load_json(self._settings_file, {})
        for key, value in stored.items():
            if key in DEFAULTS:
                self.settings[key] = value
        self.last_run = self._load_json(self._last_run_file, None)
        self._restart_poll()
        self.finish_task = asyncio.create_task(self._finish_watcher())

    async def _unload(self):
        if self.poll_task:
            self.poll_task.cancel()
        if getattr(self, "finish_task", None):
            self.finish_task.cancel()
        decky.logger.info("System Updates: unloaded")
