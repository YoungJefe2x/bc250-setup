import {
  ButtonItem,
  Field,
  PanelSection,
  PanelSectionRow,
  Router,
  SliderField,
  TextField,
  ToggleField,
  staticClasses,
} from "@decky/ui";
import {
  addEventListener,
  removeEventListener,
  callable,
  definePlugin,
  toaster,
} from "@decky/api";
import { useEffect, useState } from "react";

interface Pkg {
  name: string;
  old: string;
  new: string;
  flags?: string[];
}

interface Reason {
  kind: string;
  text: string;
}

interface NewsItem {
  title: string;
  intervention: boolean;
  seen: boolean;
}

interface State {
  checked_at: number;
  error: string | null;
  count: number;
  packages: Pkg[];
  important: Pkg[];
  reasons: Reason[];
  flatpak: string[];
  security: { name: string; severity: string }[];
  services?: string[];
  dkms?: string[];
  news?: NewsItem[];
  aur?: { name: string; old: string; new: string; vcs: boolean }[];
  blocking_news?: boolean;
  last_run?: LastRun | null;
  stale_days_since?: number | null;
  plugin_updates?: PluginUpdate[];
  plugin_error?: string | null;
  tool_update?: { path: string; blob: string } | null;
  decky_restart_pending?: string[];
}

interface PluginUpdate {
  dir: string;
  name: string;
  installed: string;
  latest: string;
  packages_only?: boolean;
  missing?: string[];
}

interface LastRun {
  finished: number;
  rc: number | null;
  ok: boolean;
  installed: number;
  attempted: number;
  remaining: number;
  reboot: boolean;
  reboot_reason: string | null;
}

interface Settings {
  poll_hours: number;
  notify_watchlist: boolean;
  notify_major: boolean;
  notify_volume: boolean;
  volume_threshold: number;
  notify_stale: boolean;
  stale_days: number;
  notify_services: boolean;
  notify_dkms: boolean;
  include_aur: boolean;
  notify_aur: boolean;
  notify_aur_devel: boolean;
  install_aur: boolean;
  notify_news: boolean;
  news_count: number;
  block_on_intervention: boolean;
  hold_in_game: boolean;
  include_flatpak: boolean;
  watchlist: string;
  cooldown_hours: number;
}

interface UpdateStatus {
  running: boolean;
  active: string;
  last_rc: number | null;
  finished_at: number | null;
}

const checkNow = callable<[boolean], State>("check_now");
const updatePlugins = callable<
  [],
  { ok: boolean; updated: string[]; failed: { name: string; error: string }[] }
>("update_plugins");
const restartDecky = callable<[], { ok: boolean; message: string }>("restart_decky");
const updateTool = callable<[], { ok: boolean; message: string }>("update_tool");
const getState = callable<[], State>("get_state");
const startUpdate = callable<[], { ok: boolean; error?: string }>("start_update");
const cancelUpdate = callable<[], { ok: boolean }>("cancel_update");
const updateStatus = callable<[], UpdateStatus>("update_status");
const getLog = callable<[number], string>("get_log");
const getSettings = callable<[], Settings>("get_settings");
const setSettings = callable<[Partial<Settings>], Settings>("set_settings");
const resetWatchlist = callable<[], Settings>("reset_watchlist");
const needsReboot = callable<[], { needed: boolean; reason: string | null }>("needs_reboot");
const doReboot = callable<[], { ok: boolean }>("do_reboot");
const restartServices = callable<
  [string[]],
  { restarted: string[]; skipped: string[]; failed: string[] }
>("restart_services");
const ackNews = callable<[], State>("ack_news");
const lockState = callable<[], { locked: boolean; live: boolean; age_min: number }>("lock_state");
const clearLock = callable<[], { ok: boolean; message: string }>("clear_lock");

/** Service unit names mean nothing to most people mid-game. */
const SERVICE_LABELS: Record<string, string> = {
  "NetworkManager.service": "Networking",
  "wpa_supplicant.service": "Wi-Fi",
  "systemd-resolved.service": "DNS lookups",
  "systemd-udevd.service": "Device detection",
  "sshd.service": "Remote login",
  "udisks2.service": "Drive mounting",
  "upower.service": "Battery and power",
  "input-remapper.service": "Controller remapping",
  "bluetooth.service": "Bluetooth",
  "cups.service": "Printing",
};

const friendlyService = (unit: string): string =>
  SERVICE_LABELS[unit] ?? unit.replace(/\.(service|socket|timer)$/, "");


/**
 * The icon and title are mounted once by Decky and live outside <Content>, so
 * they need their own tiny store rather than component state.
 */
interface Badge {
  count: number;
  attention: boolean;
}

let badge: Badge = { count: 0, attention: false };
const badgeSubs = new Set<(b: Badge) => void>();

function setBadge(next: Badge) {
  if (next.count === badge.count && next.attention === badge.attention) return;
  badge = next;
  badgeSubs.forEach((fn) => fn(badge));
}

function badgeFromState(s: State | null): Badge {
  if (!s || s.error) return { count: 0, attention: false };
  const attention =
    !!s.blocking_news ||
    (s.important?.length ?? 0) > 0 ||
    (s.services?.length ?? 0) > 0 ||
    (s.dkms?.length ?? 0) > 0;
  return { count: s.count ?? 0, attention };
}

function useBadge(): Badge {
  const [b, setB] = useState<Badge>(badge);
  useEffect(() => {
    badgeSubs.add(setB);
    return () => {
      badgeSubs.delete(setB);
    };
  }, []);
  return b;
}

function BadgePill({ count, attention }: Badge) {
  if (count <= 0) return null;
  return (
    <span
      style={{
        marginLeft: "6px",
        padding: "0 6px",
        borderRadius: "10px",
        fontSize: "0.7em",
        fontWeight: 700,
        lineHeight: "1.5em",
        display: "inline-block",
        minWidth: "1.1em",
        textAlign: "center",
        background: attention ? "#e0a03a" : "#4c5b6b",
        color: attention ? "#1a1a1a" : "#ffffff",
      }}
    >
      {count > 99 ? "99+" : count}
    </span>
  );
}

function timeAgo(ts?: number): string {
  if (!ts) return "not yet";
  const mins = Math.floor((Date.now() / 1000 - ts) / 60);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

/** Turn raw pacman output into one line a person can read at a glance. */
function phaseFromLog(log: string): string {
  const lines = log.trim().split("\n").reverse();
  for (const line of lines) {
    if (line.includes("flatpak (user)")) return "Updating apps…";
    if (line.includes("flatpak (system)")) return "Updating apps…";
    if (/^\s*installing|reinstalling|upgrading/i.test(line)) return "Installing…";
    if (/checking (keys|package integrity|for file conflicts)/i.test(line))
      return "Verifying downloads…";
    if (/^\s*downloading|retrieving packages/i.test(line)) return "Downloading…";
    if (line.includes("refreshing keyrings")) return "Refreshing keys…";
    if (line.includes("pacman -Syu")) return "Starting…";
  }
  return "Working…";
}

function Content() {
  const [state, setState] = useState<State | null>(null);
  const [settings, setSettingsState] = useState<Settings | null>(null);
  const [status, setStatus] = useState<UpdateStatus | null>(null);
  const [log, setLog] = useState<string>("");
  const [showLog, setShowLog] = useState(false);
  const [showList, setShowList] = useState(false);
  const [reboot, setReboot] = useState<{ needed: boolean; reason: string | null }>({
    needed: false,
    reason: null,
  });
  const [busy, setBusy] = useState(false);
  const [lock, setLock] = useState<{ locked: boolean; live: boolean; age_min: number }>({
    locked: false,
    live: false,
    age_min: 0,
  });
  const [showSettings, setShowSettings] = useState(false);
  const [dismissedRun, setDismissedRun] = useState<number | null>(null);
  const [watchlistDraft, setWatchlistDraft] = useState("");
  const [pluginUpdates, setPluginUpdates] = useState<PluginUpdate[]>([]);
  const [toolUpdate, setToolUpdate] = useState<{ path: string } | null>(null);
  const [deckyPending, setDeckyPending] = useState<string[]>([]);

  const refreshAll = async () => {
    try {
      const [s, st, sett, rb, lk] = await Promise.all([
        getState(),
        updateStatus(),
        getSettings(),
        needsReboot(),
        lockState(),
      ]);
      setLock(lk);
      setPluginUpdates((s as any)?.plugin_updates ?? []);
      setToolUpdate((s as any)?.tool_update ?? null);
      setDeckyPending((s as any)?.decky_restart_pending ?? []);
      setBadge(badgeFromState(s && (s as any).checked_at ? s : null));
      setState(s && (s as any).checked_at ? s : null);
      setStatus(st);
      setSettingsState(sett);
      setWatchlistDraft(sett.watchlist);
      setReboot(rb);
      if (st.running || showLog) setLog(await getLog(60));
    } catch (e) {
      console.error("[System Updates] refresh failed", e);
    }
  };

  useEffect(() => {
    refreshAll();
    const onFinished = () => {
      refreshAll();
    };
    addEventListener<[LastRun]>("cachy_updates/finished", onFinished);
    return () => removeEventListener("cachy_updates/finished", onFinished);
  }, []);

  useEffect(() => {
    if (!status?.running) return;
    const handle = window.setInterval(async () => {
      try {
        const st = await updateStatus();
        setStatus(st);
        setLog(await getLog(60));
        if (!st.running) {
          setReboot(await needsReboot());
          await checkNow(false);
          setState(await getState());
        }
      } catch (e) {
        console.error("[System Updates] status poll failed", e);
      }
    }, 2000);
    return () => window.clearInterval(handle);
  }, [status?.running]);

  const patch = async (p: Partial<Settings>) => {
    const next = await setSettings(p);
    setSettingsState(next);
    setWatchlistDraft(next.watchlist);
  };

  const repoCount = state?.count ?? 0;
  const aurAll = state?.aur ?? [];
  const canInstallAur = settings?.install_aur ?? false;
  const total = repoCount + (canInstallAur ? aurAll.length : 0);
  const running = status?.running ?? false;
  const failed = !running && status?.last_rc != null && status.last_rc !== 0;
  const blocked = !!state?.blocking_news;
  const unreadNews = state?.news?.filter((n) => !n.seen) ?? [];
  const services = state?.services ?? [];
  const lastRun = state?.last_run ?? null;
  const aur = aurAll;
  // Show the outcome until acknowledged, so a finished run can't go unseen.
  const justFinished =
    lastRun && dismissedRun !== lastRun.finished ? lastRun : null;
  const dkms = state?.dkms ?? [];

  // One headline, in plain words, so the panel answers "am I fine?" instantly.
  let headline = "Checking…";
  let detail = "";
  if (state?.error) {
    headline = "Can't check right now";
    detail = state.error;
  } else if (running) {
    headline = phaseFromLog(log);
    detail = "You can leave this panel — it keeps going.";
  } else if (justFinished && justFinished.ok) {
    const n = justFinished.installed || justFinished.attempted;
    headline = `Finished — ${n} update${n === 1 ? "" : "s"} installed`;
    detail = justFinished.reboot
      ? "Restart to finish applying them."
      : justFinished.remaining > 0
        ? `${justFinished.remaining} still pending.`
        : "Everything is up to date.";
  } else if (lock.locked && !lock.live) {
    headline = "A previous update was interrupted";
    detail = "It left a lock behind. Clear it below, then try again.";
  } else if (failed) {
    headline = "That update didn't finish";
    detail = "Check the technical log below to see how far it got.";
  } else if (blocked) {
    headline = "Read this before updating";
    detail = "One of these updates needs a manual step.";
  } else if (total === 0) {
    headline =
      aur.length > 0 && !canInstallAur ? "System is up to date" : "You're up to date";
    detail =
      aur.length > 0 && !canInstallAur
        ? `${aur.length} AUR package${aur.length === 1 ? " has" : "s have"} updates — turn on AUR installing below, or run cachy-update in Desktop Mode.`
        : services.length > 0
          ? ""
          : `Last checked ${timeAgo(state?.checked_at)}.`;
  } else if ((state?.important?.length ?? 0) > 0) {
    headline = total === 1 ? "1 update ready" : `${total} updates ready`;
    detail = "Some of these are worth installing soon.";
  } else {
    headline = total === 1 ? "1 update ready" : `${total} updates ready`;
    detail = "All routine — install whenever suits you.";
  }

  const primaryLabel = running
    ? "Installing…"
    : blocked
      ? "Held until you mark the news read"
      : total > 0
        ? total === 1
          ? "Install 1 update"
          : `Install ${total} updates`
        : "Check again";

  const onPrimary = async () => {
    setBusy(true);
    try {
      if (total > 0 && !blocked) {
        const res = await startUpdate();
        if (!res.ok) {
          toaster.toast({ title: "Couldn't start", body: res.error ?? "Unknown error" });
        }
      } else {
        await checkNow(false);
      }
      await refreshAll();
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <PanelSection>
        <PanelSectionRow>
          <Field
            focusable={true}
            bottomSeparator={detail ? "none" : "standard"}
            childrenLayout="below"
          >
            <div style={{ fontSize: "1.1em", fontWeight: 600 }}>{headline}</div>
            {detail && (
              <div style={{ fontSize: "0.8em", opacity: 0.7, marginTop: "2px" }}>
                {detail}
              </div>
            )}
          </Field>
        </PanelSectionRow>

        <PanelSectionRow>
          <ButtonItem
            layout="below"
            disabled={busy || running || blocked || (lock.locked && !lock.live)}
            onClick={onPrimary}
          >
            {primaryLabel}
          </ButtonItem>
        </PanelSectionRow>

        {running && (
          <PanelSectionRow>
            <ButtonItem
              layout="below"
              onClick={async () => {
                await cancelUpdate();
                await refreshAll();
              }}
            >
              Stop
            </ButtonItem>
          </PanelSectionRow>
        )}
      </PanelSection>

      {pluginUpdates.length > 0 && (
        <PanelSection title="Your plugins">
          {pluginUpdates.map((p) => (
            <PanelSectionRow key={p.dir}>
              <Field
                label={p.name}
                description={
                  p.packages_only
                    ? `Needs ${(p.missing ?? []).join(", ")} installed`
                    : `${p.installed} → ${p.latest}`
                }
              />
            </PanelSectionRow>
          ))}
          <PanelSectionRow>
            <ButtonItem
              layout="below"
              disabled={busy || running}
              onClick={async () => {
                setBusy(true);
                try {
                  const res = await updatePlugins();
                  if (res.failed.length > 0) {
                    toaster.toast({
                      title: "Plugin update failed",
                      body: res.failed.map((f) => `${f.name}: ${f.error}`).join("; "),
                    });
                  }
                  await refreshAll();
                } finally {
                  setBusy(false);
                }
              }}
            >
              {pluginUpdates.length === 1 ? "Update plugin" : `Update ${pluginUpdates.length} plugins`}
            </ButtonItem>
          </PanelSectionRow>
        </PanelSection>
      )}

      {deckyPending.length > 0 && (
        <PanelSection title="Restart Decky">
          <PanelSectionRow>
            <Field
              label="Plugins updated"
              description={`${deckyPending.join(", ")} ${
                deckyPending.length === 1 ? "loads" : "load"
              } the new version after Decky restarts.${
                running ? " Wait for the system update to finish first." : ""
              }`}
            />
          </PanelSectionRow>
          <PanelSectionRow>
            <ButtonItem
              layout="below"
              disabled={busy || running}
              onClick={async () => {
                setBusy(true);
                try {
                  const res = await restartDecky();
                  if (!res.ok) {
                    toaster.toast({ title: "Restart Decky", body: res.message });
                  }
                  await refreshAll();
                } finally {
                  setBusy(false);
                }
              }}
            >
              Restart Decky now
            </ButtonItem>
          </PanelSectionRow>
        </PanelSection>
      )}

      {toolUpdate && (
        <PanelSection title="Setup tool">
          <PanelSectionRow>
            <Field
              label="bc250-setup has an update"
              description="Replaces the script (the old one is kept as .bak) and re-applies what it installed, so there's nothing to run afterwards."
            />
          </PanelSectionRow>
          <PanelSectionRow>
            <ButtonItem
              layout="below"
              disabled={busy}
              onClick={async () => {
                setBusy(true);
                try {
                  const res = await updateTool();
                  toaster.toast({
                    title: res.ok ? "Setup tool updated" : "Setup tool update failed",
                    body: res.message,
                  });
                  await refreshAll();
                } finally {
                  setBusy(false);
                }
              }}
            >
              Update setup tool
            </ButtonItem>
          </PanelSectionRow>
        </PanelSection>
      )}

      {/* Things that need a decision come before the package details. */}

      {unreadNews.length > 0 && (
        <PanelSection title="Heads up">
          {unreadNews.map((n) => (
            <PanelSectionRow key={n.title}>
              <Field focusable={true} bottomSeparator="none" childrenLayout="below">
                <div style={{ fontSize: "0.8em", lineHeight: "1.4em" }}>
                  {n.intervention && (
                    <div style={{ fontWeight: 600 }}>Needs a manual step</div>
                  )}
                  <div style={{ opacity: n.intervention ? 1 : 0.75 }}>{n.title}</div>
                </div>
              </Field>
            </PanelSectionRow>
          ))}
          {blocked && (
            <PanelSectionRow>
              <Field focusable={true} bottomSeparator="none">
                <span style={{ fontSize: "0.75em", opacity: 0.75 }}>
                  Read it in Desktop Mode with cachy-update -n, then mark it read here.
                  If it's about software you don't have, marking it read is fine.
                </span>
              </Field>
            </PanelSectionRow>
          )}
          <PanelSectionRow>
            <ButtonItem
              layout="below"
              disabled={busy}
              onClick={async () => {
                setBusy(true);
                try {
                  setState(await ackNews());
                  await refreshAll();
                } finally {
                  setBusy(false);
                }
              }}
            >
              Mark as read
            </ButtonItem>
          </PanelSectionRow>
        </PanelSection>
      )}

      {justFinished && (
        <PanelSection title={justFinished.ok ? "Last update" : "Last attempt"}>
          <PanelSectionRow>
            <Field focusable={true} bottomSeparator="none" childrenLayout="below">
              <div style={{ fontSize: "0.8em", lineHeight: "1.5em" }}>
                {justFinished.ok ? (
                  <>
                    <div>
                      {justFinished.installed || justFinished.attempted} installed,{" "}
                      {timeAgo(justFinished.finished)}.
                    </div>
                    {justFinished.reboot && (
                      <div style={{ opacity: 0.8 }}>
                        {justFinished.reboot_reason ??
                          "A restart is needed to finish."}
                      </div>
                    )}
                  </>
                ) : (
                  <div>
                    It stopped partway through. Nothing is half-installed — check the
                    technical log below, then try again.
                  </div>
                )}
              </div>
            </Field>
          </PanelSectionRow>
          {justFinished.ok && justFinished.reboot && (
            <PanelSectionRow>
              <ButtonItem layout="below" onClick={() => doReboot()}>
                Restart now
              </ButtonItem>
            </PanelSectionRow>
          )}
          <PanelSectionRow>
            <ButtonItem
              layout="below"
              onClick={() => setDismissedRun(justFinished.finished)}
            >
              {justFinished.ok && justFinished.reboot ? "Later" : "Dismiss"}
            </ButtonItem>
          </PanelSectionRow>
        </PanelSection>
      )}

      {reboot.needed && !justFinished && (
        <PanelSection title="Restart needed">
          <PanelSectionRow>
            <Field focusable={true} bottomSeparator="none">
              <span style={{ fontSize: "0.8em", opacity: 0.8 }}>
                Updates are installed, but a restart finishes them off.
              </span>
            </Field>
          </PanelSectionRow>
          <PanelSectionRow>
            <ButtonItem layout="below" onClick={() => doReboot()}>
              Restart now
            </ButtonItem>
          </PanelSectionRow>
        </PanelSection>
      )}

      {services.length > 0 && (
        <PanelSection title="Waiting on a restart">
          <PanelSectionRow>
            <Field focusable={true} bottomSeparator="none" childrenLayout="below">
              <div style={{ fontSize: "0.8em", opacity: 0.8, marginBottom: "4px" }}>
                These are still running the old version:
              </div>
              <div style={{ fontSize: "0.8em", lineHeight: "1.5em" }}>
                {services.map((s) => (
                  <div key={s}>{friendlyService(s)}</div>
                ))}
              </div>
            </Field>
          </PanelSectionRow>
          <PanelSectionRow>
            <ButtonItem
              layout="below"
              disabled={busy || running}
              onClick={async () => {
                setBusy(true);
                try {
                  const res = await restartServices(services);
                  toaster.toast({
                    title: "Restarted",
                    body: res.skipped.length
                      ? `${res.restarted.length} done, ${res.skipped.length} need a full restart`
                      : `${res.restarted.length} done`,
                  });
                  await checkNow(false);
                  await refreshAll();
                } finally {
                  setBusy(false);
                }
              }}
            >
              Restart these now
            </ButtonItem>
          </PanelSectionRow>
          <PanelSectionRow>
            <Field focusable={true} bottomSeparator="none">
              <span style={{ fontSize: "0.75em", opacity: 0.65 }}>
                Networking and Wi-Fi are skipped on purpose — restarting those would
                drop your connection. A full restart handles them safely.
              </span>
            </Field>
          </PanelSectionRow>
        </PanelSection>
      )}

      {aur.length > 0 && (
        <PanelSection title="AUR packages">
          <PanelSectionRow>
            <Field focusable={true} bottomSeparator="none" childrenLayout="below">
              <div style={{ fontSize: "0.8em", lineHeight: "1.5em" }}>
                {aur.map((a) => (
                  <div key={a.name}>
                    {a.name}{" "}
                    <span style={{ opacity: 0.6 }}>
                      {a.vcs ? "new commits" : a.new}
                    </span>
                  </div>
                ))}
                {aur.some((a) => a.vcs) && (
                  <div style={{ opacity: 0.65, marginTop: "6px" }}>
                    "New commits" means newer code is available upstream. You're
                    told once per version, not on every check.
                  </div>
                )}
              </div>
            </Field>
          </PanelSectionRow>
          <PanelSectionRow>
            <Field focusable={true} bottomSeparator="none">
              <span style={{ fontSize: "0.75em", opacity: 0.65 }}>
                {canInstallAur
                  ? "These build from source when you install, so an update takes longer than usual. A package that fails to build is skipped — the rest still install."
                  : "Not installed from here yet — turn on AUR installing in Options, or run cachy-update in Desktop Mode."}
              </span>
            </Field>
          </PanelSectionRow>
        </PanelSection>
      )}

      {dkms.length > 0 && (
        <PanelSection title="Driver problem">
          <PanelSectionRow>
            <Field focusable={true} bottomSeparator="none">
              <span style={{ fontSize: "0.8em", opacity: 0.85 }}>
                A driver didn't rebuild for your current kernel, so whatever it
                controls — sensors, fan speed — may not work. Worth a look in Desktop
                Mode.
              </span>
            </Field>
          </PanelSectionRow>
        </PanelSection>
      )}

      {/* Detail lives behind a tap, so the panel stays scannable. */}
      {(total > 0 || (state?.flatpak?.length ?? 0) > 0) && (
        <PanelSection title="Details">
          <PanelSectionRow>
            <ButtonItem layout="below" onClick={() => setShowList(!showList)}>
              {showList ? "Hide the list" : "See what's included"}
            </ButtonItem>
          </PanelSectionRow>
          {showList && (
            <PanelSectionRow>
              <Field focusable={true} bottomSeparator="none" childrenLayout="below">
                <div style={{ fontSize: "0.75em", lineHeight: "1.5em" }}>
                  {(state?.important?.length ?? 0) > 0 && (
                    <div style={{ opacity: 0.7, marginBottom: "2px" }}>
                      Worth knowing about:
                    </div>
                  )}
                  {state?.important?.slice(0, 10).map((p) => (
                    <div key={p.name}>
                      {p.name}
                      {p.flags?.includes("security") ? " — security fix" : ""}
                    </div>
                  ))}
                  {(state?.important?.length ?? 0) > 0 && (
                    <div style={{ opacity: 0.7, marginTop: "6px" }}>
                      Plus {total - (state?.important?.length ?? 0)} routine packages.
                    </div>
                  )}
                  {(state?.important?.length ?? 0) === 0 && (
                    <div style={{ opacity: 0.7 }}>{total} routine packages.</div>
                  )}
                  {(state?.flatpak?.length ?? 0) > 0 && (
                    <div style={{ marginTop: "6px" }}>
                      {state!.flatpak.length} app{state!.flatpak.length === 1 ? "" : "s"}{" "}
                      will update too.
                    </div>
                  )}
                </div>
              </Field>
            </PanelSectionRow>
          )}
        </PanelSection>
      )}

      <PanelSection title="Options">
        <PanelSectionRow>
          <ButtonItem layout="below" onClick={() => setShowSettings(!showSettings)}>
            {showSettings ? "Done" : "When should I be told?"}
          </ButtonItem>
        </PanelSectionRow>

        {showSettings && settings && (
          <>
            <PanelSectionRow>
              <Field focusable={true} bottomSeparator="none">
                <span style={{ fontSize: "0.75em", opacity: 0.7 }}>
                  Everything still shows up here. These only control what interrupts
                  you with a notification. Security fixes always do.
                </span>
              </Field>
            </PanelSectionRow>
            <PanelSectionRow>
              <ToggleField
                label="Important software"
                description="Kernel, graphics, audio, Steam"
                checked={settings.notify_watchlist}
                onChange={(v) => patch({ notify_watchlist: v })}
              />
            </PanelSectionRow>
            <PanelSectionRow>
              <ToggleField
                label="Big version jumps"
                checked={settings.notify_major}
                onChange={(v) => patch({ notify_major: v })}
              />
            </PanelSectionRow>
            <PanelSectionRow>
              <ToggleField
                label="Updates needing manual steps"
                description="Also holds the install button until you've read it"
                checked={settings.notify_news}
                onChange={(v) => patch({ notify_news: v, block_on_intervention: v })}
              />
            </PanelSectionRow>
            <PanelSectionRow>
              <ToggleField
                label="AUR updates"
                checked={settings.notify_aur}
                onChange={(v) => patch({ notify_aur: v })}
              />
            </PanelSectionRow>
            {settings.notify_aur && (
              <PanelSectionRow>
                <ToggleField
                  label="Include -git packages"
                  description="Your BC250 control center and sensor driver"
                  checked={settings.notify_aur_devel}
                  onChange={(v) => patch({ notify_aur_devel: v })}
                />
              </PanelSectionRow>
            )}
            <PanelSectionRow>
              <ToggleField
                label="Install AUR packages too"
                description="Builds from source. Only enable if you trust the packages you have — AUR code isn't reviewed."
                checked={settings.install_aur}
                onChange={(v) => patch({ install_aur: v })}
              />
            </PanelSectionRow>
            <PanelSectionRow>
              <ToggleField
                label="Something needs restarting"
                checked={settings.notify_services}
                onChange={(v) => patch({ notify_services: v })}
              />
            </PanelSectionRow>
            <PanelSectionRow>
              <ToggleField
                label="Driver problems"
                checked={settings.notify_dkms}
                onChange={(v) => patch({ notify_dkms: v })}
              />
            </PanelSectionRow>
            <PanelSectionRow>
              <ToggleField
                label="Unusually large batches"
                checked={settings.notify_volume}
                onChange={(v) => patch({ notify_volume: v })}
              />
            </PanelSectionRow>
            <PanelSectionRow>
              <ToggleField
                label="If I've put it off too long"
                description={`After ${settings.stale_days} days`}
                checked={settings.notify_stale}
                onChange={(v) => patch({ notify_stale: v })}
              />
            </PanelSectionRow>
            <PanelSectionRow>
              <ToggleField
                label="Stay quiet during games"
                description="Holds notifications until you're back at the library"
                checked={settings.hold_in_game}
                onChange={(v) => patch({ hold_in_game: v })}
              />
            </PanelSectionRow>
            <PanelSectionRow>
              <ToggleField
                label="Include apps"
                description="Flatpak apps update alongside the system"
                checked={settings.include_flatpak}
                onChange={(v) => patch({ include_flatpak: v })}
              />
            </PanelSectionRow>
            <PanelSectionRow>
              <SliderField
                label="Check every"
                value={settings.poll_hours}
                min={1}
                max={24}
                step={1}
                showValue={true}
                valueSuffix=" h"
                onChange={(v) => patch({ poll_hours: v })}
              />
            </PanelSectionRow>
          </>
        )}
      </PanelSection>

      {/* Log stays last and closed — it's for when something breaks. */}
      <PanelSection title="Troubleshooting">
        {lock.locked && (
          <>
            <PanelSectionRow>
              <Field focusable={true} bottomSeparator="none">
                <span style={{ fontSize: "0.8em", opacity: 0.85 }}>
                  {lock.live
                    ? "An update is running right now. Let it finish."
                    : `An interrupted update left a lock file behind (${lock.age_min} min ago). Nothing is broken — clearing it lets you retry.`}
                </span>
              </Field>
            </PanelSectionRow>
            <PanelSectionRow>
              <ButtonItem
                layout="below"
                disabled={busy || lock.live}
                onClick={async () => {
                  setBusy(true);
                  try {
                    const res = await clearLock();
                    toaster.toast({ title: "Lock", body: res.message });
                    await refreshAll();
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                Clear leftover lock
              </ButtonItem>
            </PanelSectionRow>
          </>
        )}
        <PanelSectionRow>
          <ButtonItem
            layout="below"
            onClick={async () => {
              const next = !showLog;
              setShowLog(next);
              if (next) setLog(await getLog(60));
            }}
          >
            {showLog ? "Hide the technical log" : "Show the technical log"}
          </ButtonItem>
        </PanelSectionRow>
        {showLog && (
          <>
            <PanelSectionRow>
              <Field focusable={true} bottomSeparator="none">
                <pre
                  style={{
                    fontSize: "0.65em",
                    lineHeight: "1.25em",
                    whiteSpace: "pre-wrap",
                    wordBreak: "break-all",
                    maxHeight: "220px",
                    overflowY: "scroll",
                    margin: 0,
                  }}
                >
                  {log || "Nothing yet — this fills in during an update."}
                </pre>
              </Field>
            </PanelSectionRow>
            <PanelSectionRow>
              <Field label="Advanced" focusable={true} bottomSeparator="none" childrenLayout="below">
                <div style={{ fontSize: "0.75em", opacity: 0.7, marginBottom: "4px" }}>
                  Which software counts as important, as a comma-separated list.
                </div>
                <TextField
                  value={watchlistDraft}
                  onChange={(e) => setWatchlistDraft(e.target.value)}
                  onBlur={() => patch({ watchlist: watchlistDraft })}
                />
              </Field>
            </PanelSectionRow>
            <PanelSectionRow>
              <ButtonItem
                layout="below"
                onClick={async () => {
                  const next = await resetWatchlist();
                  setSettingsState(next);
                  setWatchlistDraft(next.watchlist);
                }}
              >
                Reset that list
              </ButtonItem>
            </PanelSectionRow>
          </>
        )}
      </PanelSection>
    </>
  );
}

function UpdateIcon() {
  const b = useBadge();
  return (
    <div style={{ position: "relative", display: "inline-flex", alignItems: "center" }}>
      <BaseIcon />
      {b.count > 0 && (
        <span
          style={{
            position: "absolute",
            top: "-4px",
            right: "-7px",
            minWidth: "14px",
            height: "14px",
            padding: "0 3px",
            borderRadius: "7px",
            background: b.attention ? "#e0a03a" : "#4c5b6b",
            color: b.attention ? "#1a1a1a" : "#ffffff",
            fontSize: "9px",
            fontWeight: 700,
            lineHeight: "14px",
            textAlign: "center",
            boxSizing: "border-box",
          }}
        >
          {b.count > 99 ? "99+" : b.count}
        </span>
      )}
    </div>
  );
}

function TitleView() {
  const b = useBadge();
  return (
    <div className={staticClasses.Title} style={{ display: "flex", alignItems: "center" }}>
      <span>System Updates</span>
      <BadgePill {...b} />
    </div>
  );
}

function BaseIcon() {
  return (
    <svg
      width="1em"
      height="1em"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 3v12" />
      <path d="m7 12 5 5 5-5" />
      <path d="M5 21h14" />
    </svg>
  );
}

export default definePlugin(() => {
  const pending: { title: string; body: string }[] = [];
  let flushTimer: number | undefined;
  let badgeTimer: number | undefined;

  const inGame = (): boolean => {
    try {
      return !!(Router as any)?.MainRunningApp;
    } catch {
      return false;
    }
  };

  const flush = () => {
    if (inGame() || pending.length === 0) return;
    const item = pending.shift()!;
    pending.length = 0;
    toaster.toast({ title: item.title, body: item.body, duration: 8000 });
  };

  const onNotify = async (payload: { title: string; body: string }) => {
    let hold = true;
    try {
      hold = (await getSettings()).hold_in_game;
    } catch {
      /* default to holding */
    }
    if (hold && inGame()) {
      pending.push(payload);
      return;
    }
    toaster.toast({ title: payload.title, body: payload.body, duration: 8000 });
  };

  addEventListener<[{ title: string; body: string }]>("cachy_updates/notify", onNotify);
  flushTimer = window.setInterval(flush, 30000);

  // get_state is just the cached result, so polling it is cheap - it never
  // triggers a pacman call.
  const syncBadge = async () => {
    try {
      const s = await getState();
      setBadge(badgeFromState(s && (s as any).checked_at ? s : null));
    } catch {
      /* loader may not be ready yet */
    }
  };
  syncBadge();
  badgeTimer = window.setInterval(syncBadge, 60000);

  return {
    name: "System Updates",
    titleView: <TitleView />,
    content: <Content />,
    icon: <UpdateIcon />,
    onDismount() {
      removeEventListener("cachy_updates/notify", onNotify);
      if (flushTimer) window.clearInterval(flushTimer);
      if (badgeTimer) window.clearInterval(badgeTimer);
    },
  };
});
