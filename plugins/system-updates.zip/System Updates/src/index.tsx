import {
  ButtonItem,
  DialogButton,
  Field,
  Focusable,
  GamepadButton,
  PanelSection,
  PanelSectionRow,
  Router,
  SliderField,
  TextField,
  ToggleField,
  staticClasses,
} from "@decky/ui";
import {
  addEventListener,
  removeEventListener,
  callable,
  definePlugin,
  toaster,
} from "@decky/api";
import { useEffect, useState, type ReactNode } from "react";

interface Pkg {
  name: string;
  old: string;
  new: string;
  flags?: string[];
}

interface Reason {
  kind: string;
  text: string;
}

interface NewsItem {
  title: string;
  intervention: boolean;
  seen: boolean;
}

interface State {
  checked_at: number;
  error: string | null;
  count: number;
  packages: Pkg[];
  important: Pkg[];
  reasons: Reason[];
  flatpak: string[];
  security: { name: string; severity: string }[];
  services?: string[];
  dkms?: string[];
  news?: NewsItem[];
  aur?: { name: string; old: string; new: string; vcs: boolean }[];
  aur_installed?: { name: string; version: string }[];
  blocking_news?: boolean;
  last_run?: LastRun | null;
  stale_days_since?: number | null;
  plugin_updates?: PluginUpdate[];
  plugin_error?: string | null;
  tool_update?: { path: string; blob: string } | null;
  decky_restart_pending?: string[];
}

interface PluginUpdate {
  dir: string;
  name: string;
  installed: string;
  latest: string;
  packages_only?: boolean;
  missing?: string[];
}

interface Component {
  id: string;
  name: string;
  note: string;
  update: boolean;
  remote?: string | null;
}

interface LastRun {
  finished: number;
  rc: number | null;
  ok: boolean;
  cancelled?: boolean;
  packages_done?: boolean;
  installed: number;
  attempted: number;
  remaining: number;
  reboot: boolean;
  reboot_reason: string | null;
}

interface Settings {
  poll_hours: number;
  notify_watchlist: boolean;
  notify_major: boolean;
  notify_volume: boolean;
  volume_threshold: number;
  notify_stale: boolean;
  stale_days: number;
  notify_services: boolean;
  notify_dkms: boolean;
  include_aur: boolean;
  notify_aur: boolean;
  notify_aur_devel: boolean;
  install_aur: boolean;
  notify_news: boolean;
  news_count: number;
  block_on_intervention: boolean;
  hold_in_game: boolean;
  include_flatpak: boolean;
  steamgriddb_key: string;
  show_setup_tools: boolean;
  watchlist: string;
  cooldown_hours: number;
}

interface UpdateStatus {
  running: boolean;
  active: string;
  cancelling?: boolean;
  // percent is null while there's no way to tell how far along it is.
  progress?: { label: string; percent: number | null } | null;
  // pacman is alive, whether or not this plugin's update started it.
  pacman_live?: boolean;
  last_rc: number | null;
  cancelled?: boolean;
  packages_done?: boolean;
  finished_at: number | null;
}

const checkNow = callable<[boolean], State>("check_now");
const updatePlugins = callable<
  [],
  { ok: boolean; updated: string[]; failed: { name: string; error: string }[] }
>("update_plugins");
const restartDecky = callable<[], { ok: boolean; message: string }>("restart_decky");
const updateComponents = callable<[], { ok: boolean; message: string }>("update_components");
const getState = callable<[], State>("get_state");
const startUpdate = callable<[], { ok: boolean; error?: string }>("start_update");
const cancelUpdate = callable<[], { ok: boolean; message: string }>("cancel_update");
const updateStatus = callable<[], UpdateStatus>("update_status");
const getLog = callable<[number], string>("get_log");
const getSettings = callable<[], Settings>("get_settings");
const setSettings = callable<[Partial<Settings>], Settings>("set_settings");
const resetWatchlist = callable<[], Settings>("reset_watchlist");
const needsReboot = callable<[], { needed: boolean; reason: string | null }>("needs_reboot");
const doReboot = callable<[], { ok: boolean }>("do_reboot");
const restartServices = callable<
  [string[]],
  { restarted: string[]; skipped: string[]; failed: string[] }
>("restart_services");
const ackNews = callable<[], State>("ack_news");
const lockState = callable<[], { locked: boolean; live: boolean; age_min: number }>("lock_state");
const clearLock = callable<[], { ok: boolean; message: string }>("clear_lock");

interface ShortcutWant {
  key: string;
  name: string;
  exe: string;
  start_dir: string;
  appid: number | null;
  found: { appid: number; ours: boolean }[];
  listed: boolean;
}
const steamShortcutPlan = callable<
  [number | null],
  { want: ShortcutWant[]; drop: { key: string; name: string; appid: number; copies: number[] }[] }
>("steam_shortcut_plan");
const steamShortcutRecord = callable<[string, number | null], boolean>("steam_shortcut_record");
const steamArtDownload = callable<[string, string], Record<string, { b64?: string; path?: string; ext: string }>>("steam_art_download");
const steamArtSource = callable<[string], { b64: string; path: string } | null>("steam_art_source");
const ART_COLORS: Record<string, string> = {
    atv: "#2e7d32",
    xcloud: "#107c10",
    gfn: "#76b900",
    discord: "#5865f2",
};
function loadImage(b64: string): Promise<HTMLImageElement> {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = () => reject(new Error("icon would not load"));
        img.src = "data:image/png;base64," + b64;
    });
}
// Library art drawn from the app's own icon: a gradient in the app's colour,
// the icon and the name. kind: 0 capsule, 1 hero, 2 logo, 3 wide capsule.
function drawArt(kind: number, size: number[], color: string, name: string, icon: HTMLImageElement): string {
    const [W, H] = size;
    const c = document.createElement("canvas");
    c.width = W;
    c.height = H;
    const g = c.getContext("2d")!;
    if (kind !== 2) {
        const bg = g.createLinearGradient(0, 0, W, H);
        bg.addColorStop(0, color);
        bg.addColorStop(1, "#0b0e12");
        g.fillStyle = bg;
        g.fillRect(0, 0, W, H);
    }
    const label = (px: number, x: number, y: number, align: CanvasTextAlign) => {
        g.font = `600 ${px}px sans-serif`;
        g.textAlign = align;
        g.textBaseline = "middle";
        g.fillStyle = "#ffffff";
        g.shadowColor = "rgba(0,0,0,0.55)";
        g.shadowBlur = px / 6;
        g.fillText(name, x, y, W * 0.9);
        g.shadowBlur = 0;
    };
    if (kind === 0) {
        const s = W * 0.62;
        g.drawImage(icon, (W - s) / 2, H * 0.2, s, s);
        label(W * 0.095, W / 2, H * 0.2 + s + H * 0.09, "center");
    }
    else if (kind === 3) {
        const s = H * 0.56;
        g.drawImage(icon, W * 0.08, (H - s) / 2, s, s);
        label(H * 0.14, W * 0.08 + s + W * 0.04, H / 2, "left");
    }
    else if (kind === 1) {
        g.globalAlpha = 0.35;
        const s = H * 1.5;
        g.drawImage(icon, W - s * 0.85, (H - s) / 2, s, s);
        g.globalAlpha = 1;
    }
    else {
        const s = H * 0.8;
        g.drawImage(icon, 0, (H - s) / 2, s, s);
        label(H * 0.4, s + H * 0.12, H / 2, "left");
    }
    return c.toDataURL("image/png").split(",")[1];
}
// Give a shortcut we just created library art and an icon. Skipped when the
// app has no icon installed; shortcuts that already existed are left alone.
async function applyArt(apps: any, appid: number, key: string, name: string) {
    try {
        // Top-rated art from SteamGridDB where it can be fetched; anything
        // missing is drawn from the app's own icon.
        const online = await steamArtDownload(key, name).catch(
            () => ({}) as Record<string, { b64?: string; path?: string; ext: string }>,
        );
        const src = await steamArtSource(key);
        const icon = src ? await loadImage(src.b64) : null;
        const color = ART_COLORS[key] ?? "#37474f";
        const sizes: [number, number[]][] = [[0, [600, 900]], [3, [920, 430]], [1, [1920, 620]], [2, [960, 240]]];
        for (const [kind, size] of sizes) {
            const got = online[String(kind)];
            if (got?.b64) {
                await apps.SetCustomArtworkForApp(appid, got.b64, got.ext, kind);
            }
            else if (icon) {
                await apps.SetCustomArtworkForApp(appid, drawArt(kind, size, color, name, icon), "png", kind);
            }
        }
        if (apps.SetShortcutIcon && (online["4"]?.path || src))
            apps.SetShortcutIcon(appid, online["4"]?.path ?? src!.path);
    }
    catch (e) {
        console.error("[System Updates] library art failed", e);
    }
}

// Re-fetch art for every app shortcut already in the library (the panel's
// "Fetch library art" button). Replaces whatever art those shortcuts have.
async function refreshArt(): Promise<number> {
  const w = window as any;
  const apps = w.SteamClient?.Apps;
  if (!apps?.SetCustomArtworkForApp) return 0;
  const plan = await steamShortcutPlan(steamAccountId());
  let n = 0;
  for (const s of plan.want) {
    if (s.appid && w.appStore?.GetAppOverviewByAppID?.(s.appid)) {
      await applyArt(apps, s.appid, s.key, s.name);
      n++;
    }
  }
  return n;
}

// The signed-in Steam account's id, which names its userdata folder.
function steamAccountId(): number | null {
  try {
    const id = (window as any).App?.m_CurrentUser?.strSteamID;
    return id ? Number(BigInt(id) - 76561197960265728n) : null;
  } catch {
    return null;
  }
}

// Put launchers the setup tool installed (Android TV, cloud gaming apps) in the Steam library,
// and take them back out when the setup tool removes them. A shortcut you
// already made with the same name is adopted rather than duplicated, and
// extra copies of one we made are removed. Steam's shortcut list on disk is
// checked as well as the library, which can still be loading after boot.
let shortcutSyncRunning = false;
async function syncShortcuts() {
  if (shortcutSyncRunning) return;
  shortcutSyncRunning = true;
  try {
    await syncShortcutsOnce();
  } finally {
    shortcutSyncRunning = false;
  }
}

async function syncShortcutsOnce() {
  const w = window as any;
  const apps = w.SteamClient?.Apps;
  if (!apps?.AddShortcut) return;
  const plan = await steamShortcutPlan(steamAccountId());
  const exists = (id: number | null) => !!(id && w.appStore?.GetAppOverviewByAppID?.(id));
  const byName = (name: string): number | null => {
    try {
      // Non-Steam shortcuts don't all show up in one list on every client
      // version, so look through each place they can be.
      const lists: any[][] = [
        w.collectionStore?.deckDesktopApps?.allApps,
        w.collectionStore?.allAppsCollection?.allApps,
        w.appStore?.allApps,
      ].filter(Array.isArray);
      for (const list of lists) {
        const hit = list.find((a: any) => (a.display_name ?? "").toLowerCase() === name.toLowerCase());
        if (hit?.appid) return hit.appid;
      }
      return null;
    } catch {
      return null;
    }
  };
  for (const s of plan.want) {
    // Keep the one we recorded, else one pointing at our launcher, else one
    // you made with the same name. Other copies of our launcher go.
    const ours = s.found.filter((f) => f.ours).map((f) => f.appid);
    let appid: number | null = null;
    if (s.appid && (exists(s.appid) || s.found.some((f) => f.appid === s.appid))) appid = s.appid;
    else if (ours.length) appid = ours[0];
    else if (s.found.length) appid = s.found[0].appid;
    else appid = byName(s.name);
    for (const extra of ours) {
      if (extra !== appid) {
        apps.RemoveShortcut(extra);
        console.log(`[System Updates] removed duplicate ${s.name} shortcut ${extra}`);
      }
    }
    if (appid) {
      if (appid !== s.appid) await steamShortcutRecord(s.key, appid);
      continue;
    }
    // Nothing on disk or in the library. If the list on disk couldn't be
    // read, only add once the library has loaded, so a slow start after
    // boot doesn't look like a missing shortcut.
    if (!s.listed && !(w.appStore?.allApps?.length > 0)) continue;
    appid = await apps.AddShortcut(s.name, s.exe, "", "");
    if (!appid) continue;
    apps.SetShortcutName(appid, s.name);
    apps.SetShortcutExe(appid, JSON.stringify(s.exe));
    apps.SetShortcutStartDir(appid, JSON.stringify(s.start_dir));
    await steamShortcutRecord(s.key, appid);
    await applyArt(apps, appid, s.key, s.name);
    toaster.toast({ title: "Added to your library", body: s.name, duration: 6000 });
  }
  for (const d of plan.drop) {
    if (exists(d.appid)) apps.RemoveShortcut(d.appid);
    for (const copy of d.copies) if (copy !== d.appid) apps.RemoveShortcut(copy);
    await steamShortcutRecord(d.key, null);
  }
}

/** Service unit names mean nothing to most people mid-game. */
const SERVICE_LABELS: Record<string, string> = {
  "NetworkManager.service": "Networking",
  "wpa_supplicant.service": "Wi-Fi",
  "systemd-resolved.service": "DNS lookups",
  "systemd-udevd.service": "Device detection",
  "sshd.service": "Remote login",
  "udisks2.service": "Drive mounting",
  "upower.service": "Battery and power",
  "input-remapper.service": "Controller remapping",
  "bluetooth.service": "Bluetooth",
  "cups.service": "Printing",
};

const friendlyService = (unit: string): string =>
  SERVICE_LABELS[unit] ?? unit.replace(/\.(service|socket|timer)$/, "");


/**
 * The icon and title are mounted once by Decky and live outside <Content>, so
 * they need their own tiny store rather than component state.
 */
interface Badge {
  count: number;
  attention: boolean;
}

let badge: Badge = { count: 0, attention: false };
const badgeSubs = new Set<(b: Badge) => void>();

function setBadge(next: Badge) {
  if (next.count === badge.count && next.attention === badge.attention) return;
  badge = next;
  badgeSubs.forEach((fn) => fn(badge));
}

function badgeFromState(s: State | null): Badge {
  if (!s || s.error) return { count: 0, attention: false };
  const attention =
    !!s.blocking_news ||
    (s.important?.length ?? 0) > 0 ||
    (s.services?.length ?? 0) > 0 ||
    (s.dkms?.length ?? 0) > 0;
  return { count: s.count ?? 0, attention };
}

function useBadge(): Badge {
  const [b, setB] = useState<Badge>(badge);
  useEffect(() => {
    badgeSubs.add(setB);
    return () => {
      badgeSubs.delete(setB);
    };
  }, []);
  return b;
}

function BadgePill({ count, attention }: Badge) {
  if (count <= 0) return null;
  return (
    <span
      style={{
        marginLeft: "6px",
        padding: "0 6px",
        borderRadius: "10px",
        fontSize: "0.7em",
        fontWeight: 700,
        lineHeight: "1.5em",
        display: "inline-block",
        minWidth: "1.1em",
        textAlign: "center",
        background: attention ? "#e0a03a" : "#4c5b6b",
        color: attention ? "#1a1a1a" : "#ffffff",
      }}
    >
      {count > 99 ? "99+" : count}
    </span>
  );
}

function timeAgo(ts?: number): string {
  if (!ts) return "not yet";
  const mins = Math.floor((Date.now() / 1000 - ts) / 60);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

/** Turn raw pacman output into one line a person can read at a glance. */
function phaseFromLog(log: string): string {
  const lines = log.trim().split("\n").reverse();
  for (const line of lines) {
    if (line.includes("flatpak (user)")) return "Updating apps…";
    if (line.includes("flatpak (system)")) return "Updating apps…";
    if (/^\s*installing|reinstalling|upgrading/i.test(line)) return "Installing…";
    if (/checking (keys|package integrity|for file conflicts)/i.test(line))
      return "Verifying downloads…";
    if (/^\s*downloading|retrieving packages/i.test(line)) return "Downloading…";
    if (line.includes("refreshing keyrings")) return "Refreshing keys…";
    if (line.includes("pacman -Syu")) return "Starting…";
  }
  return "Working…";
}

// Drawn by hand: Steam's ProgressBarWithInfo sits off-centre in this panel.
function UpdateProgress({ label, percent }: { label: string; percent: number | null }) {
  const known = percent != null;
  return (
    <div style={{ width: "100%", boxSizing: "border-box", padding: "4px 0 8px" }}>
      <style>{`@keyframes cachy-updates-slide {
        from { transform: translateX(-100%); } to { transform: translateX(350%); } }`}</style>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          fontSize: "0.8em",
          opacity: 0.8,
          marginBottom: "6px",
        }}
      >
        <span>{label}</span>
        {known && <span>{percent}%</span>}
      </div>
      <div
        style={{
          width: "100%",
          height: "6px",
          borderRadius: "3px",
          background: "rgba(255, 255, 255, 0.15)",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            height: "100%",
            borderRadius: "3px",
            background: "#1a9fff",
            width: known ? `${percent}%` : "30%",
            transition: known ? "width 1s ease-out" : undefined,
            animation: known ? undefined : "cachy-updates-slide 1.4s ease-in-out infinite",
          }}
        />
      </div>
    </div>
  );
}

const TAB_UPDATES = "updates";
const TAB_TOOLS = "tools";
// Kept while Steam runs, so the panel reopens on the tab you left it on.
let lastTab = TAB_UPDATES;

const LOG_STYLE = {
  fontSize: "0.65em",
  lineHeight: "1.25em",
  whiteSpace: "pre-wrap",
  wordBreak: "break-all",
  maxHeight: "220px",
  overflowY: "scroll",
  margin: 0,
} as const;

// Same tab bar as BC-250 Lighting, so the two panels feel alike.
function TabBar({ tab, onTab, badge }: { tab: string; onTab: (t: string) => void; badge: number }) {
  const tabs = [
    { id: TAB_UPDATES, label: "Updates" },
    { id: TAB_TOOLS, label: "Tools" },
  ];
  return (
    <Focusable
      style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "4px", padding: "0 0 8px" }}
      flow-children="horizontal"
    >
      {tabs.map((t) => (
        <DialogButton
          key={t.id}
          onClick={() => onTab(t.id)}
          style={{
            minWidth: 0,
            padding: "6px 0",
            fontSize: "0.9em",
            background: t.id === tab ? "#1a9fff" : undefined,
            color: t.id === tab ? "#ffffff" : undefined,
          }}
        >
          {t.label}
          {t.id === TAB_UPDATES && badge > 0 && (
            <span
              style={{
                marginLeft: "6px",
                padding: "0 6px",
                borderRadius: "8px",
                fontSize: "0.8em",
                fontWeight: 700,
                background: t.id === tab ? "#ffffff" : "#e0a03a",
                color: t.id === tab ? "#1a9fff" : "#1a1a1a",
              }}
            >
              {badge > 99 ? "99+" : badge}
            </span>
          )}
        </DialogButton>
      ))}
    </Focusable>
  );
}

function SubHead({ children }: { children: ReactNode }) {
  return (
    <PanelSectionRow>
      <div
        style={{
          fontSize: "0.7em",
          fontWeight: 600,
          letterSpacing: "0.08em",
          textTransform: "uppercase",
          opacity: 0.6,
          padding: "8px 0 2px",
        }}
      >
        {children}
      </div>
    </PanelSectionRow>
  );
}

// One kind of update: a press opens the names inside.
function Group(props: {
  title: string;
  summary: string;
  count: number | string;
  open: boolean;
  onToggle: () => void;
  children: ReactNode;
  // rows: children are PanelSectionRows with their own buttons.
  rows?: boolean;
  dot?: string;
}) {
  return (
    <>
      <PanelSectionRow>
        <ButtonItem layout="below" onClick={props.onToggle}>
          <div style={{ display: "flex", alignItems: "center", gap: "8px", width: "100%" }}>
            {props.dot && (
              <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: props.dot, flex: "none" }} />
            )}
            <div style={{ flex: 1, minWidth: 0, textAlign: "left" }}>
              <div>{props.title}</div>
              <div style={{ fontSize: "0.75em", opacity: 0.6, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {props.summary}
              </div>
            </div>
            <span style={{ fontSize: "0.85em", opacity: 0.75 }}>
              {props.count === "" ? "" : `${props.count} `}{props.open ? "▾" : "›"}
            </span>
          </div>
        </ButtonItem>
      </PanelSectionRow>
      {props.open && props.rows && props.children}
      {props.open && !props.rows && (
        <PanelSectionRow>
          <Field focusable={true} bottomSeparator="none" childrenLayout="below">
            <div style={{ fontSize: "0.75em", lineHeight: "1.5em" }}>{props.children}</div>
          </Field>
        </PanelSectionRow>
      )}
    </>
  );
}

interface SetupJob {
  running: boolean;
  meta: { action: string; option: string; name: string; started: number } | null;
  rc: number | null;
  log: string;
}
interface SetupOptions {
  available: boolean;
  options: { id: string; name: string; installed: boolean }[];
  job: SetupJob;
}
const setupOptions = callable<[], SetupOptions>("setup_options");
const setupRun = callable<[string, string], { ok: boolean; message: string }>("setup_run");
const setupJob = callable<[number], SetupJob>("setup_job");

// The setup tool's options, grouped so the Tools tab stays short.
const SETUP_GROUPS = [
  { id: "tv", title: "TV and controller", summary: "HDMI-CEC, Guide button, Steam Link 1080p", ids: ["cec", "guide", "streamres"] },
  { id: "apps", title: "Apps in your library", summary: "Android TV, Xbox Cloud, GeForce NOW, Discord, JDownloader", ids: ["atv", "xcloud", "gfn", "discord", "jd"] },
  { id: "system", title: "System", summary: "LED strip, sleep off, quick boot, Claude Code", ids: ["led", "power", "boot", "claude"] },
  { id: "aur", title: "AUR (opt-in)", summary: "BC-250 Control Center, built from source", ids: ["ctlcenter"] },
];

function jobTitle(meta: SetupJob["meta"]): string {
  if (!meta) return "";
  switch (meta.action) {
    case "install":
      return `Installing ${meta.name}`;
    case "remove":
      return `Removing ${meta.name}`;
    case "install-all":
      return "Installing everything";
    case "status":
      return "Status check";
    case "test-cec":
      return "HDMI-CEC test";
    default:
      return meta.action;
  }
}

// The setup tool's menu, run from here. Nothing is asked: every question the
// terminal would ask takes its default, and removing keeps your data.
function SetupTools({ onFinished }: { onFinished: () => Promise<void> }) {
  const [data, setData] = useState<SetupOptions | null>(null);
  const [armed, setArmed] = useState<string | null>(null);
  const [showOutput, setShowOutput] = useState(true);
  const [seenJob, setSeenJob] = useState<number | null>(null);
  const [open, setOpen] = useState<Record<string, boolean>>({});

  const load = async () => {
    try {
      setData(await setupOptions());
    } catch (e) {
      console.error("[System Updates] setup options failed", e);
    }
  };
  useEffect(() => {
    load();
  }, []);

  const running = !!data?.job.running;
  useEffect(() => {
    if (!running) return;
    const handle = window.setInterval(async () => {
      try {
        const job = await setupJob(40);
        if (!job.running) {
          await load();
          // New launchers show up in the library right away.
          syncShortcuts().catch(() => {});
          await onFinished();
        } else {
          setData((d) => (d ? { ...d, job } : d));
        }
      } catch (e) {
        console.error("[System Updates] setup job poll failed", e);
      }
    }, 2000);
    return () => window.clearInterval(handle);
  }, [running]);

  useEffect(() => {
    if (!armed) return;
    const t = window.setTimeout(() => setArmed(null), 4000);
    return () => window.clearTimeout(t);
  }, [armed]);

  const run = async (action: string, option = "") => {
    setArmed(null);
    const res = await setupRun(action, option);
    if (!res.ok) toaster.toast({ title: "Setup tool", body: res.message });
    setShowOutput(true);
    await load();
  };

  // Destructive or long presses need a second press within 4 seconds.
  const twoPress = (key: string, go: () => void) => () => {
    if (armed === key) go();
    else setArmed(key);
  };

  if (!data) return null;
  const job = data.job;
  const finished = !job.running && job.meta && seenJob !== job.meta.started;
  const missing = data.options.filter((o) => !o.installed && o.id !== "ctlcenter").length;

  return (
    <>
      <PanelSection title="Setup tool">
        {!data.available && (
          <PanelSectionRow>
            <Field focusable={true} bottomSeparator="none">
              <span style={{ fontSize: "0.8em", opacity: 0.85 }}>
                Run the setup tool once from a terminal so this panel can find it.
              </span>
            </Field>
          </PanelSectionRow>
        )}

        {(job.running || finished) && job.meta && (
          <>
            <PanelSectionRow>
              <Field focusable={true} bottomSeparator="none" childrenLayout="below">
                <div style={{ fontWeight: 600 }}>
                  {job.running
                    ? `${jobTitle(job.meta)}…`
                    : job.rc === 0
                      ? `${jobTitle(job.meta)}: done`
                      : `${jobTitle(job.meta)} didn't finish`}
                </div>
                <div style={{ fontSize: "0.75em", opacity: 0.7 }}>
                  {job.running
                    ? "You can leave this panel. It keeps going."
                    : job.rc === 0
                      ? "The output is below."
                      : "The output below says where it stopped."}
                </div>
              </Field>
            </PanelSectionRow>
            {showOutput && (
              <PanelSectionRow>
                <Field focusable={true} bottomSeparator="none">
                  <pre style={LOG_STYLE}>{job.log || "Starting…"}</pre>
                </Field>
              </PanelSectionRow>
            )}
            <PanelSectionRow>
              <ButtonItem layout="below" onClick={() => setShowOutput(!showOutput)}>
                {showOutput ? "Hide the output" : "Show the output"}
              </ButtonItem>
            </PanelSectionRow>
            {finished && (
              <PanelSectionRow>
                <ButtonItem layout="below" onClick={() => setSeenJob(job.meta!.started)}>
                  Dismiss
                </ButtonItem>
              </PanelSectionRow>
            )}
          </>
        )}

        {SETUP_GROUPS.map((g) => {
          const opts = data.options.filter((o) => g.ids.includes(o.id));
          if (opts.length === 0) return null;
          const have = opts.filter((o) => o.installed).length;
          return (
            <Group
              key={g.id}
              title={g.title}
              summary={g.summary}
              count={`${have}/${opts.length}`}
              dot={have === opts.length ? "#59bf40" : "#8b93a3"}
              open={!!open[g.id]}
              onToggle={() => setOpen({ ...open, [g.id]: !open[g.id] })}
              rows={true}
            >
              {opts.map((o) => (
                <PanelSectionRow key={o.id}>
                  <Field
                    label={o.name}
                    description={o.installed ? "Installed" : "Not installed"}
                    bottomSeparator="standard"
                  >
                    <DialogButton
                      style={{ minWidth: "96px", padding: "4px 10px", fontSize: "0.85em" }}
                      disabled={running || !data.available}
                      onClick={
                        o.installed
                          ? twoPress(o.id, () => run("remove", o.id))
                          : () => run("install", o.id)
                      }
                    >
                      {o.installed ? (armed === o.id ? "Press again" : "Remove") : "Install"}
                    </DialogButton>
                  </Field>
                </PanelSectionRow>
              ))}
            </Group>
          );
        })}

        {missing > 0 && (
          <PanelSectionRow>
            <ButtonItem
              layout="below"
              disabled={running || !data.available}
              description="Everything except Control Center, which stays opt-in"
              onClick={twoPress("all", () => run("install-all"))}
            >
              {armed === "all" ? "Press again to install" : `Install what's missing (${missing})`}
            </ButtonItem>
          </PanelSectionRow>
        )}
        <PanelSectionRow>
          <Focusable
            style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px", padding: "6px 0" }}
            flow-children="horizontal"
          >
            <DialogButton
              style={{ minWidth: 0, padding: "6px 0", fontSize: "0.9em" }}
              disabled={running || !data.available}
              onClick={() => run("status")}
            >
              Status check
            </DialogButton>
            <DialogButton
              style={{ minWidth: 0, padding: "6px 0", fontSize: "0.9em" }}
              disabled={running || !data.available}
              onClick={() => run("test-cec")}
            >
              Test HDMI-CEC
            </DialogButton>
          </Focusable>
        </PanelSectionRow>
      </PanelSection>
    </>
  );
}

function Content() {
  const [state, setState] = useState<State | null>(null);
  const [settings, setSettingsState] = useState<Settings | null>(null);
  const [status, setStatus] = useState<UpdateStatus | null>(null);
  const [log, setLog] = useState<string>("");
  const [showLog, setShowLog] = useState(false);
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({});
  const [tab, setTabState] = useState<string>(lastTab);
  const setTab = (t: string) => {
    lastTab = t;
    setTabState(t);
  };
  const [reboot, setReboot] = useState<{ needed: boolean; reason: string | null }>({
    needed: false,
    reason: null,
  });
  const [busy, setBusy] = useState(false);
  const [lock, setLock] = useState<{ locked: boolean; live: boolean; age_min: number }>({
    locked: false,
    live: false,
    age_min: 0,
  });
  const [showSettings, setShowSettings] = useState(false);
  const [dismissedRun, setDismissedRun] = useState<number | null>(null);
  const [watchlistDraft, setWatchlistDraft] = useState("");
  const [keyDraft, setKeyDraft] = useState("");
  const [artBusy, setArtBusy] = useState(false);
  const [pluginUpdates, setPluginUpdates] = useState<PluginUpdate[]>([]);
  const [toolUpdate, setToolUpdate] = useState<{ path: string } | null>(null);
  const [components, setComponents] = useState<Component[]>([]);
  const [componentsRunning, setComponentsRunning] = useState(false);
  const [deckyPending, setDeckyPending] = useState<string[]>([]);

  const refreshAll = async () => {
    try {
      const [s, st, sett, rb, lk] = await Promise.all([
        getState(),
        updateStatus(),
        getSettings(),
        needsReboot(),
        lockState(),
      ]);
      setLock(lk);
      setPluginUpdates((s as any)?.plugin_updates ?? []);
      setToolUpdate((s as any)?.tool_update ?? null);
      setComponents((s as any)?.components ?? []);
      setComponentsRunning(!!(s as any)?.components_running);
      setDeckyPending((s as any)?.decky_restart_pending ?? []);
      setBadge(badgeFromState(s && (s as any).checked_at ? s : null));
      setState(s && (s as any).checked_at ? s : null);
      setStatus(st);
      setSettingsState(sett);
      setWatchlistDraft(sett.watchlist);
      setKeyDraft(sett.steamgriddb_key ?? "");
      setReboot(rb);
      if (st.running || st.pacman_live || showLog) setLog(await getLog(60));
    } catch (e) {
      console.error("[System Updates] refresh failed", e);
    }
  };

  useEffect(() => {
    refreshAll();
    const onFinished = () => {
      refreshAll();
    };
    addEventListener<[LastRun]>("cachy_updates/finished", onFinished);
    return () => removeEventListener("cachy_updates/finished", onFinished);
  }, []);

  const busyElsewhere = !!status?.pacman_live && !status?.running;
  useEffect(() => {
    if (!status?.running && !status?.pacman_live) return;
    const handle = window.setInterval(async () => {
      try {
        const st = await updateStatus();
        setStatus(st);
        setLog(await getLog(60));
        if (!st.running && !st.pacman_live) {
          setLock(await lockState());
          setReboot(await needsReboot());
          await checkNow(false);
          setState(await getState());
        }
      } catch (e) {
        console.error("[System Updates] status poll failed", e);
      }
    }, 2000);
    return () => window.clearInterval(handle);
  }, [status?.running, status?.pacman_live]);

  const patch = async (p: Partial<Settings>) => {
    const next = await setSettings(p);
    setSettingsState(next);
    setWatchlistDraft(next.watchlist);
  };

  const repoCount = state?.count ?? 0;
  const aurAll = state?.aur ?? [];
  const canInstallAur = settings?.install_aur ?? false;
  const pkgTotal = repoCount + (canInstallAur ? aurAll.length : 0);
  // Plugin and setup-tool updates sit in the same list and install with
  // the same button as the system's own packages.
  const extras = [
    ...pluginUpdates.map((p) => ({
      name: p.name,
      note: p.packages_only
        ? `needs ${(p.missing ?? []).join(", ")}`
        : `${p.installed} → ${p.latest}`,
    })),
    ...(toolUpdate ? [{ name: "Setup tool", note: "new version" }] : []),
    ...components.filter((c) => c.remote).map((c) => ({ name: c.name, note: c.note })),
  ];
  const total = pkgTotal + extras.length;
  const running = status?.running ?? false;
  const failed =
    !running && status?.last_rc != null && status.last_rc !== 0 && !status.cancelled;
  const blocked = !!state?.blocking_news;
  const unreadNews = state?.news?.filter((n) => !n.seen) ?? [];
  const services = state?.services ?? [];
  const lastRun = state?.last_run ?? null;
  const aur = aurAll;
  // Show the outcome until acknowledged, so a finished run can't go unseen.
  const justFinished =
    lastRun && dismissedRun !== lastRun.finished ? lastRun : null;
  const dkms = state?.dkms ?? [];

  // One headline, in plain words, so the panel answers "am I fine?" instantly.
  let headline = "Checking…";
  let detail = "";
  if (state?.error) {
    headline = "Can't check right now";
    detail = state.error;
  } else if (componentsRunning) {
    headline = "Updating plugins and the setup tool…";
    detail = pkgTotal > 0 ? "System packages come right after." : "";
  } else if (running && status?.cancelling) {
    headline = "Stopping…";
    detail = "Installing packages can't be cut short safely, so it stops after the current step.";
  } else if (running) {
    headline = phaseFromLog(log);
    detail = "You can leave this panel — it keeps going.";
  } else if (busyElsewhere) {
    headline = "Packages are still installing";
    detail = "pacman is still running. Wait for it to finish before you restart or update again.";
  } else if (justFinished && justFinished.cancelled) {
    headline = "Update stopped";
    detail = justFinished.packages_done
      ? "System packages were installed; the rest was skipped."
      : "Nothing new was installed. Install again whenever you like.";
  } else if (justFinished && justFinished.ok) {
    const n = justFinished.installed || justFinished.attempted;
    headline = `Finished — ${n} update${n === 1 ? "" : "s"} installed`;
    detail = justFinished.reboot
      ? "Restart to finish applying them."
      : total > 0
        ? `${total} still pending.`
        : "Everything is up to date.";
  } else if (lock.locked && !lock.live) {
    headline = "A previous update was interrupted";
    detail = "It left a lock behind. Clear it below, then try again.";
  } else if (failed) {
    headline = "That update didn't finish";
    detail = "Nothing is half-installed. The technical log under Tools shows how far it got.";
  } else if (blocked) {
    headline = "Read this before updating";
    detail = "One of these updates needs a manual step.";
  } else if (total === 0) {
    headline =
      aur.length > 0 && !canInstallAur ? "System is up to date" : "You're up to date";
    detail =
      aur.length > 0 && !canInstallAur
        ? `${aur.length} AUR package${aur.length === 1 ? " has" : "s have"} updates — turn on AUR packages under Settings, or run cachy-update in Desktop Mode.`
        : services.length > 0
          ? ""
          : `Last checked ${timeAgo(state?.checked_at)}.`;
  } else if ((state?.important?.length ?? 0) > 0) {
    headline = total === 1 ? "1 update ready" : `${total} updates ready`;
    detail = "Some of these are worth installing soon.";
  } else {
    headline = total === 1 ? "1 update ready" : `${total} updates ready`;
    detail = "All routine — install whenever suits you.";
  }

  const primaryLabel = running || componentsRunning || busyElsewhere
    ? "Installing…"
    : blocked
      ? "Held until you mark the news read"
      : total > 0
        ? total === 1
          ? "Install 1 update"
          : `Install ${total} updates`
        : "Check again";

  const onPrimary = async () => {
    setBusy(true);
    try {
      if (total > 0 && !blocked) {
        // Extras first: the setup tool can need pacman, which the
        // system update holds while it runs.
        if (extras.length > 0) {
          setComponentsRunning(true);
          const problems: string[] = [];
          try {
            if (pluginUpdates.length > 0) {
              const res = await updatePlugins();
              if (res.failed.length > 0)
                problems.push(res.failed.map((f) => `${f.name}: ${f.error}`).join("; "));
            }
            if (toolUpdate || components.some((c) => c.remote)) {
              const res = await updateComponents();
              if (!res.ok) problems.push(res.message);
            }
          } finally {
            setComponentsRunning(false);
          }
          if (problems.length > 0)
            toaster.toast({ title: "Some updates didn't install", body: problems.join(" ") });
        }
        if (pkgTotal > 0) {
          const res = await startUpdate();
          if (!res.ok) {
            toaster.toast({ title: "Couldn't start", body: res.error ?? "Unknown error" });
          }
        }
      } else {
        await checkNow(false);
      }
      await refreshAll();
    } finally {
      setBusy(false);
    }
  };

  const restartNeeded = (!!justFinished?.ok && !!justFinished.reboot) || reboot.needed;
  const softRestartLabel =
    deckyPending.length > 0 && services.length > 0
      ? "Decky and services"
      : deckyPending.length > 0
        ? "Decky"
        : "these services";
  const showFinish = restartNeeded || deckyPending.length > 0 || services.length > 0;

  // Services first: restarting Decky reloads this panel.
  const softRestart = async () => {
    setBusy(true);
    try {
      if (services.length > 0) {
        const res = await restartServices(services);
        toaster.toast({
          title: "Restarted",
          body: res.skipped.length
            ? `${res.restarted.length} done, ${res.skipped.length} need a full restart`
            : `${res.restarted.length} done`,
        });
      }
      if (deckyPending.length > 0) {
        const res = await restartDecky();
        if (!res.ok) toaster.toast({ title: "Restart Decky", body: res.message });
      }
      await checkNow(false);
      await refreshAll();
    } finally {
      setBusy(false);
    }
  };

  const toggleGroup = (id: string) => setOpenGroups({ ...openGroups, [id]: !openGroups[id] });
  const importantN = state?.important?.length ?? 0;
  const routine = (state?.packages ?? []).filter(
    (p) => !(state?.important ?? []).some((i) => i.name === p.name),
  );
  const routineN = Math.max(repoCount - importantN, 0);
  const flatpak = state?.flatpak ?? [];
  const firstNames = (names: string[]) =>
    names.slice(0, 3).join(", ") + (names.length > 3 ? "…" : "");

  const lockBlock = lock.locked && !lock.live && (
    <PanelSectionRow>
      <ButtonItem
        layout="below"
        disabled={busy}
        description={`An interrupted update left a lock file behind (${lock.age_min} min ago). Nothing is broken; clearing it lets you retry.`}
        onClick={async () => {
          setBusy(true);
          try {
            const res = await clearLock();
            toaster.toast({ title: "Lock", body: res.message });
            await refreshAll();
          } finally {
            setBusy(false);
          }
        }}
      >
        Clear leftover lock
      </ButtonItem>
    </PanelSectionRow>
  );

  // LB / RB (L1 / R1) switch tabs from anywhere in the panel.
  const onButtonDown = (evt: any) => {
    const b = evt?.detail?.button;
    if (b === GamepadButton.BUMPER_LEFT || b === GamepadButton.BUMPER_RIGHT) {
      setTab(tab === TAB_UPDATES ? TAB_TOOLS : TAB_UPDATES);
    }
  };

  return (
    <Focusable onButtonDown={onButtonDown}>
      <PanelSection>
        <PanelSectionRow>
          <TabBar tab={tab} onTab={setTab} badge={total} />
        </PanelSectionRow>
      </PanelSection>

      {tab === TAB_UPDATES && (
        <>
          <PanelSection>
            <PanelSectionRow>
              <Field
                focusable={true}
                bottomSeparator={detail ? "none" : "standard"}
                childrenLayout="below"
              >
                <div style={{ fontSize: "1.1em", fontWeight: 600 }}>{headline}</div>
                {detail && (
                  <div style={{ fontSize: "0.8em", opacity: 0.7, marginTop: "2px" }}>
                    {detail}
                  </div>
                )}
              </Field>
            </PanelSectionRow>

            {running && status?.progress && (
              <PanelSectionRow>
                <UpdateProgress
                  label={status.progress.label}
                  percent={status.progress.percent}
                />
              </PanelSectionRow>
            )}

            {running ? (
              <PanelSectionRow>
                <ButtonItem
                  layout="below"
                  disabled={busy || !!status?.cancelling}
                  onClick={async () => {
                    setBusy(true);
                    try {
                      const res = await cancelUpdate();
                      toaster.toast({ title: "System update", body: res.message });
                      await refreshAll();
                    } finally {
                      setBusy(false);
                    }
                  }}
                >
                  {status?.cancelling ? "Stopping…" : "Stop"}
                </ButtonItem>
              </PanelSectionRow>
            ) : !(showFinish && total === 0) ? (
              <PanelSectionRow>
                <ButtonItem
                  layout="below"
                  disabled={
                    busy || busyElsewhere || componentsRunning || blocked || (lock.locked && !lock.live)
                  }
                  onClick={onPrimary}
                >
                  {primaryLabel}
                </ButtonItem>
              </PanelSectionRow>
            ) : null}

            {justFinished && !restartNeeded && !running && (
              <PanelSectionRow>
                <ButtonItem layout="below" onClick={() => setDismissedRun(justFinished.finished)}>
                  Dismiss
                </ButtonItem>
              </PanelSectionRow>
            )}

            {lockBlock}
          </PanelSection>

          {/* One place to finish an update, however many things want restarting. */}
          {showFinish && !running && (
            <PanelSection title="Restart to finish">
              <PanelSectionRow>
                <Field focusable={true} bottomSeparator="none" childrenLayout="below">
                  <div style={{ fontSize: "0.8em", lineHeight: "1.5em", opacity: 0.85 }}>
                    {restartNeeded && (
                      <div>
                        {justFinished?.reboot_reason ?? reboot.reason ?? "A restart finishes installing the updates."}
                      </div>
                    )}
                    {deckyPending.length > 0 && (
                      <div>Plugins waiting on a Decky restart: {deckyPending.join(", ")}.</div>
                    )}
                    {services.length > 0 && (
                      <div>Still running the old version: {services.map(friendlyService).join(", ")}.</div>
                    )}
                  </div>
                </Field>
              </PanelSectionRow>
              {restartNeeded && (
                <PanelSectionRow>
                  <ButtonItem layout="below" disabled={busy} onClick={() => doReboot()}>
                    Restart the BC-250
                  </ButtonItem>
                </PanelSectionRow>
              )}
              {(deckyPending.length > 0 || services.length > 0) && (
                <PanelSectionRow>
                  <ButtonItem layout="below" disabled={busy} onClick={softRestart}>
                    {restartNeeded ? `Only restart ${softRestartLabel}` : `Restart ${softRestartLabel}`}
                  </ButtonItem>
                </PanelSectionRow>
              )}
              {justFinished && restartNeeded && (
                <PanelSectionRow>
                  <ButtonItem layout="below" onClick={() => setDismissedRun(justFinished.finished)}>
                    Later
                  </ButtonItem>
                </PanelSectionRow>
              )}
              {services.length > 0 && (
                <PanelSectionRow>
                  <Field focusable={true} bottomSeparator="none">
                    <span style={{ fontSize: "0.75em", opacity: 0.65 }}>
                      Networking and Wi-Fi are left for a full restart, so your connection stays up.
                    </span>
                  </Field>
                </PanelSectionRow>
              )}
            </PanelSection>
          )}

          {unreadNews.length > 0 && (
            <PanelSection title="Heads up">
              {unreadNews.map((n) => (
                <PanelSectionRow key={n.title}>
                  <Field focusable={true} bottomSeparator="none" childrenLayout="below">
                    <div style={{ fontSize: "0.8em", lineHeight: "1.4em" }}>
                      {n.intervention && <div style={{ fontWeight: 600 }}>Needs a manual step</div>}
                      <div style={{ opacity: n.intervention ? 1 : 0.75 }}>{n.title}</div>
                    </div>
                  </Field>
                </PanelSectionRow>
              ))}
              {blocked && (
                <PanelSectionRow>
                  <Field focusable={true} bottomSeparator="none">
                    <span style={{ fontSize: "0.75em", opacity: 0.75 }}>
                      Read it in Desktop Mode with cachy-update -n, then mark it read here.
                      If it's about software you don't have, marking it read is fine.
                    </span>
                  </Field>
                </PanelSectionRow>
              )}
              <PanelSectionRow>
                <ButtonItem
                  layout="below"
                  disabled={busy}
                  onClick={async () => {
                    setBusy(true);
                    try {
                      setState(await ackNews());
                      await refreshAll();
                    } finally {
                      setBusy(false);
                    }
                  }}
                >
                  Mark as read
                </ButtonItem>
              </PanelSectionRow>
            </PanelSection>
          )}

          {dkms.length > 0 && (
            <PanelSection title="Driver problem">
              <PanelSectionRow>
                <Field focusable={true} bottomSeparator="none">
                  <span style={{ fontSize: "0.8em", opacity: 0.85 }}>
                    A driver didn't rebuild for your current kernel, so whatever it
                    controls (sensors, fan speed) may not work. Worth a look in Desktop Mode.
                  </span>
                </Field>
              </PanelSectionRow>
            </PanelSection>
          )}

          {(extras.length > 0 || repoCount > 0 || flatpak.length > 0 || aur.length > 0) && (
            <PanelSection title={running ? "Installing" : "What's in it"}>
              {extras.length > 0 && (
                <Group
                  title="Plugins and setup tool"
                  summary={firstNames(extras.map((e) => e.name))}
                  count={extras.length}
                  open={!!openGroups.extras}
                  onToggle={() => toggleGroup("extras")}
                >
                  {extras.map((e) => (
                    <div key={e.name}>
                      {e.name} <span style={{ opacity: 0.6 }}>{e.note}</span>
                    </div>
                  ))}
                </Group>
              )}
              {importantN > 0 && (
                <Group
                  title="Worth knowing about"
                  summary={firstNames(state!.important.map((p) => p.name))}
                  count={importantN}
                  open={!!openGroups.important}
                  onToggle={() => toggleGroup("important")}
                >
                  {state!.important.map((p) => (
                    <div key={p.name}>
                      {p.name} <span style={{ opacity: 0.6 }}>{p.old} → {p.new}</span>
                      {p.flags?.includes("security") ? " · security fix" : ""}
                    </div>
                  ))}
                </Group>
              )}
              {routineN > 0 && (
                <Group
                  title="Routine packages"
                  summary="Libraries and small fixes"
                  count={routineN}
                  open={!!openGroups.routine}
                  onToggle={() => toggleGroup("routine")}
                >
                  {routine.slice(0, 60).map((p) => (
                    <div key={p.name}>
                      {p.name} <span style={{ opacity: 0.6 }}>{p.new}</span>
                    </div>
                  ))}
                  {routine.length > 60 && (
                    <div style={{ opacity: 0.6 }}>and {routine.length - 60} more</div>
                  )}
                </Group>
              )}
              {flatpak.length > 0 && (
                <Group
                  title="Apps"
                  summary={settings?.include_flatpak === false ? "Flatpak, not installed from here" : "Flatpak"}
                  count={flatpak.length}
                  open={!!openGroups.apps}
                  onToggle={() => toggleGroup("apps")}
                >
                  {flatpak.map((f) => (
                    <div key={f}>{f}</div>
                  ))}
                </Group>
              )}
              {aur.length > 0 && (
                <Group
                  title="AUR packages"
                  summary={canInstallAur ? "Built from source" : "Not installed from here"}
                  count={aur.length}
                  open={!!openGroups.aur}
                  onToggle={() => toggleGroup("aur")}
                >
                  {/* Only what has an update; the rest of the AUR packages need nothing. */}
                  {aur.map((a) => (
                    <div key={a.name}>
                      {a.name} <span style={{ opacity: 0.6 }}>{a.old}</span>
                      <span style={{ fontWeight: 600 }}> {a.vcs ? "· new commits" : `→ ${a.new}`}</span>
                    </div>
                  ))}
                  <div style={{ opacity: 0.65, marginTop: "6px" }}>
                    {canInstallAur
                      ? "These build from source when you install, so an update takes longer than usual. A package that fails to build is skipped; the rest still install."
                      : "Turn on AUR packages under Settings to install them here, or run cachy-update in Desktop Mode."}
                  </div>
                  {aur.some((a) => a.vcs) && (
                    <div style={{ opacity: 0.65, marginTop: "6px" }}>
                      "New commits" means newer code is available upstream. You're told
                      once per version, not on every check.
                    </div>
                  )}
                </Group>
              )}
            </PanelSection>
          )}

          <PanelSection title="Settings">
            <PanelSectionRow>
              <ButtonItem layout="below" onClick={() => setShowSettings(!showSettings)}>
                {showSettings ? "Close settings" : "Notifications and what to install"}
              </ButtonItem>
            </PanelSectionRow>
            {showSettings && settings && (
              <>
                <PanelSectionRow>
                  <Field focusable={true} bottomSeparator="none">
                    <span style={{ fontSize: "0.75em", opacity: 0.7 }}>
                      Everything still shows up here. The first list only decides what
                      pops up a notification. Security fixes always do.
                    </span>
                  </Field>
                </PanelSectionRow>
                <SubHead>Tell me about</SubHead>
                <PanelSectionRow>
                  <ToggleField
                    label="Important software"
                    description="Kernel, graphics, audio, Steam"
                    checked={settings.notify_watchlist}
                    onChange={(v) => patch({ notify_watchlist: v })}
                  />
                </PanelSectionRow>
                <PanelSectionRow>
                  <ToggleField
                    label="Big version jumps"
                    checked={settings.notify_major}
                    onChange={(v) => patch({ notify_major: v })}
                  />
                </PanelSectionRow>
                <PanelSectionRow>
                  <ToggleField
                    label="News that needs a manual step"
                    description="Holds Install until you've read it"
                    checked={settings.notify_news}
                    onChange={(v) => patch({ notify_news: v, block_on_intervention: v })}
                  />
                </PanelSectionRow>
                <PanelSectionRow>
                  <ToggleField
                    label="AUR updates"
                    checked={settings.notify_aur}
                    onChange={(v) => patch({ notify_aur: v })}
                  />
                </PanelSectionRow>
                {settings.notify_aur && (
                  <PanelSectionRow>
                    <ToggleField
                      label="Include -git packages"
                      description="Control Center and sensor driver"
                      checked={settings.notify_aur_devel}
                      onChange={(v) => patch({ notify_aur_devel: v })}
                    />
                  </PanelSectionRow>
                )}
                <PanelSectionRow>
                  <ToggleField
                    label="Something needs restarting"
                    checked={settings.notify_services}
                    onChange={(v) => patch({ notify_services: v })}
                  />
                </PanelSectionRow>
                <PanelSectionRow>
                  <ToggleField
                    label="Driver problems"
                    checked={settings.notify_dkms}
                    onChange={(v) => patch({ notify_dkms: v })}
                  />
                </PanelSectionRow>
                <PanelSectionRow>
                  <ToggleField
                    label="Unusually large batches"
                    checked={settings.notify_volume}
                    onChange={(v) => patch({ notify_volume: v })}
                  />
                </PanelSectionRow>
                <PanelSectionRow>
                  <ToggleField
                    label={`Put off for ${settings.stale_days} days`}
                    checked={settings.notify_stale}
                    onChange={(v) => patch({ notify_stale: v })}
                  />
                </PanelSectionRow>
                <SubHead>When</SubHead>
                <PanelSectionRow>
                  <ToggleField
                    label="Quiet during games"
                    description="Holds notifications until you're back at the library"
                    checked={settings.hold_in_game}
                    onChange={(v) => patch({ hold_in_game: v })}
                  />
                </PanelSectionRow>
                <PanelSectionRow>
                  <SliderField
                    label="Check every"
                    value={settings.poll_hours}
                    min={1}
                    max={24}
                    step={1}
                    showValue={true}
                    valueSuffix=" h"
                    onChange={(v) => patch({ poll_hours: v })}
                  />
                </PanelSectionRow>
                <SubHead>Panel</SubHead>
                <PanelSectionRow>
                  <ToggleField
                    label="Setup tool options in Tools"
                    description="Turn off once the box is set up. Library art and the log stay."
                    checked={settings.show_setup_tools !== false}
                    onChange={(v) => patch({ show_setup_tools: v })}
                  />
                </PanelSectionRow>
                <SubHead>What to install</SubHead>
                <PanelSectionRow>
                  <ToggleField
                    label="Apps (Flatpak)"
                    checked={settings.include_flatpak}
                    onChange={(v) => patch({ include_flatpak: v })}
                  />
                </PanelSectionRow>
                <PanelSectionRow>
                  <ToggleField
                    label="AUR packages"
                    description="Builds from source. AUR code isn't reviewed, so only turn this on if you trust what you have."
                    checked={settings.install_aur}
                    onChange={(v) => patch({ install_aur: v })}
                  />
                </PanelSectionRow>
              </>
            )}
          </PanelSection>
        </>
      )}

      {tab === TAB_TOOLS && (
        <>
          {settings?.show_setup_tools !== false && <SetupTools onFinished={refreshAll} />}

          <PanelSection title="More">
            <Group
              title="Library art"
              summary={keyDraft ? "SteamGridDB key set" : "Drawn art, no SteamGridDB key"}
              count=""
              open={!!openGroups.art}
              onToggle={() => toggleGroup("art")}
              rows={true}
            >
              <PanelSectionRow>
                <ButtonItem
                  layout="below"
                  disabled={artBusy}
                  description="Replaces the art on your Android TV, Xbox Cloud Gaming, GeForce NOW, Discord and JDownloader shortcuts"
                  onClick={async () => {
                    setArtBusy(true);
                    try {
                      const n = await refreshArt();
                      toaster.toast({ title: "Library art", body: n ? `Updated ${n} shortcut${n === 1 ? "" : "s"}` : "No app shortcuts found", duration: 5000 });
                    } finally {
                      setArtBusy(false);
                    }
                  }}
                >
                  {artBusy ? "Fetching art..." : "Fetch library art"}
                </ButtonItem>
              </PanelSectionRow>
              <PanelSectionRow>
                <Field label="SteamGridDB key" focusable={true} bottomSeparator="none" childrenLayout="below">
                  <div style={{ fontSize: "0.75em", opacity: 0.7, marginBottom: "4px" }}>
                    Optional. With a free key (steamgriddb.com, Preferences, API), shortcuts get the top-rated art from there instead of drawn art.
                  </div>
                  <TextField
                    value={keyDraft}
                    onChange={(e) => setKeyDraft(e.target.value)}
                    onBlur={() => patch({ steamgriddb_key: keyDraft.trim() })}
                  />
                </Field>
              </PanelSectionRow>
            </Group>

            <Group
              title="When something breaks"
              summary={lock.locked && !lock.live ? "A leftover lock needs clearing" : "Technical log, leftover lock, important list"}
              count=""
              dot={lock.locked && !lock.live ? "#e0a03a" : undefined}
              open={!!openGroups.breaks || (lock.locked && !lock.live)}
              onToggle={() => toggleGroup("breaks")}
              rows={true}
            >
              {lock.locked && lock.live && (
                <PanelSectionRow>
                  <Field focusable={true} bottomSeparator="none">
                    <span style={{ fontSize: "0.8em", opacity: 0.85 }}>
                      An update is running right now. Let it finish.
                    </span>
                  </Field>
                </PanelSectionRow>
              )}
              {lockBlock}
              <PanelSectionRow>
                <ButtonItem
                  layout="below"
                  onClick={async () => {
                    const next = !showLog;
                    setShowLog(next);
                    if (next) setLog(await getLog(60));
                  }}
                >
                  {showLog ? "Hide the technical log" : "Show the technical log"}
                </ButtonItem>
              </PanelSectionRow>
              {showLog && (
                <PanelSectionRow>
                  <Field focusable={true} bottomSeparator="none">
                    <pre style={LOG_STYLE}>
                      {log || "Nothing yet. This fills in during an update."}
                    </pre>
                  </Field>
                </PanelSectionRow>
              )}
              <PanelSectionRow>
                <Field label="What counts as important" focusable={true} bottomSeparator="none" childrenLayout="below">
                  <div style={{ fontSize: "0.75em", opacity: 0.7, marginBottom: "4px" }}>
                    Software that's flagged as worth knowing about, as a comma-separated list.
                  </div>
                  <TextField
                    value={watchlistDraft}
                    onChange={(e) => setWatchlistDraft(e.target.value)}
                    onBlur={() => patch({ watchlist: watchlistDraft })}
                  />
                </Field>
              </PanelSectionRow>
              <PanelSectionRow>
                <ButtonItem
                  layout="below"
                  onClick={async () => {
                    const next = await resetWatchlist();
                    setSettingsState(next);
                    setWatchlistDraft(next.watchlist);
                  }}
                >
                  Reset that list
                </ButtonItem>
              </PanelSectionRow>
            </Group>
          </PanelSection>
        </>
      )}
    </Focusable>
  );
}

function UpdateIcon() {
  const b = useBadge();
  return (
    <div style={{ position: "relative", display: "inline-flex", alignItems: "center" }}>
      <BaseIcon />
      {b.count > 0 && (
        <span
          style={{
            position: "absolute",
            top: "-4px",
            right: "-7px",
            minWidth: "14px",
            height: "14px",
            padding: "0 3px",
            borderRadius: "7px",
            background: b.attention ? "#e0a03a" : "#4c5b6b",
            color: b.attention ? "#1a1a1a" : "#ffffff",
            fontSize: "9px",
            fontWeight: 700,
            lineHeight: "14px",
            textAlign: "center",
            boxSizing: "border-box",
          }}
        >
          {b.count > 99 ? "99+" : b.count}
        </span>
      )}
    </div>
  );
}

function TitleView() {
  const b = useBadge();
  return (
    <div className={staticClasses.Title} style={{ display: "flex", alignItems: "center" }}>
      <span>System Updates</span>
      <BadgePill {...b} />
    </div>
  );
}

function BaseIcon() {
  return (
    <svg
      width="1em"
      height="1em"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 3v12" />
      <path d="m7 12 5 5 5-5" />
      <path d="M5 21h14" />
    </svg>
  );
}

export default definePlugin(() => {
  const pending: { title: string; body: string }[] = [];
  let flushTimer: number | undefined;
  let badgeTimer: number | undefined;

  const inGame = (): boolean => {
    try {
      return !!(Router as any)?.MainRunningApp;
    } catch {
      return false;
    }
  };

  const flush = () => {
    if (inGame() || pending.length === 0) return;
    const item = pending.shift()!;
    pending.length = 0;
    toaster.toast({ title: item.title, body: item.body, duration: 8000 });
  };

  const onNotify = async (payload: { title: string; body: string }) => {
    let hold = true;
    try {
      hold = (await getSettings()).hold_in_game;
    } catch {
      /* default to holding */
    }
    if (hold && inGame()) {
      pending.push(payload);
      return;
    }
    toaster.toast({ title: payload.title, body: payload.body, duration: 8000 });
  };

  addEventListener<[{ title: string; body: string }]>("cachy_updates/notify", onNotify);
  flushTimer = window.setInterval(flush, 30000);

  // get_state is just the cached result, so polling it is cheap - it never
  // triggers a pacman call.
  const syncBadge = async () => {
    try {
      const s = await getState();
      setBadge(badgeFromState(s && (s as any).checked_at ? s : null));
    } catch {
      /* loader may not be ready yet */
    }
  };
  syncBadge();
  badgeTimer = window.setInterval(syncBadge, 60000);
  const runShortcutSync = () =>
    syncShortcuts().catch((e) => console.error("[System Updates] shortcut sync failed", e));
  const shortcutStart = window.setTimeout(runShortcutSync, 5000);
  const shortcutTimer = window.setInterval(runShortcutSync, 5 * 60000);

  return {
    name: "System Updates",
    titleView: <TitleView />,
    content: <Content />,
    icon: <UpdateIcon />,
    onDismount() {
      removeEventListener("cachy_updates/notify", onNotify);
      if (flushTimer) window.clearInterval(flushTimer);
      if (badgeTimer) window.clearInterval(badgeTimer);
      window.clearTimeout(shortcutStart);
      window.clearInterval(shortcutTimer);
    },
  };
});
