import {
  ButtonItem,
  Field,
  PanelSection,
  PanelSectionRow,
  ToggleField,
  staticClasses,
} from "@decky/ui";
import { callable, definePlugin, toaster } from "@decky/api";
import { useEffect, useState } from "react";
import { FaTachometerAlt } from "react-icons/fa";

interface Status {
  smt_control: string | null;
  smt_changeable: boolean;
  smt_on: boolean;
  threads: number;
  governor: string | null;
  governors: string[];
  driver: string | null;
  performance_available: boolean;
  performance: boolean;
}

interface Result {
  ok: boolean;
  message: string;
  status: Status;
}

const getStatus = callable<[], Status>("get_status");
const setSmt = callable<[boolean], Result>("set_smt");
const setPerformance = callable<[boolean], Result>("set_performance");

function Content() {
  const [status, setStatus] = useState<Status | null>(null);
  const [failed, setFailed] = useState(false);
  const [busy, setBusy] = useState(false);

  const refresh = () =>
    getStatus()
      .then((s) => {
        setStatus(s);
        setFailed(false);
      })
      .catch(() => setFailed(true));

  useEffect(() => {
    refresh();
  }, []);

  const run = async (title: string, fn: () => Promise<Result>) => {
    if (busy) return;
    setBusy(true);
    try {
      const r = await fn();
      setStatus(r.status);
      if (!r.ok) toaster.toast({ title, body: r.message });
    } catch {
      toaster.toast({ title, body: "Backend did not respond." });
    } finally {
      setBusy(false);
    }
  };

  if (status === null) {
    return (
      <PanelSection title="Performance">
        <PanelSectionRow>{failed ? "Backend did not respond." : "Reading the CPU…"}</PanelSectionRow>
        {failed && (
          <PanelSectionRow>
            <ButtonItem layout="below" onClick={refresh}>
              Try again
            </ButtonItem>
          </PanelSectionRow>
        )}
      </PanelSection>
    );
  }

  const smtNote = status.smt_changeable
    ? `${status.threads} threads on line. Off gives each game a whole core per thread; on runs more at once.`
    : `Can't be changed while running (kernel reports "${status.smt_control ?? "missing"}").`;

  const perfNote = status.performance_available
    ? `CPU governor: ${status.governor ?? "unknown"}${status.driver ? ` (${status.driver})` : ""}. On keeps the CPU at full clocks; more heat and fan noise.`
    : "This kernel exposes no CPU frequency scaling.";

  return (
    <PanelSection title="CPU">
      <PanelSectionRow>
        <ToggleField
          label="SMT (hyperthreading)"
          description={smtNote}
          checked={status.smt_on}
          disabled={busy || !status.smt_changeable}
          onChange={(v) => run("SMT", () => setSmt(v))}
        />
      </PanelSectionRow>
      <PanelSectionRow>
        <ToggleField
          label="Performance mode"
          description={perfNote}
          checked={status.performance}
          disabled={busy || !status.performance_available}
          onChange={(v) => run("Performance mode", () => setPerformance(v))}
        />
      </PanelSectionRow>
      <PanelSectionRow>
        <Field
          label="Kept across reboots"
          description="Both settings are applied again each time Game Mode starts."
        />
      </PanelSectionRow>
    </PanelSection>
  );
}

export default definePlugin(() => ({
  name: "BC-250 Performance",
  titleView: <div className={staticClasses.Title}>BC-250 Performance</div>,
  content: <Content />,
  icon: <FaTachometerAlt />,
}));
