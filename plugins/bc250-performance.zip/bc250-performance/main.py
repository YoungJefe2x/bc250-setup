"""BC-250 Performance: SMT and CPU performance mode toggles from Game Mode.

SMT goes through the kernel's /sys/devices/system/cpu/smt/control, which
takes the sibling threads off line (6 cores / 6 threads) or brings them back
(6 cores / 12 threads) without a reboot. Performance mode sets every online
CPU's cpufreq governor to "performance" and puts back the governor that was
there before when it is turned off. The GPU is left to its own governor
(oberon-governor, when the BC-250 Control Center installed it).

Both settings are saved and applied again each time Decky starts, so they
hold across reboots. Nothing is written outside sysfs and this plugin's
settings file: remove the plugin and reboot, and the kernel defaults are back.
"""

import asyncio
import glob
import json
import os

import decky

CPU_DIR = "/sys/devices/system/cpu"
SMT_CONTROL = os.path.join(CPU_DIR, "smt/control")
SMT_ACTIVE = os.path.join(CPU_DIR, "smt/active")

SETTINGS_DIR = getattr(decky, "DECKY_PLUGIN_SETTINGS_DIR", "/tmp/bc250-performance")
SETTINGS_PATH = os.path.join(SETTINGS_DIR, "settings.json")

DEFAULTS = {
    # None until the toggle is used, so a fresh install leaves SMT as booted.
    "smt": None,
    "performance": False,
    # Governor to go back to when performance mode is turned off.
    "previous_governor": None,
}

PERF_GOVERNOR = "performance"


def _read(path):
    try:
        with open(path) as f:
            return f.read().strip()
    except OSError:
        return None


def _write(path, value):
    try:
        with open(path, "w") as f:
            f.write(value)
        return None
    except OSError as e:
        return e.strerror or str(e)


def _governor_files():
    """scaling_governor of every online CPU. Offline SMT siblings have none."""
    return sorted(glob.glob(os.path.join(CPU_DIR, "cpu[0-9]*/cpufreq/scaling_governor")))


def _available_governors():
    text = _read(os.path.join(CPU_DIR, "cpu0/cpufreq/scaling_available_governors"))
    return text.split() if text else []


def _threads_online():
    text = _read(os.path.join(CPU_DIR, "online")) or ""
    count = 0
    for part in text.split(","):
        if "-" in part:
            lo, hi = part.split("-", 1)
            count += int(hi) - int(lo) + 1
        elif part:
            count += 1
    return count


def _cpu_driver():
    return _read(os.path.join(CPU_DIR, "cpu0/cpufreq/scaling_driver"))


class Plugin:
    async def _main(self):
        self.lock = asyncio.Lock()
        self.settings = dict(DEFAULTS)
        try:
            with open(SETTINGS_PATH) as f:
                saved = json.load(f)
            for key in DEFAULTS:
                if key in saved:
                    self.settings[key] = saved[key]
        except (OSError, ValueError):
            pass
        async with self.lock:
            await asyncio.to_thread(self._apply_saved)
        decky.logger.info("BC-250 Performance loaded")

    async def _unload(self):
        pass

    def _save(self):
        try:
            os.makedirs(SETTINGS_DIR, exist_ok=True)
            with open(SETTINGS_PATH, "w") as f:
                json.dump(self.settings, f, indent=2)
        except OSError as e:
            decky.logger.warning(f"could not save settings: {e}")

    # ---------------------------------------------------------- helpers ---

    def _apply_saved(self):
        if self.settings.get("smt") is not None:
            err = self._set_smt(bool(self.settings["smt"]))
            if err:
                decky.logger.warning(f"SMT: {err}")
        if self.settings.get("performance"):
            err = self._set_governor_all(PERF_GOVERNOR)
            if err:
                decky.logger.warning(f"performance mode: {err}")

    def _smt_state(self):
        control = _read(SMT_CONTROL)
        return {
            "control": control,
            # "forceoff" (nosmt=force), "notsupported" and "notimplemented"
            # can't be changed at run time.
            "changeable": control in ("on", "off"),
            "active": _read(SMT_ACTIVE) == "1",
        }

    def _set_smt(self, on):
        state = self._smt_state()
        if not state["changeable"]:
            return f"SMT can't be changed here (kernel reports \"{state['control'] or 'missing'}\")."
        want = "on" if on else "off"
        if state["control"] == want:
            return None
        err = _write(SMT_CONTROL, want)
        if err:
            return f"could not turn SMT {want}: {err}"
        # Siblings coming back on line start on the kernel's default
        # governor, so performance mode has to cover them too.
        if on and self.settings.get("performance"):
            self._set_governor_all(PERF_GOVERNOR)
        return None

    def _current_governor(self):
        files = _governor_files()
        return _read(files[0]) if files else None

    def _set_governor_all(self, governor):
        files = _governor_files()
        if not files:
            return "this kernel exposes no CPU frequency scaling (cpufreq)."
        available = _available_governors()
        if available and governor not in available:
            return f"the \"{governor}\" governor isn't available (have: {' '.join(available)})."
        failed = []
        for path in files:
            if _read(path) == governor:
                continue
            if _write(path, governor):
                failed.append(path.split("/")[-3])
        if failed:
            return f"could not set {governor} on {', '.join(failed)}."
        return None

    def _snapshot(self):
        smt = self._smt_state()
        available = _available_governors()
        return {
            "smt_control": smt["control"],
            "smt_changeable": smt["changeable"],
            "smt_on": smt["control"] == "on",
            "threads": _threads_online(),
            "governor": self._current_governor(),
            "governors": available,
            "driver": _cpu_driver(),
            "performance_available": bool(_governor_files()) and (not available or PERF_GOVERNOR in available),
            "performance": bool(self.settings.get("performance")),
        }

    # -------------------------------------------------------- callables ---

    async def get_status(self):
        async with self.lock:
            return await asyncio.to_thread(self._snapshot)

    async def set_smt(self, on: bool):
        def work():
            err = self._set_smt(bool(on))
            if not err:
                self.settings["smt"] = bool(on)
                self._save()
            return {"ok": err is None, "message": err or "", "status": self._snapshot()}

        async with self.lock:
            return await asyncio.to_thread(work)

    async def set_performance(self, on: bool):
        def work():
            if on:
                current = self._current_governor()
                if current and current != PERF_GOVERNOR:
                    self.settings["previous_governor"] = current
                err = self._set_governor_all(PERF_GOVERNOR)
            else:
                back = self.settings.get("previous_governor")
                available = _available_governors()
                if not back or (available and back not in available):
                    # Same fallback order the kernel config usually picks.
                    back = next((g for g in ("schedutil", "powersave", "ondemand") if g in available), None)
                err = self._set_governor_all(back) if back else "no governor to go back to."
            if not err:
                self.settings["performance"] = bool(on)
                self._save()
            return {"ok": err is None, "message": err or "", "status": self._snapshot()}

        async with self.lock:
            return await asyncio.to_thread(work)
