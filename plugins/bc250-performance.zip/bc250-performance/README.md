# BC-250 Performance

Decky plugin for the BC-250: CPU toggles in the Quick Access Menu.

- SMT (hyperthreading) on or off. Off takes the sibling threads off line
  (6 cores / 6 threads), on brings them back (6 cores / 12 threads). Changes
  right away through `/sys/devices/system/cpu/smt/control`, no reboot.
- Performance mode on or off. On sets every CPU's cpufreq governor to
  `performance`; off puts back the governor that was in use before. The GPU
  is left to its own governor (oberon-governor from the BC-250 Control
  Center).

Both settings are saved and applied again each time Decky starts, so they
hold across reboots. Nothing is written outside sysfs and the plugin's own
settings file: remove the plugin and reboot to get the kernel defaults back.

If the kernel was booted with `nosmt=force`, SMT shows as locked.

Build: `npm install && npm run build`.
