# Discord Deck

A Decky Loader plugin for joining Discord voice channels and changing audio devices from the Quick Access menu.

- Pick a server, then press A on a voice channel to join it; leave from the same panel
- See who's in the call in a party-style grid — avatars light up in a ring color you can customize, while someone's talking, **including your own** (Discord's RPC only reports *other* people's speaking activity, so your own mic is monitored locally via PipeWire to detect this — nothing is recorded or transmitted, just a live volume level)
- Per-person volume and mute: the picture you're on gets a white ring; tap a friend's picture in the call to get their volume slider (0–200%) and a mute switch. It only changes what you hear, and Discord remembers it for that person.
- Favorites: press X on a channel to favorite it (X again to remove it), and it shows at the top of the panel with its server and how many people are in it, ready to join in one tap. Servers with a favorite come first in the Server list, and "Only show these servers" hides the rest.
- Speaking overlay: Xbox-style cards with each talker's picture and name pop up over your game only while they talk. Pick the corner, how see-through the background is, and the size under "Speaking overlay". It needs GTK for Python (`python-gobject`, `python-cairo`, `gtk3`, `xorg-xprop`), which the BC-250 setup tool installs.
- Join and leave pop-ups: when someone joins or leaves your voice channel, an Xbox achievement-style pop-up (in your speaking ring color for a join, grey for a leave) with their picture says "Joined the party" or "Left the party" for a few seconds at the bottom middle of the screen. Turn it off with "Show joins and leaves".
- Set up from your phone: Discord Deck shows a QR code, and the page it opens walks you through making the Discord app and sends its ID and secret back to the box over your home Wi-Fi (needs `qrencode` for the QR code; otherwise it shows the address)
- Show Discord on screen: adds Discord to your Steam library and opens it in Game Mode, so you can approve the one-time Authorize popup without desktop mode
- Mute and deafen
- Invites: when a friend sends you an invite link, it pops up wherever you are with their name and the channel. Hold the Xbox button within two minutes of the pop-up to join, or press A on it under Invites at the top of the panel (X dismisses it). Joining works for voice channels in servers you're already in; for a new server, accept the invite in Discord on your phone first. This needs one more Authorize if you signed in before 0.8.0; the panel asks.
- Change Discord's microphone, output device, and mic volume
- Change the **system** default output and input (PipeWire), because Discord's device list only shows what PipeWire is offering

It talks to the Discord desktop client over its local RPC socket, so Discord has to be running on the same machine. Nothing goes through a bot.

## What you need

- Decky Loader 3.0+ (this plugin uses `api_version: 1`)
- The Discord desktop client running (native, Flatpak, Vesktop and Canary sockets are all probed)
- `pipewire-utils` (`pw-dump`) and `wireplumber` (`wpctl`) — both ship with SteamOS
- Your own Discord application, see below

## Create the Discord app (one time)

Discord does not let unapproved apps use RPC for the general public, but the app **owner and up to 50 testers can use it immediately**. Since you're the owner, no approval is needed.

1. Go to <https://discord.com/developers/applications> → **New Application**
2. **OAuth2** → **Redirects** → add `http://localhost` → Save
3. Copy the **Client ID** (General Information) and the **Client Secret** (OAuth2)
4. Paste both into the plugin's setup screen, then press **Authorize with Discord**

Discord pops a consent window *inside the Discord client*. Do this once in desktop mode — it's much easier to click there. After that the plugin stores the token and reconnects on its own.

The token is written to `~/homebrew/settings/Discord Deck/config.json` with `0600` permissions. Treat that file like a password.

## Build

```bash
pnpm i
pnpm run build
```

## Install onto the Deck

Copy the plugin folder to the Deck and drop it in place:

```bash
# on the Deck, from the built plugin folder
sudo cp -r . /home/deck/homebrew/plugins/discord-deck
sudo chown -R root:root /home/deck/homebrew/plugins/discord-deck
sudo systemctl restart plugin_loader
```

The installed folder needs at minimum: `dist/index.js`, `main.py`, `plugin.json`, `package.json`, `LICENSE`.

## Notes and rough edges

**Discord in Game Mode.** If Discord isn't running, pressing Connect/Authorize (or the "Launch Discord in background" button) starts it minimized automatically — no need to switch to Desktop Mode or add it as a non-Steam game. It looks for a Flatpak install first (Discord, Canary, PTB, Vesktop, GoofCord), then falls back to a native binary on `PATH`. If nothing is found, it'll say so — install Discord once in Desktop Mode and this stops being needed.

**Discord's RPC voice lock.** While an app is changing voice settings over RPC, Discord locks those settings to that app, and they revert to their previous values when the app disconnects. That's Discord's behaviour, not a bug here — if your mic device snaps back after the plugin disconnects, this is why. System-level device switching (the "System audio" section) is unaffected.

**Flatpak sockets.** Flatpak Discord puts its socket at `$XDG_RUNTIME_DIR/app/com.discordapp.Discord/discord-ipc-0`. The backend already looks there, so no symlink is needed. If you use a fork not in the list, add its path to `candidate_sockets()` in `main.py`.

**Stage channels** (type 13) show up in the channel list but joining one behaves like Discord's stage join.

**Your own speaking indicator sensitivity.** This is a simple volume-threshold detector (default: about -35dBFS, with a 400ms hangover so it doesn't flicker between words), not the same voice-activity detection Discord itself uses internally. If it's too sensitive (lighting up on background noise) or not sensitive enough (missing quiet speech), the threshold is the `_VAD_THRESHOLD_DB` constant near the top of `main.py`.

## Troubleshooting

Logs: `~/homebrew/logs/Discord Deck/`

| Symptom | Cause |
| --- | --- |
| "No Discord IPC socket found" | Discord isn't running, or is running as a different user |
| "Not authorized yet" | Token missing or revoked — press Authorize again |
| Authorize times out | The consent window is waiting behind the game overlay; do it in desktop mode |
| Empty system device list | `pw-dump` missing or the backend can't see `XDG_RUNTIME_DIR` |
| 401 on token exchange | Client secret is wrong, or `http://localhost` isn't a registered redirect URI |
