#!/usr/bin/env python3
"""Xbox-style "who's talking" cards drawn over games in Game Mode.

Started by Discord Deck's backend with the system Python (it needs GTK, which
Decky's bundled Python lacks) and fed one JSON object per line on stdin:

  {"speakers": [{"id": "...", "name": "...", "avatar": "https://..."}],
   "corner": "tr", "opacity": 0.75, "scale": 1.0}

and, when someone joins or leaves the call, a one-off

  {"notice": {"id": "...", "name": "...", "avatar": "...", "kind": "join"}}

Gamescope only composites windows it is told about on top of a game. The
window carries GAMESCOPE_EXTERNAL_OVERLAY, the same flag MangoHud's overlay
uses, covers the whole screen and is transparent apart from the cards. It
never takes input: its input region is empty.

Gamescope draws only one external overlay at a time, so while MangoHud's
performance overlay is showing the cards stay hidden and MangoHud keeps
the screen; they come back once it's turned off.
"""
import colorsys
import glob
import json
import math
import os
import re
import subprocess
import sys
import threading
import time
import urllib.request

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkX11", "3.0")
gi.require_version("PangoCairo", "1.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gdk, GdkPixbuf, GdkX11, GLib, Gtk, Pango, PangoCairo  # noqa: E402
import cairo  # noqa: E402

# A card stays up this long after someone stops talking, then fades out.
LINGER = 1.0
FADE = 0.3
# How long a "joined" / "left" toast stays open, how long its icon takes
# to pop in and how long the pill takes to open (and later to close).
NOTICE = 3.5
POP = 0.15
OPEN = 0.35
NOTICE_H = 72
# A leave toast is grey; a join toast takes the speaking ring colour.
LEAVE_GREY = (0.27, 0.28, 0.30)
BADGE_GREY = (0.45, 0.46, 0.48)
MARGIN = 32
CARD_H = 48
GAP = 6
AVATAR = 36
DEFAULT_RING = (0.23, 0.65, 0.36)


def parse_color(text):
    """CSS hsl()/hex/rgb() as an (r, g, b) tuple of floats."""
    m = re.match(r"hsla?\(\s*([\d.]+)[^\d.]+([\d.]+)%[^\d.]+([\d.]+)%", text or "")
    if m:
        h, s, l = float(m.group(1)) / 360, float(m.group(2)) / 100, float(m.group(3)) / 100
        return colorsys.hls_to_rgb(h, l, s)
    rgba = Gdk.RGBA()
    if text and rgba.parse(text):
        return (rgba.red, rgba.green, rgba.blue)
    return DEFAULT_RING


def output_size():
    """The real size of the screen gamescope is driving, or None.

    Gamescope runs Steam's X server at a lower size (1920x1080 on a 4K TV)
    and scales apps up, but draws external overlays 1:1 in output pixels.
    A window sized to the X screen then only covers the top-left corner, so
    size it to the output instead, like MangoHud does. Gamescope uses the
    display's preferred mode, which is the first line of `modes` for the
    connected external connector."""
    for status in sorted(glob.glob("/sys/class/drm/card*-*/status")):
        conn = os.path.dirname(status)
        if "eDP" in os.path.basename(conn) or "Writeback" in conn:
            continue
        try:
            with open(status) as f:
                if f.read().strip() != "connected":
                    continue
            with open(os.path.join(conn, "modes")) as f:
                first = f.readline().strip()
        except OSError:
            continue
        m = re.match(r"(\d+)x(\d+)", first)
        if m:
            return int(m.group(1)), int(m.group(2))
    return None


def mangohud_showing():
    """True while Steam's performance overlay (MangoHud's mangoapp) is on.
    Steam writes the level into mangoapp's config file; "no_display" there
    means it's off."""
    for comm in glob.glob("/proc/[0-9]*/comm"):
        try:
            with open(comm) as f:
                if f.read().strip() != "mangoapp":
                    continue
            with open(comm[:-4] + "environ", "rb") as f:
                env = dict(v.split(b"=", 1) for v in f.read().split(b"\0") if b"=" in v)
            path = env.get(b"MANGOHUD_CONFIGFILE")
            if not path:
                return True
            with open(path, errors="replace") as f:
                lines = [l.strip() for l in f]
            return "no_display" not in lines
        except OSError:
            continue
    return False


def circle(cr, cx, cy, r):
    cr.new_path()
    cr.arc(cx, cy, r, 0, 2 * math.pi)
    cr.close_path()


def toast_colours(ring):
    """Pill, badge and text colours for a join toast in the ring colour:
    the pill a shade deeper, the badge a shade lighter, like the Xbox
    green toast, and dark text if the colour is too light for white."""
    pill = tuple(c * 0.8 for c in ring)
    badge = tuple(c + (1 - c) * 0.3 for c in ring)
    lum = 0.2126 * pill[0] + 0.7152 * pill[1] + 0.0722 * pill[2]
    text = (0.08, 0.08, 0.09) if lum > 0.55 else (1.0, 1.0, 1.0)
    return pill, badge, text


def rounded(cr, x, y, w, h, r):
    cr.new_path()
    cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
    cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
    cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
    cr.close_path()


class Overlay(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.POPUP)
        self.set_app_paintable(True)
        self.set_decorated(False)
        self.set_accept_focus(False)
        self.set_keep_above(True)
        screen = self.get_screen()
        visual = screen.get_rgba_visual()
        if visual is not None:
            self.set_visual(visual)
        geo = Gdk.Display.get_default().get_monitor(0).get_geometry()
        self.screen_w, self.screen_h = geo.width, geo.height
        self.width, self.height = geo.width, geo.height
        # Window pixels per design pixel. Cards are designed for a 1080-line
        # screen and scaled by the window's height over 1080, so the Size
        # setting looks the same on 1080p, 1440p and 4K, on the desktop or
        # in Game Mode.
        self.k = 1.0
        self.fit_output()
        self.move(0, 0)
        self.set_default_size(self.width, self.height)
        GLib.timeout_add_seconds(3, self.refit)
        self.connect("draw", self.on_draw)
        self.connect("realize", self.on_realize)

        self.settings = {"corner": "tr", "opacity": 0.75, "scale": 1.0}
        self.ring = DEFAULT_RING
        # id -> {"name", "avatar", "last" (time last seen speaking)}
        self.cards = {}
        self.order = []
        # One-off join/leave cards: {"name", "avatar", "kind", "t"}.
        self.notices = []
        self.avatars = {}  # url -> GdkPixbuf or None while loading
        self.visible_now = False
        self.mangohud = False
        self.next_mangohud_check = 0.0
        GLib.timeout_add(50, self.tick)

    def fit_output(self):
        size = output_size()
        if size is None or size[0] < self.screen_w:
            size = (self.screen_w, self.screen_h)
        w, h = size
        changed = (w, h) != (self.width, self.height)
        self.width, self.height = w, h
        self.k = h / 1080.0
        return changed

    def refit(self):
        # The output can change under us (1080p fallback <-> 4K).
        if self.fit_output():
            self.resize(self.width, self.height)
            self.move(0, 0)
            self.queue_draw()
        return True

    def on_realize(self, _w):
        # Clicks and controller input go straight through to the game.
        self.get_window().input_shape_combine_region(cairo.Region(), 0, 0)
        xid = self.get_window().get_xid()
        atom = "GAMESCOPE_EXTERNAL_OVERLAY"
        subprocess.run(
            ["xprop", "-id", str(xid), "-f", atom, "32c", "-set", atom, "1"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False,
        )

    # ----------------------------------------------------------- input --

    def update(self, msg):
        for key in ("corner", "opacity", "scale"):
            if key in msg:
                self.settings[key] = msg[key]
        if "ring" in msg:
            self.ring = parse_color(msg["ring"])
        notice = msg.get("notice")
        if isinstance(notice, dict):
            self.notices.append({
                "name": notice.get("name") or "Someone",
                "avatar": notice.get("avatar"),
                "kind": "leave" if notice.get("kind") == "leave" else "join",
                "t": time.monotonic(),
            })
            self.want_avatar(notice.get("avatar"))
        if "speakers" in msg:
            now = time.monotonic()
            for s in msg["speakers"]:
                sid = str(s.get("id"))
                card = self.cards.get(sid)
                if card is None:
                    card = self.cards[sid] = {}
                    self.order.append(sid)
                card.update(name=s.get("name") or "?", avatar=s.get("avatar"), last=now, live=True)
                self.want_avatar(card["avatar"])
            live = {str(s.get("id")) for s in msg["speakers"]}
            for sid, card in self.cards.items():
                if sid not in live and card.get("live"):
                    card["live"] = False
                    card["last"] = now
        self.queue_draw()

    def want_avatar(self, url):
        if not url or url in self.avatars:
            return
        self.avatars[url] = None

        def fetch():
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "DiscordDeck"})
                data = urllib.request.urlopen(req, timeout=10).read()
                loader = GdkPixbuf.PixbufLoader()
                loader.write(data)
                loader.close()
                pix = loader.get_pixbuf()
                GLib.idle_add(self.got_avatar, url, pix)
            except Exception:
                pass

        threading.Thread(target=fetch, daemon=True).start()

    def got_avatar(self, url, pix):
        self.avatars[url] = pix
        self.queue_draw()
        return False

    # ------------------------------------------------------------ timing --

    def alpha_of(self, card, now):
        if card.get("live"):
            return 1.0
        gone = now - card["last"] - LINGER
        if gone <= 0:
            return 1.0
        return max(0.0, 1.0 - gone / FADE)

    def tick(self):
        now = time.monotonic()
        for sid in list(self.order):
            if self.alpha_of(self.cards[sid], now) <= 0:
                del self.cards[sid]
                self.order.remove(sid)
        self.notices = [n for n in self.notices if self.notice_alpha(n, now) > 0]
        if now >= self.next_mangohud_check:
            self.next_mangohud_check = now + 1
            self.mangohud = mangohud_showing()
        # Only one of us can be on screen; MangoHud's stats win.
        want = bool(self.order or self.notices) and not self.mangohud
        if want and not self.visible_now:
            self.show_all()
            self.visible_now = True
        elif not want and self.visible_now:
            self.hide()
            self.visible_now = False
        if want:
            self.queue_draw()
        return True

    # ----------------------------------------------------------- drawing --

    def on_draw(self, _w, cr):
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()
        cr.set_operator(cairo.OPERATOR_OVER)
        now = time.monotonic()
        scale = float(self.settings.get("scale") or 1.0) * self.k
        corner = self.settings.get("corner", "tr")
        bg = max(0.0, min(1.0, float(self.settings.get("opacity", 0.75))))
        h = CARD_H * scale
        gap = GAP * scale
        margin = MARGIN * scale
        bottom = corner.startswith("b")
        right = corner.endswith("r")
        nh = NOTICE_H * scale
        y = self.height - margin - h if bottom else margin
        for sid in self.order:
            card = self.cards[sid]
            a = self.alpha_of(card, now)
            w = self.card_width(cr, card["name"], scale)
            x = self.width - margin - w if right else margin
            self.draw_card(cr, x, y, w, h, card, a, bg, scale)
            y += -(h + gap) if bottom else (h + gap)
        # Joins and leaves pop up bottom middle like an Xbox achievement,
        # newest at the bottom.
        y = self.height - 2 * margin - nh
        for n in reversed(self.notices):
            self.draw_notice(cr, self.width / 2, y, nh, n, now, bg, scale)
            y -= nh + gap
        return False

    @staticmethod
    def notice_text(n):
        return "Joined the party" if n["kind"] == "join" else "Left the party"

    def small_layout(self, cr, text, scale):
        lay = PangoCairo.create_layout(cr)
        lay.set_font_description(Pango.FontDescription("Sans %d" % round(14 * scale)))
        lay.set_text(text, -1)
        return lay

    def notice_width(self, cr, n, scale):
        nw, _ = self.layout(cr, n["name"], scale).get_pixel_size()
        sw, _ = self.small_layout(cr, self.notice_text(n), scale).get_pixel_size()
        return NOTICE_H * scale * 1.15 + min(max(nw, sw), 280 * scale) + 32 * scale

    def notice_open(self, n, now):
        """0..1: how far the toast has slid open. The round icon pops in
        first, the pill then opens out of it, and it folds back shut
        before fading, like an Xbox achievement."""
        t = now - n["t"]
        ease = lambda v: 1 - (1 - max(0.0, min(1.0, v))) ** 3
        if t < NOTICE:
            return ease((t - POP) / OPEN)
        return 1 - ease((t - NOTICE) / OPEN)

    def notice_alpha(self, n, now):
        t = now - n["t"]
        if t < POP:
            return t / POP
        gone = t - NOTICE - OPEN
        return 1.0 if gone <= 0 else max(0.0, 1.0 - gone / FADE)

    def draw_notice(self, cr, cx, y, h, n, now, bg, scale):
        """Xbox achievement toast: a round badge holding the gamerpic, then
        a pill in the ring colour that opens out of it with "Joined the party" over
        the name in bold. Stays centred on cx while it opens."""
        a = self.notice_alpha(n, now)
        if a <= 0:
            return
        opened = self.notice_open(n, now)
        full = self.notice_width(cr, n, scale)
        w = h + (full - h) * opened
        x = cx - w / 2

        # Pill in the ring colour for a join, grey for a leave, with a faint
        # sheen along the top. Solid like the real toast, whatever the
        # background setting.
        join = n["kind"] == "join"
        if join:
            base, badge, text = toast_colours(self.ring)
        else:
            base, badge, text = LEAVE_GREY, BADGE_GREY, (1.0, 1.0, 1.0)
        rounded(cr, x, y, w, h, h / 2)
        grad = cairo.LinearGradient(0, y, 0, y + h)
        grad.add_color_stop_rgba(0, *[min(1.0, c * 1.12) for c in base], 0.95 * a)
        grad.add_color_stop_rgba(1, *[c * 0.9 for c in base], 0.95 * a)
        cr.set_source(grad)
        cr.fill()

        # Lighter round badge filling the left end, the gamerpic inside it
        # where the trophy would be. It pops in slightly larger, then
        # settles.
        t = now - n["t"]
        pop = 1.0 + 0.12 * max(0.0, 1 - abs(t - POP) / POP) if t < 2 * POP else 1.0
        r_out = h / 2 * pop
        icx, icy = x + h / 2, y + h / 2
        circle(cr, icx, icy, r_out)
        cr.set_source_rgba(*badge, a)
        cr.fill()
        av = r_out - 7 * scale
        pix = self.avatars.get(n.get("avatar"))
        cr.save()
        circle(cr, icx, icy, av)
        cr.clip()
        if pix is not None:
            size = max(1, int(2 * av))
            pix = pix.scale_simple(size, size, GdkPixbuf.InterpType.BILINEAR)
            Gdk.cairo_set_source_pixbuf(cr, pix, icx - av, icy - av)
            cr.paint_with_alpha(a)
        else:
            cr.set_source_rgba(0.35, 0.40, 0.95, a)
            cr.paint()
        cr.restore()

        # Text fades in once the pill is mostly open, clipped to it.
        ta = a * max(0.0, (opened - 0.5) / 0.5)
        if ta <= 0:
            return
        cr.save()
        rounded(cr, x, y, w, h, h / 2)
        cr.clip()
        tx = x + h + 10 * scale
        sub = self.small_layout(cr, self.notice_text(n), scale)
        name = self.layout(cr, n["name"], scale)
        name.set_width(int(280 * scale * Pango.SCALE))
        name.set_ellipsize(Pango.EllipsizeMode.END)
        _, sh = sub.get_pixel_size()
        _, nh = name.get_pixel_size()
        top = y + (h - sh - nh) / 2
        cr.move_to(tx, top)
        cr.set_source_rgba(*text, ta)
        PangoCairo.show_layout(cr, sub)
        cr.move_to(tx, top + sh)
        cr.set_source_rgba(*text, ta)
        PangoCairo.show_layout(cr, name)
        cr.restore()

    def layout(self, cr, text, scale):
        lay = PangoCairo.create_layout(cr)
        lay.set_font_description(Pango.FontDescription("Sans Bold %d" % round(15 * scale)))
        lay.set_text(text, -1)
        return lay

    def card_width(self, cr, name, scale):
        tw, _ = self.layout(cr, name, scale).get_pixel_size()
        # gamerpic | name | speaker icon
        return CARD_H * scale + min(tw, 240 * scale) + 44 * scale

    def draw_card(self, cr, x, y, w, h, card, a, bg, scale):
        """Xbox party-chat style: dark see-through pill, round gamerpic on
        the left with a coloured ring while talking, name, speaker icon."""
        live = card.get("live")
        rounded(cr, x, y, w, h, h / 2)
        cr.set_source_rgba(0.06, 0.06, 0.07, bg * a)
        cr.fill()

        # Round gamerpic, ringed in the speaking colour.
        av = AVATAR * scale
        pad = (h - av) / 2
        ax, ay = x + pad, y + pad
        r, g, b = self.ring
        circle(cr, ax + av / 2, ay + av / 2, av / 2 + 2 * scale)
        cr.set_source_rgba(r, g, b, a if live else 0.35 * a)
        cr.fill()
        pix = self.avatars.get(card.get("avatar"))
        cr.save()
        circle(cr, ax + av / 2, ay + av / 2, av / 2)
        cr.clip()
        if pix is not None:
            pix = pix.scale_simple(max(1, int(av)), max(1, int(av)), GdkPixbuf.InterpType.BILINEAR)
            Gdk.cairo_set_source_pixbuf(cr, pix, ax, ay)
            cr.paint_with_alpha(a)
        else:
            cr.set_source_rgba(0.35, 0.40, 0.95, a)
            cr.paint()
        cr.restore()

        # Name.
        lay = self.layout(cr, card["name"], scale)
        lay.set_width(int(240 * scale * Pango.SCALE))
        lay.set_ellipsize(Pango.EllipsizeMode.END)
        tw, th = lay.get_pixel_size()
        cr.move_to(x + h + 4 * scale, y + (h - th) / 2)
        cr.set_source_rgba(1, 1, 1, a)
        PangoCairo.show_layout(cr, lay)

        # Speaker with sound waves, in the speaking colour while talking.
        sx = x + w - 30 * scale
        sy = y + h / 2
        cr.set_source_rgba(*(self.ring if live else (0.7, 0.7, 0.7)), a)
        cr.new_path()
        cr.move_to(sx, sy - 3 * scale)
        cr.line_to(sx + 4 * scale, sy - 3 * scale)
        cr.line_to(sx + 9 * scale, sy - 8 * scale)
        cr.line_to(sx + 9 * scale, sy + 8 * scale)
        cr.line_to(sx + 4 * scale, sy + 3 * scale)
        cr.line_to(sx, sy + 3 * scale)
        cr.close_path()
        cr.set_line_join(cairo.LINE_JOIN_ROUND)
        cr.set_line_width(2 * scale)
        cr.fill_preserve()
        cr.stroke()
        if live:
            cr.set_line_cap(cairo.LINE_CAP_ROUND)
            cr.set_line_width(1.8 * scale)
            for rad in (5, 9):
                cr.new_path()
                cr.arc(sx + 9 * scale, sy, rad * scale, -math.pi / 4, math.pi / 4)
                cr.stroke()


def read_stdin(win):
    for line in sys.stdin:
        try:
            msg = json.loads(line)
        except ValueError:
            continue
        GLib.idle_add(lambda m=msg: (win.update(m), False)[1])
    # The backend went away: so do we.
    GLib.idle_add(Gtk.main_quit)


def main():
    win = Overlay()
    win.realize()
    threading.Thread(target=read_stdin, args=(win,), daemon=True).start()
    Gtk.main()


if __name__ == "__main__":
    main()
