#!/usr/bin/env python3
"""Xbox-style "who's talking" cards drawn over games in Game Mode.

Started by Discord Deck's backend with the system Python (it needs GTK, which
Decky's bundled Python lacks) and fed one JSON object per line on stdin:

  {"speakers": [{"id": "...", "name": "...", "avatar": "https://..."}],
   "corner": "tr", "opacity": 0.75, "scale": 1.0}

and, when someone joins or leaves the call, a one-off

  {"notice": {"id": "...", "name": "...", "avatar": "...", "kind": "join"}}

Gamescope only composites windows it is told about on top of a game. The
window carries GAMESCOPE_EXTERNAL_OVERLAY, the same flag MangoHud's overlay
uses, covers the whole screen and is transparent apart from the cards. It
never takes input: its input region is empty.
"""
import colorsys
import json
import math
import re
import subprocess
import sys
import threading
import time
import urllib.request

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkX11", "3.0")
gi.require_version("PangoCairo", "1.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gdk, GdkPixbuf, GdkX11, GLib, Gtk, Pango, PangoCairo  # noqa: E402
import cairo  # noqa: E402

# A card stays up this long after someone stops talking, then fades out.
LINGER = 1.0
FADE = 0.3
# How long a "joined" / "left" card stays up.
NOTICE = 3.0
MARGIN = 32
CARD_H = 48
GAP = 6
AVATAR = 36
DEFAULT_RING = (0.23, 0.65, 0.36)


def parse_color(text):
    """CSS hsl()/hex/rgb() as an (r, g, b) tuple of floats."""
    m = re.match(r"hsla?\(\s*([\d.]+)[^\d.]+([\d.]+)%[^\d.]+([\d.]+)%", text or "")
    if m:
        h, s, l = float(m.group(1)) / 360, float(m.group(2)) / 100, float(m.group(3)) / 100
        return colorsys.hls_to_rgb(h, l, s)
    rgba = Gdk.RGBA()
    if text and rgba.parse(text):
        return (rgba.red, rgba.green, rgba.blue)
    return DEFAULT_RING


def circle(cr, cx, cy, r):
    cr.new_path()
    cr.arc(cx, cy, r, 0, 2 * math.pi)
    cr.close_path()


def rounded(cr, x, y, w, h, r):
    cr.new_path()
    cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
    cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
    cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
    cr.close_path()


class Overlay(Gtk.Window):
    def __init__(self):
        super().__init__(type=Gtk.WindowType.POPUP)
        self.set_app_paintable(True)
        self.set_decorated(False)
        self.set_accept_focus(False)
        self.set_keep_above(True)
        screen = self.get_screen()
        visual = screen.get_rgba_visual()
        if visual is not None:
            self.set_visual(visual)
        geo = Gdk.Display.get_default().get_monitor(0).get_geometry()
        self.width, self.height = geo.width, geo.height
        self.move(0, 0)
        self.set_default_size(self.width, self.height)
        self.connect("draw", self.on_draw)
        self.connect("realize", self.on_realize)

        self.settings = {"corner": "tr", "opacity": 0.75, "scale": 1.0}
        self.ring = DEFAULT_RING
        # id -> {"name", "avatar", "last" (time last seen speaking)}
        self.cards = {}
        self.order = []
        # One-off join/leave cards: {"name", "avatar", "kind", "t"}.
        self.notices = []
        self.avatars = {}  # url -> GdkPixbuf or None while loading
        self.visible_now = False
        GLib.timeout_add(50, self.tick)

    def on_realize(self, _w):
        # Clicks and controller input go straight through to the game.
        self.get_window().input_shape_combine_region(cairo.Region(), 0, 0)
        xid = self.get_window().get_xid()
        subprocess.run(
            ["xprop", "-id", str(xid), "-f", "GAMESCOPE_EXTERNAL_OVERLAY", "32c",
             "-set", "GAMESCOPE_EXTERNAL_OVERLAY", "1"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False,
        )

    # ----------------------------------------------------------- input --

    def update(self, msg):
        for key in ("corner", "opacity", "scale"):
            if key in msg:
                self.settings[key] = msg[key]
        if "ring" in msg:
            self.ring = parse_color(msg["ring"])
        notice = msg.get("notice")
        if isinstance(notice, dict):
            self.notices.append({
                "name": notice.get("name") or "Someone",
                "avatar": notice.get("avatar"),
                "kind": "leave" if notice.get("kind") == "leave" else "join",
                "t": time.monotonic(),
            })
            self.want_avatar(notice.get("avatar"))
        if "speakers" in msg:
            now = time.monotonic()
            for s in msg["speakers"]:
                sid = str(s.get("id"))
                card = self.cards.get(sid)
                if card is None:
                    card = self.cards[sid] = {}
                    self.order.append(sid)
                card.update(name=s.get("name") or "?", avatar=s.get("avatar"), last=now, live=True)
                self.want_avatar(card["avatar"])
            live = {str(s.get("id")) for s in msg["speakers"]}
            for sid, card in self.cards.items():
                if sid not in live and card.get("live"):
                    card["live"] = False
                    card["last"] = now
        self.queue_draw()

    def want_avatar(self, url):
        if not url or url in self.avatars:
            return
        self.avatars[url] = None

        def fetch():
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "DiscordDeck"})
                data = urllib.request.urlopen(req, timeout=10).read()
                loader = GdkPixbuf.PixbufLoader()
                loader.write(data)
                loader.close()
                pix = loader.get_pixbuf()
                GLib.idle_add(self.got_avatar, url, pix)
            except Exception:
                pass

        threading.Thread(target=fetch, daemon=True).start()

    def got_avatar(self, url, pix):
        self.avatars[url] = pix
        self.queue_draw()
        return False

    # ------------------------------------------------------------ timing --

    def alpha_of(self, card, now):
        if card.get("live"):
            return 1.0
        gone = now - card["last"] - LINGER
        if gone <= 0:
            return 1.0
        return max(0.0, 1.0 - gone / FADE)

    def notice_alpha(self, n, now):
        gone = now - n["t"] - NOTICE
        return 1.0 if gone <= 0 else max(0.0, 1.0 - gone / FADE)

    def tick(self):
        now = time.monotonic()
        for sid in list(self.order):
            if self.alpha_of(self.cards[sid], now) <= 0:
                del self.cards[sid]
                self.order.remove(sid)
        self.notices = [n for n in self.notices if self.notice_alpha(n, now) > 0]
        want = bool(self.order or self.notices)
        if want and not self.visible_now:
            self.show_all()
            self.visible_now = True
        elif not want and self.visible_now:
            self.hide()
            self.visible_now = False
        if want:
            self.queue_draw()
        return True

    # ----------------------------------------------------------- drawing --

    def on_draw(self, _w, cr):
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()
        cr.set_operator(cairo.OPERATOR_OVER)
        now = time.monotonic()
        scale = float(self.settings.get("scale") or 1.0)
        corner = self.settings.get("corner", "tr")
        bg = max(0.0, min(1.0, float(self.settings.get("opacity", 0.75))))
        h = CARD_H * scale
        gap = GAP * scale
        margin = MARGIN * scale
        bottom = corner.startswith("b")
        right = corner.endswith("r")
        y = self.height - margin - h if bottom else margin
        for sid in self.order:
            card = self.cards[sid]
            a = self.alpha_of(card, now)
            w = self.card_width(cr, card["name"], scale)
            x = self.width - margin - w if right else margin
            self.draw_card(cr, x, y, w, h, card, a, bg, scale)
            y += -(h + gap) if bottom else (h + gap)
        # Joins and leaves pop up bottom middle, like Xbox notifications,
        # newest at the bottom.
        y = self.height - 2 * margin - h
        for n in reversed(self.notices):
            a = self.notice_alpha(n, now)
            w = self.notice_width(cr, n, scale)
            x = (self.width - w) / 2
            self.draw_notice(cr, x, y, w, h, n, a, bg, scale)
            y -= h + gap
        return False

    @staticmethod
    def notice_text(n):
        return "joined the party" if n["kind"] == "join" else "left the party"

    def small_layout(self, cr, text, scale):
        lay = PangoCairo.create_layout(cr)
        lay.set_font_description(Pango.FontDescription("Sans %d" % round(11 * scale)))
        lay.set_text(text, -1)
        return lay

    def notice_width(self, cr, n, scale):
        nw, _ = self.layout(cr, n["name"], scale).get_pixel_size()
        sw, _ = self.small_layout(cr, self.notice_text(n), scale).get_pixel_size()
        return CARD_H * scale + min(max(nw, sw), 240 * scale) + 26 * scale

    def draw_notice(self, cr, x, y, w, h, n, a, bg, scale):
        """Same pill as a talking card: gamerpic, then the name over a
        smaller "joined the party" / "left the party" line."""
        rounded(cr, x, y, w, h, h / 2)
        cr.set_source_rgba(0.06, 0.06, 0.07, bg * a)
        cr.fill()

        av = AVATAR * scale
        pad = (h - av) / 2
        ax, ay = x + pad, y + pad
        r, g, b = self.ring if n["kind"] == "join" else (0.55, 0.55, 0.58)
        circle(cr, ax + av / 2, ay + av / 2, av / 2 + 2 * scale)
        cr.set_source_rgba(r, g, b, a)
        cr.fill()
        pix = self.avatars.get(n.get("avatar"))
        cr.save()
        circle(cr, ax + av / 2, ay + av / 2, av / 2)
        cr.clip()
        if pix is not None:
            pix = pix.scale_simple(max(1, int(av)), max(1, int(av)), GdkPixbuf.InterpType.BILINEAR)
            Gdk.cairo_set_source_pixbuf(cr, pix, ax, ay)
            cr.paint_with_alpha(a)
        else:
            cr.set_source_rgba(0.35, 0.40, 0.95, a)
            cr.paint()
        cr.restore()

        tx = x + h + 4 * scale
        name = self.layout(cr, n["name"], scale)
        name.set_width(int(240 * scale * Pango.SCALE))
        name.set_ellipsize(Pango.EllipsizeMode.END)
        sub = self.small_layout(cr, self.notice_text(n), scale)
        _, nh = name.get_pixel_size()
        _, sh = sub.get_pixel_size()
        top = y + (h - nh - sh) / 2
        cr.move_to(tx, top)
        cr.set_source_rgba(1, 1, 1, a)
        PangoCairo.show_layout(cr, name)
        cr.move_to(tx, top + nh)
        cr.set_source_rgba(0.75, 0.75, 0.78, a)
        PangoCairo.show_layout(cr, sub)

    def layout(self, cr, text, scale):
        lay = PangoCairo.create_layout(cr)
        lay.set_font_description(Pango.FontDescription("Sans Bold %d" % round(15 * scale)))
        lay.set_text(text, -1)
        return lay

    def card_width(self, cr, name, scale):
        tw, _ = self.layout(cr, name, scale).get_pixel_size()
        # gamerpic | name | speaker icon
        return CARD_H * scale + min(tw, 240 * scale) + 44 * scale

    def draw_card(self, cr, x, y, w, h, card, a, bg, scale):
        """Xbox party-chat style: dark see-through pill, round gamerpic on
        the left with a coloured ring while talking, name, speaker icon."""
        live = card.get("live")
        rounded(cr, x, y, w, h, h / 2)
        cr.set_source_rgba(0.06, 0.06, 0.07, bg * a)
        cr.fill()

        # Round gamerpic, ringed in the speaking colour.
        av = AVATAR * scale
        pad = (h - av) / 2
        ax, ay = x + pad, y + pad
        r, g, b = self.ring
        circle(cr, ax + av / 2, ay + av / 2, av / 2 + 2 * scale)
        cr.set_source_rgba(r, g, b, a if live else 0.35 * a)
        cr.fill()
        pix = self.avatars.get(card.get("avatar"))
        cr.save()
        circle(cr, ax + av / 2, ay + av / 2, av / 2)
        cr.clip()
        if pix is not None:
            pix = pix.scale_simple(max(1, int(av)), max(1, int(av)), GdkPixbuf.InterpType.BILINEAR)
            Gdk.cairo_set_source_pixbuf(cr, pix, ax, ay)
            cr.paint_with_alpha(a)
        else:
            cr.set_source_rgba(0.35, 0.40, 0.95, a)
            cr.paint()
        cr.restore()

        # Name.
        lay = self.layout(cr, card["name"], scale)
        lay.set_width(int(240 * scale * Pango.SCALE))
        lay.set_ellipsize(Pango.EllipsizeMode.END)
        tw, th = lay.get_pixel_size()
        cr.move_to(x + h + 4 * scale, y + (h - th) / 2)
        cr.set_source_rgba(1, 1, 1, a)
        PangoCairo.show_layout(cr, lay)

        # Speaker with sound waves, in the speaking colour while talking.
        sx = x + w - 30 * scale
        sy = y + h / 2
        cr.set_source_rgba(*(self.ring if live else (0.7, 0.7, 0.7)), a)
        cr.new_path()
        cr.move_to(sx, sy - 3 * scale)
        cr.line_to(sx + 4 * scale, sy - 3 * scale)
        cr.line_to(sx + 9 * scale, sy - 8 * scale)
        cr.line_to(sx + 9 * scale, sy + 8 * scale)
        cr.line_to(sx + 4 * scale, sy + 3 * scale)
        cr.line_to(sx, sy + 3 * scale)
        cr.close_path()
        cr.set_line_join(cairo.LINE_JOIN_ROUND)
        cr.set_line_width(2 * scale)
        cr.fill_preserve()
        cr.stroke()
        if live:
            cr.set_line_cap(cairo.LINE_CAP_ROUND)
            cr.set_line_width(1.8 * scale)
            for rad in (5, 9):
                cr.new_path()
                cr.arc(sx + 9 * scale, sy, rad * scale, -math.pi / 4, math.pi / 4)
                cr.stroke()


def read_stdin(win):
    for line in sys.stdin:
        try:
            msg = json.loads(line)
        except ValueError:
            continue
        GLib.idle_add(lambda m=msg: (win.update(m), False)[1])
    # The backend went away: so do we.
    GLib.idle_add(Gtk.main_quit)


def main():
    win = Overlay()
    win.realize()
    threading.Thread(target=read_stdin, args=(win,), daemon=True).start()
    Gtk.main()


if __name__ == "__main__":
    main()
