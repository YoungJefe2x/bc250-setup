import array
import asyncio
import json
import math
import os
import re
import shutil
import socket
import ssl
import struct
import subprocess
import uuid
import urllib.error
import urllib.parse
import urllib.request

import decky

# ---------------------------------------------------------------- constants --

TOKEN_URL = "https://discord.com/api/oauth2/token"
REDIRECT_URI = "http://localhost"
SCOPES = ["rpc", "rpc.voice.read", "rpc.voice.write", "identify"]

_CACERT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "certs", "cacert.pem")


def _ssl_context() -> ssl.SSLContext:
    # Decky's plugin_loader runs main.py as root under systemd, which on
    # SteamOS often can't locate (or trust) the system CA bundle, causing
    # CERTIFICATE_VERIFY_FAILED. Load a known-good bundle we ship ourselves
    # instead of depending on the host's OpenSSL default paths.
    if os.path.isfile(_CACERT_PATH):
        try:
            return ssl.create_default_context(cafile=_CACERT_PATH)
        except Exception as e:
            decky.logger.warning("Could not load bundled CA file, falling back: %s", e)
    return ssl.create_default_context()

OP_HANDSHAKE = 0
OP_FRAME = 1
OP_CLOSE = 2
OP_PING = 3
OP_PONG = 4

CONFIG_PATH = os.path.join(decky.DECKY_PLUGIN_SETTINGS_DIR, "config.json")

VOICE_CHANNEL_TYPES = (2, 13)  # 2 = voice, 13 = stage
VOICE_MEMBER_EVENTS = (
    "VOICE_STATE_CREATE",
    "VOICE_STATE_UPDATE",
    "VOICE_STATE_DELETE",
    "SPEAKING_START",
    "SPEAKING_STOP",
)


def runtime_dir() -> str:
    d = os.environ.get("XDG_RUNTIME_DIR")
    if d and os.path.isdir(d):
        return d
    try:
        import pwd

        uid = pwd.getpwnam(decky.DECKY_USER).pw_uid
    except Exception:
        uid = os.getuid()
    return "/run/user/%d" % uid


def read_config() -> dict:
    try:
        with open(CONFIG_PATH, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def write_config(cfg: dict) -> None:
    os.makedirs(decky.DECKY_PLUGIN_SETTINGS_DIR, exist_ok=True)
    tmp = CONFIG_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(cfg, f, indent=2)
    os.replace(tmp, CONFIG_PATH)
    try:
        os.chmod(CONFIG_PATH, 0o600)
    except Exception:
        pass


def _find_session_env() -> dict:
    """main.py runs under Decky's systemd service, which has no DISPLAY,
    WAYLAND_DISPLAY, or D-Bus session info — none of gamescope's session
    environment. A plain GUI process (even one that never shows a window)
    still needs that to connect to the compositor at all, or it crashes on
    startup. Steam itself is always running as a client inside that session
    with the right vars set, so borrow them from its /proc environ."""
    keys = ("DISPLAY", "WAYLAND_DISPLAY", "XDG_SESSION_TYPE", "DBUS_SESSION_BUS_ADDRESS", "XAUTHORITY")
    candidates = ("steam", "steamwebhelper", "gamescope", "gamescopereaper")
    found: dict = {}
    try:
        for pid in os.listdir("/proc"):
            if not pid.isdigit():
                continue
            try:
                with open("/proc/%s/comm" % pid) as f:
                    comm = f.read().strip()
            except Exception:
                continue
            if comm not in candidates:
                continue
            try:
                with open("/proc/%s/environ" % pid, "rb") as f:
                    raw = f.read()
            except Exception:
                continue
            env = {}
            for item in raw.split(b"\0"):
                if b"=" not in item:
                    continue
                k, _, v = item.partition(b"=")
                env[k.decode(errors="replace")] = v.decode(errors="replace")
            got_display = "DISPLAY" in env or "WAYLAND_DISPLAY" in env
            for k in keys:
                if k in env and k not in found:
                    found[k] = env[k]
            if comm == "steam" and got_display:
                break  # steam's own env is the most reliable; stop once found
    except Exception:
        decky.logger.exception("_find_session_env failed")
    return found


# ------------------------------------------------------------- discord ipc ---


class RPCError(Exception):
    pass


DISCORD_FLATPAK_IDS = [
    "com.discordapp.Discord",
    "com.discordapp.DiscordCanary",
    "com.discordapp.DiscordPTB",
    "dev.vencord.Vesktop",
    "io.github.milkshiift.GoofCord",
]
DISCORD_NATIVE_BINS = ["discord", "discord-canary", "discord-ptb", "vesktop"]


async def _find_discord_launcher():
    """Return a command list to start Discord minimized in the background,
    or None if no installed Discord-compatible client was found. Checks
    Flatpak first (most common on SteamOS) then plain $PATH binaries."""
    if shutil.which("flatpak"):
        rc, out, _err = await _run(["flatpak", "list", "--app", "--columns=application"], timeout=10)
        if rc == 0:
            installed = set(out.split())
            for app_id in DISCORD_FLATPAK_IDS:
                if app_id in installed:
                    return ["flatpak", "run", app_id, "--start-minimized"]
    for bin_name in DISCORD_NATIVE_BINS:
        path = shutil.which(bin_name)
        if path:
            return [path, "--start-minimized"]
    return None


async def _discord_steam_command():
    """(exe, launch options, flatpak app id or None) for running Discord as a
    normal on-screen window from the Steam library, or None if not installed."""
    if shutil.which("flatpak"):
        rc, out, _err = await _run(["flatpak", "list", "--app", "--columns=application"], timeout=10)
        if rc == 0:
            installed = set(out.split())
            for app_id in DISCORD_FLATPAK_IDS:
                if app_id in installed:
                    return shutil.which("flatpak"), "run " + app_id, app_id
    for bin_name in DISCORD_NATIVE_BINS:
        path = shutil.which(bin_name)
        if path:
            return path, "", None
    return None


# Process names of the native clients, for closing a background copy.
DISCORD_PROCESS_NAMES = ["Discord", "DiscordCanary", "DiscordPTB", "vesktop"]


_ENV_STRIP_KEYS = ("LD_LIBRARY_PATH", "LD_PRELOAD", "PYTHONHOME", "PYTHONPATH")


def _clean_subprocess_env(base: dict) -> dict:
    """main.py runs inside Decky's own bundled Python environment, which
    sets LD_LIBRARY_PATH (and similar) to point at its own shared libraries.
    Copying that wholesale into an external GUI process's environment can
    make it load an incompatible library instead of the system one — this
    is exactly what broke launching Discord: /bin/sh crashed with a
    readline symbol mismatch because it inherited Decky's LD_LIBRARY_PATH.
    Strip these before spawning anything outside the plugin itself."""
    env = dict(base)
    for k in _ENV_STRIP_KEYS:
        env.pop(k, None)
    return env


async def launch_discord_background():
    """Start Discord (or a compatible client) minimized/in the background.
    Raises RuntimeError if nothing installed could be found, or if the
    process exits immediately (most likely missing display/session env)."""
    cmd = await _find_discord_launcher()
    if not cmd:
        raise RuntimeError(
            "Could not find a Discord install to launch (checked Flatpak apps and PATH)"
        )
    env = _clean_subprocess_env(os.environ)
    env.setdefault("XDG_RUNTIME_DIR", runtime_dir())
    session_env = await asyncio.get_event_loop().run_in_executor(None, _find_session_env)
    decky.logger.info("launch_discord_background: borrowed session env: %s", session_env)
    env.update(session_env)
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.PIPE,
        stdin=asyncio.subprocess.DEVNULL,
        env=env,
        start_new_session=True,  # detach so it outlives this call
    )
    decky.logger.info("launched Discord: %s (pid %s)", cmd, proc.pid)

    # A GUI app that can't reach the compositor typically dies within a
    # second or two. Give it a moment, then check it's actually still alive
    # instead of reporting success just because the fork succeeded.
    await asyncio.sleep(2.5)
    if proc.returncode is not None:
        try:
            err = (await asyncio.wait_for(proc.stderr.read(4000), timeout=1)).decode(errors="replace")
        except Exception:
            err = ""
        decky.logger.warning(
            "Discord exited immediately (code %s), session_env=%s: %s",
            proc.returncode, session_env, err.strip()[-1500:],
        )
        detail = err.strip().splitlines()[-1] if err.strip() else ""
        raise RuntimeError(
            "Discord exited immediately after launch (code %s)%s%s"
            % (
                proc.returncode,
                " — no display/session env found" if not session_env else "",
                (": %s" % detail) if detail else "",
            )
        )
    return cmd


class DiscordIPC:
    """Minimal Discord RPC client over the local IPC socket."""

    def __init__(self):
        self.reader = None
        self.writer = None
        self.socket_path = None
        self.pending = {}
        self.reader_task = None
        self.user = None
        self.authenticated = False
        # Sync callback: (evt: str, data: dict) -> None. Fired for pushed
        # DISPATCH events from an active SUBSCRIBE. Must not block/await.
        self.on_event = None

    # -- transport ------------------------------------------------------------

    @staticmethod
    def candidate_sockets():
        base = runtime_dir()
        roots = [
            base,
            os.path.join(base, "app", "com.discordapp.Discord"),
            os.path.join(base, "app", "com.discordapp.DiscordCanary"),
            os.path.join(base, "app", "com.discordapp.DiscordPTB"),
            os.path.join(base, "app", "dev.vencord.Vesktop"),
            os.path.join(base, "app", "io.github.milkshiift.GoofCord"),
            os.path.join(base, "snap.discord"),
            "/tmp",
        ]
        found = []
        for root in roots:
            for i in range(10):
                path = os.path.join(root, "discord-ipc-%d" % i)
                if os.path.exists(path):
                    found.append(path)
        return found

    def connected(self) -> bool:
        return self.writer is not None and not self.writer.is_closing()

    async def _send(self, op: int, payload: dict) -> None:
        raw = json.dumps(payload).encode("utf-8")
        self.writer.write(struct.pack("<II", op, len(raw)) + raw)
        await self.writer.drain()

    async def _recv(self):
        header = await self.reader.readexactly(8)
        op, length = struct.unpack("<II", header)
        body = await self.reader.readexactly(length) if length else b"{}"
        return op, json.loads(body.decode("utf-8"))

    async def _read_loop(self):
        try:
            while True:
                op, payload = await self._recv()
                if op == OP_PING:
                    await self._send(OP_PONG, payload)
                    continue
                if op == OP_CLOSE:
                    break
                nonce = payload.get("nonce")
                fut = self.pending.pop(nonce, None) if nonce else None
                if fut and not fut.done():
                    if payload.get("evt") == "ERROR":
                        data = payload.get("data") or {}
                        fut.set_exception(
                            RPCError(data.get("message", "Discord returned an error"))
                        )
                    else:
                        fut.set_result(payload.get("data"))
                elif not nonce and payload.get("cmd") == "DISPATCH":
                    # A pushed event from a SUBSCRIBE'd stream (voice state
                    # changes, speaking start/stop, etc). Never await new IPC
                    # requests here — the read loop has to keep looping to
                    # receive their responses. on_event should be quick and
                    # schedule any follow-up work itself (e.g. via
                    # asyncio.create_task).
                    evt = payload.get("evt")
                    if evt and self.on_event:
                        try:
                            self.on_event(evt, payload.get("data") or {})
                        except Exception:
                            decky.logger.exception("on_event handler failed for %s", evt)
        except (asyncio.IncompleteReadError, ConnectionError, asyncio.CancelledError):
            pass
        except Exception as e:
            decky.logger.warning("RPC read loop stopped: %s", e)
        finally:
            for fut in self.pending.values():
                if not fut.done():
                    fut.set_exception(RPCError("Discord connection closed"))
            self.pending.clear()
            self.authenticated = False

    async def close(self):
        if self.reader_task:
            self.reader_task.cancel()
            self.reader_task = None
        if self.writer:
            try:
                self.writer.close()
                await self.writer.wait_closed()
            except Exception:
                pass
        self.reader = self.writer = None
        self.socket_path = None
        self.authenticated = False
        self.user = None

    async def connect(self, client_id: str):
        await self.close()
        sockets = self.candidate_sockets()
        if not sockets:
            raise RPCError("No Discord IPC socket found — is Discord running?")
        last = None
        for path in sockets:
            try:
                self.reader, self.writer = await asyncio.open_unix_connection(path)
                await self._send(OP_HANDSHAKE, {"v": 1, "client_id": str(client_id)})
                op, payload = await asyncio.wait_for(self._recv(), timeout=10)
                if payload.get("evt") != "READY":
                    raise RPCError("Handshake failed: %s" % json.dumps(payload)[:200])
                self.socket_path = path
                self.user = (payload.get("data") or {}).get("user")
                self.reader_task = asyncio.create_task(self._read_loop())
                return payload.get("data")
            except Exception as e:
                last = e
                await self.close()
        raise RPCError("Could not connect to Discord: %s" % last)

    async def request(self, cmd: str, args: dict = None, timeout: float = 15, evt: str = None):
        if not self.connected():
            raise RPCError("Not connected to Discord")
        nonce = str(uuid.uuid4())
        fut = asyncio.get_event_loop().create_future()
        self.pending[nonce] = fut
        frame = {"cmd": cmd, "args": args or {}, "nonce": nonce}
        if evt:
            frame["evt"] = evt
        await self._send(OP_FRAME, frame)
        try:
            return await asyncio.wait_for(fut, timeout=timeout)
        except asyncio.TimeoutError:
            self.pending.pop(nonce, None)
            raise RPCError("%s timed out" % cmd)

    # -- auth -----------------------------------------------------------------

    async def authenticate(self, access_token: str):
        data = await self.request("AUTHENTICATE", {"access_token": access_token})
        self.authenticated = True
        self.user = (data or {}).get("user", self.user)
        return data

    async def authorize(self, client_id: str, scopes=None):
        # Pops a consent modal inside the Discord client; give the user time.
        data = await self.request(
            "AUTHORIZE",
            {"client_id": str(client_id), "scopes": scopes or SCOPES},
            timeout=180,
        )
        return data["code"]


def _post_form(url: str, fields: dict) -> dict:
    body = urllib.parse.urlencode(fields).encode()
    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            # Discord's edge (Cloudflare) blocks the default Python-urllib/x.y
            # User-Agent as a bot fingerprint (error code 1010). Any normal,
            # descriptive UA avoids that; this isn't spoofing a browser.
            "User-Agent": "DiscordDeck/0.1 (+https://github.com/) Python-urllib",
            "Accept": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=20, context=_ssl_context()) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        raw = e.read().decode(errors="replace")
        try:
            body_json = json.loads(raw)
            reason = body_json.get("error_description") or body_json.get("error") or raw
        except Exception:
            reason = raw or e.reason
        msg = "Discord rejected the token request (%s): %s" % (e.code, reason)
        if "redirect_uri" in str(reason).lower():
            msg += " — check that http://localhost is registered exactly under OAuth2 > Redirects"
        raise RPCError(msg) from None
    except urllib.error.URLError as e:
        raise RPCError("Could not reach discord.com: %s" % e.reason) from None


# ---------------------------------------------------------------- pipewire ---


async def _run(argv, timeout=10):
    env = _clean_subprocess_env(os.environ)
    env.setdefault("XDG_RUNTIME_DIR", runtime_dir())
    proc = await asyncio.create_subprocess_exec(
        *argv,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env,
    )
    out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    return proc.returncode, out.decode(errors="replace"), err.decode(errors="replace")


_WPCTL_ROW_RE = re.compile(r"^[^\d*]*(\*)?\s*(\d+)\.\s+(.*)$")
_WPCTL_SUFFIX_RE = re.compile(r"\s*\[[^\]]*\]\s*$")


async def pipewire_devices():
    """Return system audio sinks/sources and the current defaults, parsed
    from `wpctl status` — the same tool `set_system_default` uses to change
    the default, so its answer can't drift from what we just set. (Earlier
    this read pw-dump's "default" Metadata object instead, but that object
    was never populated on this WirePlumber build — logs showed
    default_metadata_found=False on every call — so defaults always read as
    unset regardless of what was actually selected.)"""
    rc, out, err = await _run(["wpctl", "status"], timeout=15)
    if rc != 0:
        raise RuntimeError(err.strip() or "wpctl status failed")

    sinks, sources = [], []
    default_sink_id = default_source_id = None
    group = None
    section = None

    for line in out.splitlines():
        stripped = line.strip()
        if stripped in ("Audio", "Video", "Midi", "Settings"):
            group = stripped
            section = None
            continue
        if group != "Audio":
            continue
        if "Sinks:" in line:
            section = "sinks"
            continue
        if "Sources:" in line:
            section = "sources"
            continue
        if "Devices:" in line or "Filters:" in line or "Streams:" in line:
            section = None
            continue
        if section not in ("sinks", "sources"):
            continue

        m = _WPCTL_ROW_RE.match(line)
        if not m:
            continue
        is_default = bool(m.group(1))
        node_id = int(m.group(2))
        name = _WPCTL_SUFFIX_RE.sub("", m.group(3)).strip()
        entry = {"id": node_id, "name": name, "label": name}
        if section == "sinks":
            sinks.append(entry)
            if is_default:
                default_sink_id = node_id
        else:
            sources.append(entry)
            if is_default:
                default_source_id = node_id

    decky.logger.info(
        "pipewire_devices (wpctl status): sinks=%s sources=%s default_sink_id=%s default_source_id=%s",
        [(s["id"], s["name"]) for s in sinks],
        [(s["id"], s["name"]) for s in sources],
        default_sink_id,
        default_source_id,
    )

    return {
        "sinks": sinks,
        "sources": sources,
        "default_sink_id": default_sink_id,
        "default_source_id": default_source_id,
    }


# -------------------------------------------------------- self speech vad ---

# Roughly -35dBFS. Quiet rooms/background noise usually sit well below this;
# normal speaking volume comfortably clears it. Tunable if it proves too
# sensitive/insensitive once tested on real hardware.
_VAD_THRESHOLD_DB = -35.0
# Keep "speaking" true for a bit after level drops, so brief gaps between
# words/syllables don't cause the ring to flicker on and off.
_VAD_HANGOVER_SEC = 0.4
_VAD_SAMPLE_RATE = 16000
_VAD_CHUNK_SAMPLES = 320  # 20ms per chunk at 16kHz


def _pcm_rms_db(chunk: bytes) -> float:
    if len(chunk) < 2:
        return -100.0
    samples = array.array("h")
    samples.frombytes(chunk[: len(chunk) - (len(chunk) % 2)])
    if not samples:
        return -100.0
    mean_sq = sum(s * s for s in samples) / len(samples)
    if mean_sq <= 0:
        return -100.0
    rms = math.sqrt(mean_sq) / 32768.0
    if rms <= 0:
        return -100.0
    return 20.0 * math.log10(rms)


class SelfSpeechDetector:
    """Discord's RPC never sends SPEAKING_START/STOP for the local user —
    only for other participants (the same asymmetry as GET_CHANNEL excluding
    your own voice state). To highlight your own avatar while you talk, this
    reads raw audio directly from your mic via `pw-cat` and derives a
    speaking boolean locally. Audio is only ever used to compute a level
    and is immediately discarded — nothing is stored or transmitted."""

    def __init__(self, on_change):
        self.on_change = on_change  # async fn(is_speaking: bool)
        self.task = None
        self.proc = None
        self.speaking = False
        self.muted = False

    def set_muted(self, muted: bool):
        self.muted = muted
        if muted and self.speaking:
            # Don't wait for the mic to go quiet — muted means silent now.
            self.speaking = False
            asyncio.create_task(self._safe_notify(False))

    async def _safe_notify(self, value: bool):
        try:
            await self.on_change(value)
        except Exception:
            decky.logger.exception("SelfSpeechDetector on_change failed")

    async def start(self, source_id):
        await self.stop()
        env = _clean_subprocess_env(os.environ)
        env.setdefault("XDG_RUNTIME_DIR", runtime_dir())
        try:
            self.proc = await asyncio.create_subprocess_exec(
                "pw-cat",
                "--record",
                "--target", str(source_id),
                "--format", "s16",
                "--rate", str(_VAD_SAMPLE_RATE),
                "--channels", "1",
                "-",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
                stdin=asyncio.subprocess.DEVNULL,
                env=env,
            )
        except Exception:
            decky.logger.exception("SelfSpeechDetector: failed to start pw-cat")
            return
        decky.logger.info("SelfSpeechDetector: monitoring source %s (pid %s)", source_id, self.proc.pid)
        self.task = asyncio.create_task(self._run())

    async def stop(self):
        if self.task:
            self.task.cancel()
            self.task = None
        if self.proc:
            try:
                self.proc.kill()
                await self.proc.wait()
            except Exception:
                pass
            self.proc = None
        if self.speaking:
            self.speaking = False
            await self._safe_notify(False)

    async def _run(self):
        chunk_bytes = _VAD_CHUNK_SAMPLES * 2  # 16-bit samples
        last_loud = 0.0
        loop = asyncio.get_event_loop()
        try:
            while True:
                chunk = await self.proc.stdout.readexactly(chunk_bytes)
                level_db = _pcm_rms_db(chunk)
                now = loop.time()
                if not self.muted and level_db > _VAD_THRESHOLD_DB:
                    last_loud = now
                is_speaking = (not self.muted) and (now - last_loud < _VAD_HANGOVER_SEC)
                if is_speaking != self.speaking:
                    self.speaking = is_speaking
                    await self._safe_notify(is_speaking)
        except (asyncio.IncompleteReadError, asyncio.CancelledError):
            pass
        except Exception:
            decky.logger.exception("SelfSpeechDetector: read loop stopped")


# ------------------------------------------------------------------ plugin ---


def _logged(fn):
    """Log every call to a Plugin method and any exception it raises, so
    failures triggered from the QAM UI (dropdowns, buttons) always show up
    in the plugin's log file even without touching each method by hand."""
    name = fn.__name__

    async def wrapper(self, *args, **kwargs):
        decky.logger.info("%s called args=%r kwargs=%r", name, args, kwargs)
        try:
            result = await fn(self, *args, **kwargs)
            decky.logger.info("%s ok", name)
            return result
        except Exception:
            decky.logger.exception("%s failed", name)
            raise

    wrapper.__name__ = name
    return wrapper


DEFAULT_RING_COLOR = "hsl(145, 65%, 39%)"  # matches the original hardcoded green
# How long the overlay needs after its last card to fade out completely.
LINGER_STOP = 1.5

OVERLAY_SCRIPT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "overlay.py")
# The overlay needs GTK, which Decky's bundled Python doesn't have, so it runs
# under the system Python.
SYSTEM_PYTHON = "/usr/bin/python3"
OVERLAY_DEFAULTS = {
    "enabled": True,
    "corner": "tr",      # tl, tr, bl, br
    "opacity": 75,       # card background, percent
    "scale": 100,        # card size, percent
    "show_self": True,
    "show_joins": True,  # "joined the party" / "left the party" cards
}


def _avatar_url(user: dict) -> str:
    """Same rules as the panel's avatarUrl()."""
    uid = str(user.get("id") or "0")
    if user.get("avatar"):
        return "https://cdn.discordapp.com/avatars/%s/%s.png?size=80" % (uid, user["avatar"])
    disc = str(user.get("discriminator") or "0")
    if disc == "0":
        index = (int(uid) >> 22) % 6 if uid.isdigit() else 0
    else:
        index = int(disc) % 5 if disc.isdigit() else 0
    return "https://cdn.discordapp.com/embed/avatars/%d.png" % index


def _display_name(user: dict, nick=None) -> str:
    return nick or user.get("global_name") or user.get("username") or "?"


class SpeakingOverlay:
    """Runs overlay.py (Xbox-style "who's talking" cards drawn by gamescope
    over games) and keeps it fed with who is speaking and how to draw it."""

    def __init__(self):
        self.proc = None
        self.error = None
        self._stderr_task = None

    def running(self) -> bool:
        return self.proc is not None and self.proc.returncode is None

    async def start(self):
        if self.running():
            return
        if not os.path.exists(SYSTEM_PYTHON):
            self.error = "System Python not found"
            return
        env = _clean_subprocess_env(os.environ)
        env.setdefault("XDG_RUNTIME_DIR", runtime_dir())
        session_env = await asyncio.get_event_loop().run_in_executor(None, _find_session_env)
        env.update(session_env)
        # GTK must talk to gamescope's X server, not try Wayland first.
        env.pop("WAYLAND_DISPLAY", None)
        env["GDK_BACKEND"] = "x11"
        if "DISPLAY" not in env:
            self.error = "No game-mode display found"
            return
        try:
            self.proc = await asyncio.create_subprocess_exec(
                SYSTEM_PYTHON, OVERLAY_SCRIPT,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )
        except Exception as e:
            self.error = str(e)
            self.proc = None
            return
        self.error = None
        self._stderr_task = asyncio.create_task(self._watch_stderr(self.proc))
        decky.logger.info("overlay started (pid %s, DISPLAY=%s)", self.proc.pid, env.get("DISPLAY"))

    async def _watch_stderr(self, proc):
        try:
            err = await proc.stderr.read()
            await proc.wait()
        except Exception:
            return
        if proc.returncode not in (0, None, -15):
            text = err.decode(errors="replace").strip()
            last = text.splitlines()[-1] if text else "exit %s" % proc.returncode
            if "No module named" in text or "Namespace Gtk not available" in text:
                last = "GTK for Python is missing (run the setup tool's Decky option again)"
            self.error = last
            decky.logger.warning("overlay exited %s: %s", proc.returncode, text[-1500:])

    async def send(self, msg: dict):
        if not self.running():
            return
        try:
            self.proc.stdin.write((json.dumps(msg) + "\n").encode())
            await self.proc.stdin.drain()
        except Exception:
            decky.logger.warning("overlay pipe closed")

    async def stop(self):
        proc, self.proc = self.proc, None
        if proc is None or proc.returncode is not None:
            return
        try:
            proc.stdin.close()
            await asyncio.wait_for(proc.wait(), timeout=3)
        except Exception:
            try:
                proc.terminate()
            except ProcessLookupError:
                pass


# ------------------------------------------------------------- phone setup --

PHONE_SETUP_MINUTES = 15

PHONE_PAGE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Discord Deck setup</title>
<style>
:root { color-scheme: dark; }
body { margin: 0; background: #1e1f22; color: #dbdee1;
       font: 16px/1.45 system-ui, -apple-system, "Segoe UI", sans-serif; }
main { max-width: 34rem; margin: 0 auto; padding: 20px 16px 40px; }
h1 { font-size: 1.35rem; color: #fff; margin: 0 0 4px; }
p.sub { margin: 0 0 18px; color: #b5bac1; }
ol { padding-left: 1.3rem; margin: 0 0 20px; }
li { margin: 0 0 10px; }
b { color: #fff; }
code { background: #2b2d31; padding: 2px 6px; border-radius: 4px; }
a.btn, button { display: inline-block; border: 0; border-radius: 6px; padding: 10px 14px;
       font: inherit; font-weight: 600; text-decoration: none; cursor: pointer; }
a.btn { background: #5865f2; color: #fff; margin: 4px 0; }
button.copy { background: #2b2d31; color: #dbdee1; padding: 4px 10px; margin-left: 6px; }
label { display: block; font-weight: 600; color: #fff; margin: 14px 0 6px; }
input { box-sizing: border-box; width: 100%; padding: 12px; border-radius: 6px;
        border: 1px solid #3f4147; background: #111214; color: #fff; font: inherit; }
button.save { width: 100%; margin-top: 18px; background: #23a55a; color: #fff; padding: 14px; }
button.save:disabled { opacity: .6; }
#msg { margin-top: 14px; font-weight: 600; }
.ok { color: #57f287; } .err { color: #f23f43; }
</style></head><body><main>
<h1>Discord Deck setup</h1>
<p class="sub">Discord Deck needs its own Discord app. This takes about a minute and you only do it once.</p>
<ol>
<li><a class="btn" href="https://discord.com/developers/applications" target="_blank" rel="noopener">Open the Discord developer page</a><br>and sign in if it asks.</li>
<li>Tap <b>New Application</b>, give it any name, and tap <b>Create</b>.</li>
<li>Open <b>OAuth2</b> from the menu.</li>
<li>Under <b>Redirects</b>, tap <b>Add Redirect</b> and enter <code>http://localhost</code><button class="copy" type="button" data-copy="http://localhost">Copy</button>, then <b>Save Changes</b>.</li>
<li>Copy the <b>Client ID</b> and paste it below.</li>
<li>Tap <b>Reset Secret</b>, copy the new secret and paste it below.</li>
</ol>
<form id="f">
<label for="cid">Client ID</label>
<input id="cid" name="client_id" inputmode="numeric" autocomplete="off" required>
<label for="sec">Client secret</label>
<input id="sec" name="client_secret" autocomplete="off" required>
<button class="save" type="submit">Save to my BC-250</button>
</form>
<div id="msg"></div>
</main>
<script>
document.querySelectorAll("button.copy").forEach(function (b) {
  b.onclick = function () {
    var t = b.getAttribute("data-copy");
    var done = function () { b.textContent = "Copied"; };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(t).then(done);
    } else {
      var i = document.createElement("input"); i.value = t; document.body.appendChild(i);
      i.select(); try { document.execCommand("copy"); done(); } catch (e) {} i.remove();
    }
  };
});
var f = document.getElementById("f"), msg = document.getElementById("msg");
f.onsubmit = function (e) {
  e.preventDefault();
  var btn = f.querySelector("button.save");
  btn.disabled = true; msg.className = ""; msg.textContent = "Saving...";
  fetch(location.pathname, { method: "POST", body: new URLSearchParams(new FormData(f)) })
    .then(function (r) { return r.text().then(function (t) { return { ok: r.ok, t: t }; }); })
    .then(function (r) {
      msg.className = r.ok ? "ok" : "err"; msg.textContent = r.t;
      if (r.ok) { f.style.display = "none"; } else { btn.disabled = false; }
    })
    .catch(function () {
      msg.className = "err";
      msg.textContent = "Could not reach your BC-250. Is the setup screen still open on the TV?";
      btn.disabled = false;
    });
};
</script></body></html>
"""


def _lan_ip() -> str:
    """The address phones on the same network can reach this box at."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # No packet is sent; this only asks the kernel which interface
        # would be used to reach the internet.
        s.connect(("192.0.2.1", 9))
        return s.getsockname()[0]
    except OSError:
        return ""
    finally:
        s.close()


def _qr_svg(text: str) -> str:
    qrencode = shutil.which("qrencode")
    if not qrencode:
        return ""
    try:
        out = subprocess.run(
            [qrencode, "-t", "SVG", "-m", "2", "-s", "8", "-o", "-", text],
            capture_output=True, timeout=10, check=True,
        ).stdout
        return out.decode("utf-8", "replace")
    except Exception as e:
        decky.logger.warning("qrencode failed: %s", e)
        return ""


class PhoneSetup:
    """A tiny web page on the home network where a phone can paste the
    Discord app's ID and secret. Runs only while the setup screen asks for
    it, behind a random path, and stops once the codes are saved or after
    PHONE_SETUP_MINUTES. Uses aiohttp, which Decky itself ships."""

    def __init__(self, on_saved):
        self._on_saved = on_saved
        self._runner = None
        self._timer = None
        self.url = ""

    def running(self) -> bool:
        return self._runner is not None

    async def start(self) -> dict:
        if self._runner is not None:
            return await self.info()
        from aiohttp import web

        ip = _lan_ip()
        if not ip:
            raise RuntimeError("This box isn't on a network, so a phone can't reach it.")
        path = "/" + uuid.uuid4().hex[:16]

        async def page(_request):
            return web.Response(text=PHONE_PAGE, content_type="text/html",
                                headers={"Cache-Control": "no-store"})

        async def save(request):
            form = await request.post()
            cid = str(form.get("client_id", "")).strip()
            sec = str(form.get("client_secret", "")).strip()
            if not re.fullmatch(r"\d{15,22}", cid):
                return web.Response(status=400, text="That Client ID doesn't look right. It's a long number from the OAuth2 page.")
            if not re.fullmatch(r"[A-Za-z0-9_\-]{20,64}", sec):
                return web.Response(status=400, text="That secret doesn't look right. Tap Reset Secret and copy the whole thing.")
            try:
                self._on_saved(cid, sec)
            except Exception as e:
                decky.logger.error("phone setup save failed: %s", e)
                return web.Response(status=500, text="Could not save on the BC-250: %s" % e)
            asyncio.get_event_loop().call_later(1, lambda: asyncio.ensure_future(self.stop()))
            return web.Response(text="Saved! Go back to your TV and press Authorize in Discord Deck.")

        app = web.Application(client_max_size=4096)
        app.router.add_get(path, page)
        app.router.add_post(path, save)
        runner = web.AppRunner(app, access_log=None)
        await runner.setup()
        site = web.TCPSite(runner, "0.0.0.0", 0)
        await site.start()
        port = runner.addresses[0][1]
        self._runner = runner
        self.url = "http://%s:%d%s" % (ip, port, path)
        self._timer = asyncio.get_event_loop().call_later(
            PHONE_SETUP_MINUTES * 60, lambda: asyncio.ensure_future(self.stop()))
        decky.logger.info("Phone setup page up on port %d", port)
        return await self.info()

    async def info(self) -> dict:
        if not self.running():
            return {"running": False, "url": "", "qr_svg": ""}
        loop = asyncio.get_event_loop()
        qr = await loop.run_in_executor(None, _qr_svg, self.url)
        return {"running": True, "url": self.url, "qr_svg": qr}

    async def stop(self):
        runner, self._runner = self._runner, None
        if self._timer is not None:
            self._timer.cancel()
            self._timer = None
        if runner is not None:
            await runner.cleanup()
            decky.logger.info("Phone setup page stopped")


class Plugin:
    def __init__(self):
        self.ipc = DiscordIPC()
        self.ipc.on_event = self._on_ipc_event
        self.lock = asyncio.Lock()
        # Which channel_id we're currently SUBSCRIBE'd to for member/speaking
        # events, and whether the global (no-channel) VOICE_CHANNEL_SELECT
        # subscription is active. Both reset whenever the IPC connection drops.
        self._voice_subscribed_channel = None
        self._select_subscribed = False
        self._self_id = None
        self._speech_detector = SelfSpeechDetector(self._on_self_speaking_change)
        # The frontend's "who's speaking" state lives in a React component
        # that unmounts whenever the QAM panel closes, losing it — but
        # SPEAKING_START/STOP are edge-triggered, so on reopen there's no
        # new event to say "X is still talking". The backend process never
        # unmounts, so it keeps this as the actual current truth, and the
        # frontend can ask for a snapshot instead of only listening passively.
        self._currently_speaking = set()
        # Discord's own view of its voice (RTC) connection and mute/deafen,
        # kept live via SUBSCRIBE so the panel can't show stale state.
        self._rtc_state = None
        self._voice_flags = {"mute": None, "deaf": None}
        # Names and avatars of people in the current channel, for the overlay.
        self._members = {}
        # Join/leave cards only count once the member list for the channel
        # is in, so subscribing doesn't announce everyone already there.
        self._joins_armed = False
        self.overlay = SpeakingOverlay()
        self.phone = PhoneSetup(self._save_credentials_sync)

    async def _on_self_speaking_change(self, is_speaking: bool):
        if not self._self_id:
            return
        await self._update_speaking(self._self_id, is_speaking)

    async def _update_speaking(self, user_id: str, is_speaking: bool):
        if is_speaking:
            self._currently_speaking.add(user_id)
        else:
            self._currently_speaking.discard(user_id)
        evt = "SPEAKING_START" if is_speaking else "SPEAKING_STOP"
        try:
            await decky.emit("voice_event", evt, {"user_id": user_id})
        except Exception:
            decky.logger.exception("emit speaking event failed")
        await self._overlay_push()

    # -- overlay ---------------------------------------------------------------

    def _overlay_settings(self) -> dict:
        saved = read_config().get("overlay") or {}
        return {k: saved.get(k, v) for k, v in OVERLAY_DEFAULTS.items()}

    def _remember_member(self, vs: dict):
        user = (vs or {}).get("user") or {}
        if not user.get("id"):
            return
        self._members[str(user["id"])] = {
            "name": _display_name(user, vs.get("nick")),
            "avatar": _avatar_url(user),
        }

    async def _overlay_push(self):
        settings = self._overlay_settings()
        if not settings["enabled"] or not self._voice_subscribed_channel:
            await self.overlay.stop()
            return
        if not self.overlay.running():
            await self.overlay.start()
        speakers = []
        for uid in self._currently_speaking:
            if uid == self._self_id and not settings["show_self"]:
                continue
            m = self._members.get(str(uid)) or {}
            if uid == self._self_id and not m and self.ipc.user:
                m = {"name": _display_name(self.ipc.user), "avatar": _avatar_url(self.ipc.user)}
            speakers.append({"id": uid, "name": m.get("name", "Someone"), "avatar": m.get("avatar")})
        await self.overlay.send({
            "speakers": speakers,
            "corner": settings["corner"],
            "opacity": max(0, min(100, int(settings["opacity"]))) / 100,
            "scale": max(50, min(200, int(settings["scale"]))) / 100,
            "ring": read_config().get("ring_color", DEFAULT_RING_COLOR),
        })

    @_logged
    async def get_overlay(self):
        return {**self._overlay_settings(), "error": self.overlay.error}

    @_logged
    async def set_overlay(self, patch: dict):
        cfg = read_config()
        cur = {**OVERLAY_DEFAULTS, **(cfg.get("overlay") or {})}
        for k in OVERLAY_DEFAULTS:
            if k in patch:
                cur[k] = patch[k]
        if cur["corner"] not in ("tl", "tr", "bl", "br"):
            cur["corner"] = "tr"
        cfg["overlay"] = cur
        write_config(cfg)
        await self._overlay_push()
        return await self.get_overlay()

    @_logged
    async def preview_overlay(self):
        """Show a sample card for a few seconds so the corner and look can be
        checked without anyone talking."""
        settings = self._overlay_settings()
        if not settings["enabled"]:
            return await self.get_overlay()
        if not self.overlay.running():
            await self.overlay.start()
        user = self.ipc.user or {"id": "0", "username": "You"}
        await self.overlay.send({
            "speakers": [{"id": "preview", "name": _display_name(user), "avatar": _avatar_url(user)}],
            "corner": settings["corner"],
            "opacity": int(settings["opacity"]) / 100,
            "scale": int(settings["scale"]) / 100,
            "ring": read_config().get("ring_color", DEFAULT_RING_COLOR),
        })
        await asyncio.sleep(3)
        if self._voice_subscribed_channel:
            await self._overlay_push()
        else:
            await self.overlay.send({"speakers": []})
            await asyncio.sleep(LINGER_STOP)
            await self.overlay.stop()
        return await self.get_overlay()

    async def _start_self_speech_detection(self):
        try:
            devices = await pipewire_devices()
            source_id = devices.get("default_source_id")
            if source_id is not None:
                await self._speech_detector.start(source_id)
        except Exception:
            decky.logger.exception("could not start self speech detection")

    def _on_ipc_event(self, evt: str, data: dict):
        # Called synchronously from DiscordIPC's read loop — must not block
        # or await new IPC requests (see request()'s docstring note).
        if evt == "VOICE_CHANNEL_SELECT":
            asyncio.create_task(self._handle_channel_select(data.get("channel_id")))
        elif evt in ("SPEAKING_START", "SPEAKING_STOP"):
            asyncio.create_task(self._update_speaking(data.get("user_id"), evt == "SPEAKING_START"))
        elif evt in VOICE_MEMBER_EVENTS:
            asyncio.create_task(self._emit_voice_event(evt, data))
        elif evt == "VOICE_SETTINGS_UPDATE":
            asyncio.create_task(self._handle_voice_settings_update(data))
        elif evt == "VOICE_CONNECTION_STATUS":
            asyncio.create_task(self._handle_connection_status(data))

    async def _handle_voice_settings_update(self, data: dict):
        mute, deaf = bool(data.get("mute")), bool(data.get("deaf"))
        if (mute, deaf) != (self._voice_flags["mute"], self._voice_flags["deaf"]):
            decky.logger.info("voice settings changed: mute=%s deaf=%s", mute, deaf)
        self._voice_flags = {"mute": mute, "deaf": deaf}
        self._speech_detector.set_muted(mute or deaf)
        try:
            await decky.emit("voice_settings", {"mute": mute, "deaf": deaf})
        except Exception:
            decky.logger.exception("emit voice_settings failed")

    async def _handle_connection_status(self, data: dict):
        state = data.get("state")
        if state != self._rtc_state:
            # This fires repeatedly with ping stats; only log real changes.
            decky.logger.info(
                "voice connection: %s -> %s (host=%s, avg_ping=%s)",
                self._rtc_state, state, data.get("hostname"), data.get("average_ping"),
            )
            self._rtc_state = state
            try:
                await decky.emit("connection_status", state)
            except Exception:
                decky.logger.exception("emit connection_status failed")

    async def _overlay_notice(self, kind: str, data: dict):
        """A one-off "joined" / "left" card for someone other than you."""
        user = (data or {}).get("user") or {}
        uid = str(user.get("id") or "")
        settings = self._overlay_settings()
        if (not uid or not self._joins_armed or not settings["enabled"]
                or not settings["show_joins"] or uid == str(self._self_id)
                or not self.overlay.running()):
            return
        m = self._members.get(uid) or {
            "name": _display_name(user, data.get("nick")), "avatar": _avatar_url(user),
        }
        await self.overlay.send({"notice": {"id": uid, "kind": kind, **m}})

    async def _emit_voice_event(self, evt: str, data: dict):
        if evt in ("VOICE_STATE_CREATE", "VOICE_STATE_UPDATE"):
            uid = str(((data or {}).get("user") or {}).get("id") or "")
            known = uid in self._members
            self._remember_member(data)
            if evt == "VOICE_STATE_CREATE" and not known:
                await self._overlay_notice("join", data)
        elif evt == "VOICE_STATE_DELETE":
            await self._overlay_notice("leave", data)
            uid = str(((data or {}).get("user") or {}).get("id") or "")
            self._members.pop(uid, None)
        try:
            await decky.emit("voice_event", evt, data)
        except Exception:
            decky.logger.exception("emit voice_event failed")

    async def _handle_channel_select(self, channel_id):
        try:
            await self._subscribe_voice_members(channel_id)
            if channel_id:
                await self._start_self_speech_detection()
            else:
                await self._speech_detector.stop()
            await decky.emit("channel_changed", channel_id)
        except Exception:
            decky.logger.exception("_handle_channel_select failed")

    async def _subscribe_voice_members(self, channel_id):
        """(Re)subscribe to voice-state/speaking events for channel_id,
        dropping any previous channel's subscription. channel_id=None just
        drops the current subscription (e.g. after leaving a call)."""
        if self._voice_subscribed_channel == channel_id:
            return
        old = self._voice_subscribed_channel
        # Speaking state is scoped to the channel we were listening to —
        # carrying it over to a different channel would show stale glows.
        self._currently_speaking.clear()
        if old:
            for evt in VOICE_MEMBER_EVENTS:
                try:
                    await self.ipc.request("UNSUBSCRIBE", {"channel_id": old}, evt=evt, timeout=10)
                except Exception:
                    decky.logger.warning("unsubscribe %s (channel %s) failed", evt, old)
        self._voice_subscribed_channel = channel_id
        self._members = {}
        self._joins_armed = False
        if channel_id:
            for evt in VOICE_MEMBER_EVENTS:
                try:
                    await self.ipc.request("SUBSCRIBE", {"channel_id": channel_id}, evt=evt, timeout=10)
                except Exception:
                    decky.logger.warning("subscribe %s (channel %s) failed", evt, channel_id)
            try:
                data = await self.ipc.request("GET_CHANNEL", {"channel_id": str(channel_id)}, timeout=10)
                for vs in (data or {}).get("voice_states", []):
                    self._remember_member(vs)
            except Exception:
                decky.logger.warning("could not read members of channel %s", channel_id)
            self._joins_armed = True
        await self._overlay_push()

    async def _after_authenticated(self):
        # Runs once right after a fresh AUTHENTICATE succeeds: subscribe to
        # channel-switch notifications globally, and sync onto whatever
        # voice channel the user's already in (covers plugin reload mid-call,
        # or the user having joined from Discord's own UI).
        self._self_id = (self.ipc.user or {}).get("id")
        if not self._select_subscribed:
            try:
                await self.ipc.request("SUBSCRIBE", {}, evt="VOICE_CHANNEL_SELECT", timeout=10)
                self._select_subscribed = True
            except Exception:
                decky.logger.exception("subscribe VOICE_CHANNEL_SELECT failed")
            for global_evt in ("VOICE_SETTINGS_UPDATE", "VOICE_CONNECTION_STATUS"):
                try:
                    await self.ipc.request("SUBSCRIBE", {}, evt=global_evt, timeout=10)
                except Exception:
                    decky.logger.exception("subscribe %s failed", global_evt)
        try:
            current = await self.ipc.request("GET_SELECTED_VOICE_CHANNEL")
            channel_id = (current or {}).get("id")
            await self._subscribe_voice_members(channel_id)
            if channel_id:
                await self._start_self_speech_detection()
        except Exception:
            decky.logger.exception("initial voice subscribe sync failed")
        try:
            voice = await self.ipc.request("GET_VOICE_SETTINGS")
            self._voice_flags = {"mute": bool((voice or {}).get("mute")), "deaf": bool((voice or {}).get("deaf"))}
            self._speech_detector.set_muted(bool((voice or {}).get("mute") or (voice or {}).get("deaf")))
        except Exception:
            decky.logger.exception("initial mute sync failed")

    async def _main(self):
        decky.logger.info("Discord Deck loaded")

    async def _unload(self):
        await self.phone.stop()
        await self.overlay.stop()
        await self._speech_detector.stop()
        await self.ipc.close()
        decky.logger.info("Discord Deck unloaded")

    # -- credentials ----------------------------------------------------------

    @_logged
    async def get_status(self):
        cfg = read_config()
        return {
            "has_credentials": bool(cfg.get("client_id") and cfg.get("client_secret")),
            "has_token": bool(cfg.get("access_token")),
            "connected": self.ipc.connected(),
            "authenticated": self.ipc.authenticated,
            "socket": self.ipc.socket_path,
            "user": self.ipc.user,
            "client_id": cfg.get("client_id", ""),
            "ring_color": cfg.get("ring_color", DEFAULT_RING_COLOR),
        }

    @_logged
    async def set_ring_color(self, color: str):
        """color: any valid CSS color string (the color picker returns
        hsl()/hsla()). Stored as-is and applied directly in the frontend's
        inline styles, so no format conversion happens on either side."""
        cfg = read_config()
        cfg["ring_color"] = color
        write_config(cfg)
        return await self.get_status()

    def _save_credentials_sync(self, client_id: str, client_secret: str):
        cfg = read_config()
        if cfg.get("client_id") != client_id.strip():
            cfg.pop("access_token", None)
            cfg.pop("refresh_token", None)
        cfg["client_id"] = client_id.strip()
        cfg["client_secret"] = client_secret.strip()
        write_config(cfg)

    async def set_credentials(self, client_id: str, client_secret: str):
        self._save_credentials_sync(client_id, client_secret)
        return await self.get_status()

    @_logged
    async def start_phone_setup(self):
        """Serve the paste-your-codes page and return its address and QR
        code (an SVG string, empty when qrencode isn't installed)."""
        return await self.phone.start()

    @_logged
    async def stop_phone_setup(self):
        await self.phone.stop()
        return {"running": False}

    async def sign_out(self):
        cfg = read_config()
        cfg.pop("access_token", None)
        cfg.pop("refresh_token", None)
        write_config(cfg)
        await self.ipc.close()
        return await self.get_status()

    # -- connection -----------------------------------------------------------

    async def _token_exchange(self, fields: dict):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _post_form, TOKEN_URL, fields)

    async def _connect_with_autolaunch(self, client_id):
        try:
            await self.ipc.connect(client_id)
            return
        except RPCError:
            pass  # no socket yet — try starting Discord ourselves below

        try:
            await decky.emit("connect_status", "Discord isn't running — starting it in the background…")
        except Exception:
            pass
        try:
            cmd = await launch_discord_background()
        except Exception as e:
            decky.logger.exception("auto-launch Discord failed")
            raise RPCError(
                "No Discord IPC socket found, and Discord could not be auto-started (%s). "
                "Install Discord (Flatpak or native) or start it manually." % e
            )

        decky.logger.info("waiting for Discord IPC socket after auto-launch (%s)", cmd)
        loop = asyncio.get_event_loop()
        deadline = loop.time() + 25
        last_err = None
        first_wait = True
        while loop.time() < deadline:
            await asyncio.sleep(1.5)
            if first_wait:
                first_wait = False
                try:
                    await decky.emit("connect_status", "Waiting for Discord to finish starting…")
                except Exception:
                    pass
            try:
                await self.ipc.connect(client_id)
                try:
                    await decky.emit("connect_status", "")
                except Exception:
                    pass
                return
            except RPCError as e:
                last_err = e
        raise RPCError("Started Discord but its IPC socket never came up: %s" % last_err)

    async def _ensure_connected(self):
        cfg = read_config()
        client_id = cfg.get("client_id")
        if not client_id:
            raise RPCError("Add your Discord app's client ID and secret first")
        if not self.ipc.connected():
            # A fresh connection means any previous SUBSCRIBEs are gone too.
            self._voice_subscribed_channel = None
            self._select_subscribed = False
            await self._connect_with_autolaunch(client_id)
        if self.ipc.authenticated:
            return
        token = cfg.get("access_token")
        if not token:
            raise RPCError("Not authorized yet — run Authorize with Discord")
        try:
            await self.ipc.authenticate(token)
        except RPCError:
            refresh = cfg.get("refresh_token")
            if not refresh:
                raise
            data = await self._token_exchange(
                {
                    "client_id": client_id,
                    "client_secret": cfg.get("client_secret", ""),
                    "grant_type": "refresh_token",
                    "refresh_token": refresh,
                }
            )
            cfg["access_token"] = data["access_token"]
            cfg["refresh_token"] = data.get("refresh_token", refresh)
            write_config(cfg)
            await self.ipc.authenticate(cfg["access_token"])
        await self._after_authenticated()

    async def connect(self):
        async with self.lock:
            try:
                await self._ensure_connected()
            except Exception:
                decky.logger.exception("connect() failed")
                raise
            return await self.get_status()

    async def authorize(self):
        """Full OAuth flow. Discord shows a consent modal — approve it on screen."""
        async with self.lock:
            cfg = read_config()
            client_id = cfg.get("client_id")
            client_secret = cfg.get("client_secret")
            if not (client_id and client_secret):
                raise RPCError("Add your client ID and secret first")
            try:
                if not self.ipc.connected():
                    decky.logger.info("authorize: connecting to Discord IPC")
                    self._voice_subscribed_channel = None
                    self._select_subscribed = False
                    await self._connect_with_autolaunch(client_id)
                decky.logger.info("authorize: requesting AUTHORIZE (waiting on consent modal)")
                code = await self.ipc.authorize(client_id)
                decky.logger.info("authorize: got code, exchanging for token")
                data = await self._token_exchange(
                    {
                        "client_id": client_id,
                        "client_secret": client_secret,
                        "grant_type": "authorization_code",
                        "code": code,
                        "redirect_uri": REDIRECT_URI,
                    }
                )
                cfg["access_token"] = data["access_token"]
                cfg["refresh_token"] = data.get("refresh_token", "")
                write_config(cfg)
                decky.logger.info("authorize: authenticating over IPC")
                await self.ipc.authenticate(cfg["access_token"])
                await self._after_authenticated()
                decky.logger.info("authorize: success, signed in as %s", self.ipc.user)
            except Exception:
                decky.logger.exception("authorize() failed")
                raise
            return await self.get_status()

    async def disconnect(self):
        await self.ipc.close()
        return await self.get_status()

    async def _log_diagnostics(self, label: str):
        """Snapshot of everything that could explain 'in the call but can't
        hear anyone', written to the log so the state at the moment of
        failure is captured, not just after it's been fixed."""
        if self.ipc.connected():
            for cmd in ("GET_VOICE_SETTINGS", "GET_SELECTED_VOICE_CHANNEL"):
                try:
                    data = await self.ipc.request(cmd, timeout=5)
                    if cmd == "GET_VOICE_SETTINGS":
                        out = (data or {}).get("output") or {}
                        inp = (data or {}).get("input") or {}
                        decky.logger.info(
                            "diag[%s] voice: mute=%s deaf=%s output_device=%r output_volume=%s "
                            "input_device=%r input_volume=%s mode=%s",
                            label, data.get("mute"), data.get("deaf"), out.get("device_id"),
                            out.get("volume"), inp.get("device_id"), inp.get("volume"),
                            (data.get("mode") or {}).get("type"),
                        )
                    else:
                        decky.logger.info(
                            "diag[%s] channel: id=%s name=%r members=%s",
                            label, (data or {}).get("id"), (data or {}).get("name"),
                            len((data or {}).get("voice_states") or []),
                        )
                except Exception as e:
                    decky.logger.warning("diag[%s] %s failed: %s", label, cmd, e)
        else:
            decky.logger.info("diag[%s] RPC not connected", label)
        try:
            rc, out, err = await _run(["wpctl", "status"], timeout=10)
            audio = out.split("Video")[0] if out else err
            decky.logger.info("diag[%s] wpctl status (audio):\n%s", label, audio.strip())
        except Exception as e:
            decky.logger.warning("diag[%s] wpctl status failed: %s", label, e)
        decky.logger.info(
            "diag[%s] mic monitor running=%s voice_connection=%s speaking_now=%s",
            label, self._speech_detector.task is not None, self._rtc_state,
            sorted(self._currently_speaking),
        )

    async def get_voice_connection_status(self):
        return self._rtc_state

    @_logged
    async def reset_connection(self):
        """Does what reloading Decky did to fix the 'can't hear anyone' bug,
        without reloading Decky: drops the RPC connection (which makes
        Discord release and revert any voice settings this plugin was
        holding), stops the mic monitor, then reconnects and re-syncs to
        whatever call you're in."""
        async with self.lock:
            await self._log_diagnostics("before reset")
            await self._speech_detector.stop()
            await self.ipc.close()
            self._voice_subscribed_channel = None
            self._select_subscribed = False
            self._currently_speaking.clear()
            self._rtc_state = None
            await asyncio.sleep(0.5)
            await self._ensure_connected()
            await self._log_diagnostics("after reset")
            return await self.get_status()

    @_logged
    async def discord_app_info(self):
        """What the frontend needs to add Discord to the Steam library."""
        found = await _discord_steam_command()
        cfg = read_config()
        if not found:
            return {"installed": False, "shortcut_appid": cfg.get("steam_shortcut_appid")}
        exe, options, _flatpak = found
        return {
            "installed": True,
            "exe": exe,
            "start_dir": os.path.dirname(exe),
            "options": options,
            "shortcut_appid": cfg.get("steam_shortcut_appid"),
        }

    @_logged
    async def remember_shortcut(self, appid):
        cfg = read_config()
        cfg["steam_shortcut_appid"] = appid
        write_config(cfg)
        return True

    @_logged
    async def quit_discord(self):
        """Close a Discord that's running hidden in the background, so the
        copy started from the Steam library opens a real window instead of
        handing over to it."""
        await self.ipc.close()
        found = await _discord_steam_command()
        if found and found[2]:
            await _run(["flatpak", "kill", found[2]], timeout=10)
        elif found:
            exe = os.path.realpath(found[0])
            for name in DISCORD_PROCESS_NAMES:
                await _run(["pkill", "-x", name], timeout=5)
            await _run(["pkill", "-f", exe], timeout=5)
        await asyncio.sleep(1.5)
        return True

    @_logged
    async def launch_discord(self):
        """Start Discord minimized in the background without also trying to
        connect/authorize — useful as a standalone button, e.g. before
        credentials are set up, or if auto-launch during Connect failed."""
        await launch_discord_background()
        return {"launched": True}

    # -- voice channels -------------------------------------------------------

    @_logged
    async def get_guilds(self):
        await self._ensure_connected()
        data = await self.ipc.request("GET_GUILDS")
        guilds = (data or {}).get("guilds", [])

        async def with_icon(g):
            try:
                detail = await self.ipc.request("GET_GUILD", {"guild_id": g["id"]}, timeout=10)
                g["icon_url"] = (detail or {}).get("icon_url")
            except Exception:
                decky.logger.warning("icon fetch failed for guild %s", g.get("id"))
                g["icon_url"] = None
            return g

        # GET_GUILDS doesn't include icons; GET_GUILD (singular) does. Fire
        # these concurrently the same way get_voice_channels does for
        # per-channel member counts — the IPC socket multiplexes by nonce.
        return list(await asyncio.gather(*(with_icon(g) for g in guilds)))

    @_logged
    async def get_voice_channels(self, guild_id: str):
        await self._ensure_connected()
        data = await self.ipc.request("GET_CHANNELS", {"guild_id": str(guild_id)})
        channels = [
            c for c in (data or {}).get("channels", []) if c.get("type") in VOICE_CHANNEL_TYPES
        ]

        async def with_member_count(c):
            try:
                detail = await self.ipc.request("GET_CHANNEL", {"channel_id": c["id"]}, timeout=10)
                c["member_count"] = len((detail or {}).get("voice_states", []))
            except Exception:
                decky.logger.warning("member count fetch failed for channel %s", c.get("id"))
                c["member_count"] = None
            return c

        # GET_CHANNELS doesn't include voice_states, so fetch each channel's
        # detail for a member count. The IPC socket multiplexes concurrent
        # requests by nonce, so fire these in parallel rather than serially.
        return list(await asyncio.gather(*(with_member_count(c) for c in channels)))

    @_logged
    async def get_current_channel(self):
        await self._ensure_connected()
        return await self.ipc.request("GET_SELECTED_VOICE_CHANNEL")

    @_logged
    async def get_channel_members(self, channel_id: str):
        """Voice states (users + mute/deafen flags) currently in channel_id.
        Doesn't include live speaking state — see get_currently_speaking()
        for a snapshot, and the "voice_event" pushes for live updates."""
        await self._ensure_connected()
        data = await self.ipc.request("GET_CHANNEL", {"channel_id": str(channel_id)})
        return (data or {}).get("voice_states", [])

    @_logged
    async def get_currently_speaking(self):
        """Snapshot of who's speaking right now, as tracked continuously by
        the backend (which — unlike the QAM panel — never unmounts). Call
        this on mount/channel-change instead of relying solely on
        SPEAKING_START/STOP pushes, since those are edge-triggered: someone
        already mid-sentence when the panel reopens won't fire a new one."""
        return list(self._currently_speaking)

    @_logged
    async def join_channel(self, channel_id: str, force: bool = True):
        await self._ensure_connected()
        result = await self.ipc.request(
            "SELECT_VOICE_CHANNEL",
            {"channel_id": str(channel_id), "force": force},
            timeout=30,
        )
        # Don't wait on the VOICE_CHANNEL_SELECT push event for this —
        # subscribe right away so the member list is live immediately.
        await self._subscribe_voice_members(str(channel_id))
        await self._start_self_speech_detection()
        return result

    @_logged
    async def leave_channel(self):
        await self._ensure_connected()
        result = await self.ipc.request(
            "SELECT_VOICE_CHANNEL", {"channel_id": None}, timeout=30
        )
        await self._subscribe_voice_members(None)
        await self._speech_detector.stop()
        return result

    # -- discord audio --------------------------------------------------------

    @_logged
    async def get_voice_settings(self):
        await self._ensure_connected()
        data = await self.ipc.request("GET_VOICE_SETTINGS")
        inp = (data or {}).get("input") or {}
        out = (data or {}).get("output") or {}
        mode = (data or {}).get("mode") or {}
        mute = bool((data or {}).get("mute"))
        deaf = bool((data or {}).get("deaf"))
        # Discord auto-mutes the mic when you deafen, so treat either as
        # "not actually transmitting" for the self speech detector.
        self._speech_detector.set_muted(mute or deaf)
        return {
            "input_device_id": inp.get("device_id"),
            "input_volume": inp.get("volume"),
            "input_devices": inp.get("available_devices", []),
            "output_device_id": out.get("device_id"),
            "output_volume": out.get("volume"),
            "output_devices": out.get("available_devices", []),
            "mute": mute,
            "deaf": deaf,
            "mode": mode.get("type"),
        }

    @_logged
    async def set_voice_settings(self, patch: dict):
        """patch keys: input_device_id, input_volume, output_device_id,
        output_volume, mute, deaf, mode."""
        await self._ensure_connected()
        args = {}
        if "input_device_id" in patch or "input_volume" in patch:
            args["input"] = {}
            if patch.get("input_device_id") is not None:
                args["input"]["device_id"] = patch["input_device_id"]
            if patch.get("input_volume") is not None:
                args["input"]["volume"] = float(patch["input_volume"])
        if "output_device_id" in patch or "output_volume" in patch:
            args["output"] = {}
            if patch.get("output_device_id") is not None:
                args["output"]["device_id"] = patch["output_device_id"]
            if patch.get("output_volume") is not None:
                args["output"]["volume"] = float(patch["output_volume"])
        if patch.get("mute") is not None:
            args["mute"] = bool(patch["mute"])
        if patch.get("deaf") is not None:
            args["deaf"] = bool(patch["deaf"])
        if patch.get("mode"):
            args["mode"] = {"type": patch["mode"]}
        if not args:
            return await self.get_voice_settings()
        await self.ipc.request("SET_VOICE_SETTINGS", args, timeout=20)
        return await self.get_voice_settings()

    # -- system audio ---------------------------------------------------------

    @_logged
    async def get_system_devices(self):
        return await pipewire_devices()

    @_logged
    async def set_system_default(self, node_id: int):
        rc, out, err = await _run(["wpctl", "set-default", str(node_id)])
        decky.logger.info(
            "wpctl set-default %s -> rc=%s stdout=%r stderr=%r", node_id, rc, out.strip(), err.strip()
        )
        if rc != 0:
            raise RuntimeError(err.strip() or "wpctl set-default failed")
        # wpctl status can lag a beat behind wpctl set-default returning, so
        # poll briefly until the requested node actually shows as default.
        devices = await pipewire_devices()
        for i in range(10):
            matched = node_id in (devices["default_sink_id"], devices["default_source_id"])
            decky.logger.info(
                "set_system_default poll %d: matched=%s default_sink_id=%s default_source_id=%s",
                i, matched, devices["default_sink_id"], devices["default_source_id"],
            )
            if matched:
                break
            await asyncio.sleep(0.15)
            devices = await pipewire_devices()
        # If we're actively monitoring the mic for self-speaking and the
        # default *source* just changed, re-target the detector so it keeps
        # listening to whichever device is actually feeding Discord now.
        if self._speech_detector.task and devices.get("default_source_id") == node_id:
            await self._start_self_speech_detection()
        return devices
